import { createFileRoute } from "@tanstack/react-router";
import { CrmApp } from "@/components/crm/CrmApp";

export const Route = createFileRoute("/")({ component: CrmApp });
