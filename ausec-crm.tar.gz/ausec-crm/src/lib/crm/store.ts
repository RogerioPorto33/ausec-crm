import { create } from "zustand";
import { persist } from "zustand/middleware";
import {
  defaultProcesses,
  defaultStatuses,
  defaultEncargos,
  defaultVinculos,
  emptyDraft,
  hhFinal,
  lineTotal,
  materialLines,
  normalizeNivel,
  precoUnit,
  round2,
  stockOf,
  uid,
  type Client,
  type Draft,
  type ProcessRec,
  type Product,
  type Project,
  type Proposal,
  type ScheduleItem,
  type ServiceRec,
  type StatusRec,
  type StockMove,
  type Alocacao,
  type AssetRec,
  type DocRec,
  type Encargo,
  type Evento,
  type Mensagem,
  type Pessoa,
  type Rdo,
  type Supplier,
  type Taxa,
  type Usuario,
  type Vinculo,
} from "./model";
import { defaultTaxas, defaultUsuarios } from "./model";

export type ViewId =
  | "painel"
  | "fornecedores"
  | "produtos"
  | "servicos"
  | "clientes"
  | "projetos"
  | "proposta"
  | "historico"
  | "prazos"
  | "almoxarifado"
  | "pessoal"
  | "admin"
  | "mensagens";

type State = {
  initialized: boolean;
  view: ViewId;
  suppliers: Supplier[];
  products: Product[];
  services: ServiceRec[];
  clients: Client[];
  projects: Project[];
  proposals: Proposal[];
  processes: ProcessRec[];
  statuses: StatusRec[];
  schedule: ScheduleItem[];
  moves: StockMove[];
  assets: AssetRec[];
  encargos: Encargo[];
  vinculos: Vinculo[];
  pessoas: Pessoa[];
  alocacoes: Alocacao[];
  docs: DocRec[];
  eventos: Evento[];
  usuarios: Usuario[];
  taxas: Taxa[];
  mensagens: Mensagem[];
  rdos: Rdo[];
  currentUserId: string;
  query: string;
  dataDe: string;
  dataAte: string;
  warehouseProposalId: string;
  draft: Draft;
  notice: string;
  gruposMigrados: boolean;
  setView: (view: ViewId) => void;
  setNotice: (notice: string) => void;
  setQuery: (query: string) => void;
  setPeriodo: (dataDe: string, dataAte: string) => void;
  seedIfEmpty: () => void;
  upsertSupplier: (row: Supplier) => void;
  removeSupplier: (id: string) => void;
  upsertProduct: (row: Product) => void;
  removeProduct: (id: string) => void;
  upsertService: (row: ServiceRec) => void;
  removeService: (id: string) => void;
  upsertClient: (row: Client) => void;
  removeClient: (id: string) => void;
  upsertProject: (row: Project) => void;
  removeProject: (id: string) => void;
  patchDraft: (patch: Partial<Draft>) => void;
  addProductLine: (productId: string, qtd: number, justificativa: string) => void;
  addToGroup: (grupoId: string, productId: string, qtd: number) => void;
  setGroupQty: (grupoId: string, qtd: number) => void;
  removeGroup: (grupoId: string) => void;
  addServiceLine: (serviceId: string, qtd: number, justificativa: string, nivel: number) => void;
  patchLine: (
    id: string,
    patch: Partial<Pick<Draft["itens"][number], "qtd" | "margem" | "justificativa" | "custo" | "nivel">>,
  ) => void;
  removeLine: (id: string) => void;
  applyMarginAll: () => void;
  newDraft: () => void;
  loadProposal: (id: string) => void;
  saveProposal: () => string | null;
  removeProposal: (id: string) => void;
  duplicateProposal: (id: string) => void;
  upsertProcess: (row: ProcessRec) => void;
  removeProcess: (id: string) => void;
  upsertStatus: (row: StatusRec) => void;
  removeStatus: (id: string) => void;
  upsertSchedule: (row: ScheduleItem) => void;
  removeSchedule: (id: string) => void;
  openWarehouse: (proposalId: string) => void;
  addMove: (row: StockMove) => void;
  removeMove: (id: string) => void;
  upsertAsset: (row: AssetRec) => void;
  removeAsset: (id: string) => void;
  upsertEncargo: (row: Encargo) => void;
  removeEncargo: (id: string) => void;
  upsertVinculo: (row: Vinculo) => void;
  removeVinculo: (id: string) => void;
  upsertPessoa: (row: Pessoa) => void;
  removePessoa: (id: string) => void;
  upsertAlocacao: (row: Alocacao) => void;
  removeAlocacao: (id: string) => void;
  upsertDoc: (row: DocRec) => void;
  removeDoc: (id: string) => void;
  logEvento: (row: Omit<Evento, "id">) => void;
  login: (email: string, senha: string) => string | null;
  logout: () => void;
  upsertUsuario: (row: Usuario) => void;
  removeUsuario: (id: string) => void;
  upsertTaxa: (row: Taxa) => void;
  removeTaxa: (id: string) => void;
  upsertMensagem: (row: Mensagem) => void;
  removeMensagem: (id: string) => void;
  upsertRdo: (row: Rdo) => void;
  removeRdo: (id: string) => void;
};

function seedBundle() {
  const f1 = "sup-furukawa";
  const f2 = "sup-intelbras";
  const f3 = "sup-eaton";
  const c1 = "cli-exemplo";
  const suppliers: Supplier[] = [
    { id: f1, nome: "Furukawa", contato: "Comercial", email: "comercial@exemplo.com", telefone: "", cnpj: "", observacoes: "Base de exemplo — apague quando quiser." },
    { id: f2, nome: "Intelbras", contato: "", email: "", telefone: "", cnpj: "", observacoes: "" },
    { id: f3, nome: "Eaton", contato: "", email: "", telefone: "", cnpj: "", observacoes: "" },
  ];
  const products: Product[] = [
    { id: "prd-utp", codigo: "CAB-UTP-6", descricao: "Cabo F/UTP Cat.6 LSZH, caixa 305 m", fabricante: "Furukawa", unidade: "CX", categoria: "Cabeamento Estruturado e Óptico", fornecedorId: f1, custo: 890, tipo: "produto" },
    { id: "prd-fo", codigo: "FO-SM-12", descricao: "Cabo óptico CFOA-SM 12 fibras", fabricante: "Furukawa", unidade: "MT", categoria: "Cabeamento Estruturado e Óptico", fornecedorId: f1, custo: 4.8, tipo: "produto" },
    { id: "prd-rack", codigo: "RK-12U", descricao: "Rack outdoor 12U 600×450, IP55", fabricante: "Intelbras", unidade: "UND", categoria: "Racks e Organização", fornecedorId: f2, custo: 1850, tipo: "equipamento" },
    { id: "prd-sw", codigo: "SW-8P-POE", descricao: "Switch industrial 8 portas PoE+", fabricante: "Intelbras", unidade: "UND", categoria: "Ativos / Switching", fornecedorId: f2, custo: 1420, tipo: "equipamento" },
    { id: "prd-ups", codigo: "UPS-1K", descricao: "Nobreak 1 kVA senoidal", fabricante: "Eaton", unidade: "UND", categoria: "Energia / Nobreak", fornecedorId: f3, custo: 980, tipo: "equipamento" },
    { id: "prd-cam", codigo: "CAM-BULLET", descricao: "Câmera bullet IP varifocal IR 40 m", fabricante: "Intelbras", unidade: "UND", categoria: "Câmeras e Fixação", fornecedorId: f2, custo: 640, tipo: "equipamento" },
    {
      id: "prd-kit-rack",
      codigo: "KIT-RACK",
      descricao: "Rack indoor",
      fabricante: "",
      unidade: "CJ",
      categoria: "Racks e Organização",
      fornecedorId: "",
      custo: 4250,
      tipo: "grupo",
      componentes: [
        { productId: "prd-rack", qtd: 1 },
        { productId: "prd-sw", qtd: 1 },
        { productId: "prd-ups", qtd: 1 },
      ],
    },
  ];
  const services: ServiceRec[] = [
    { id: "srv-cam", codigo: "S-CAM", descricao: "Instalação e apontamento de câmera IP", unidade: "UND", categoria: "Serviços", hhBase: 1.5, nivel: 2, custo: 180 },
    { id: "srv-fus", codigo: "S-FUS", descricao: "Fusão e certificação de fibra (por fusão)", unidade: "UND", categoria: "Serviços", hhBase: 0.25, nivel: 1, custo: 35 },
    { id: "srv-com", codigo: "S-COM", descricao: "Comissionamento do sistema", unidade: "SV", categoria: "Serviços", hhBase: 6, nivel: 1, custo: 960 },
  ];
  const clients: Client[] = [
    { id: c1, nome: "Indústria Exemplo", contato: "Engenharia", email: "eng@exemplo.com", telefone: "", cidade: "Sinop", estado: "MT" },
  ];
  const projects: Project[] = [
    { id: "prj-cftv", clienteId: c1, nome: "CFTV galpão — exemplo", descricao: "Registro de demonstração. Substitua pelos dados reais.", status: "em_analise" },
  ];
  return { suppliers, products, services, clients, projects };
}

function sampleSchedule(): ScheduleItem[] {
  return [
    { id: "sch-1", projetoId: "prj-cftv", processoId: "prc-vistoria", statusId: "st-ok", nome: "Vistoria de campo e medição", responsavel: "Rogério", inicioPrev: "2026-10-06", fimPrev: "2026-10-08", inicioReal: "2026-10-06", fimReal: "2026-10-08", progresso: 100, observacoes: "" },
    { id: "sch-2", projetoId: "prj-cftv", processoId: "prc-projeto", statusId: "st-andamento", nome: "Projeto executivo e quantitativos", responsavel: "Engenharia", inicioPrev: "2026-10-09", fimPrev: "2026-10-20", inicioReal: "2026-10-09", fimReal: "", progresso: 60, observacoes: "" },
    { id: "sch-3", projetoId: "prj-cftv", processoId: "prc-aprovacao", statusId: "st-cliente", nome: "Aprovação do escopo com o cliente", responsavel: "Comercial", inicioPrev: "2026-10-21", fimPrev: "2026-10-28", inicioReal: "", fimReal: "", progresso: 20, observacoes: "Aguardando retorno da engenharia do cliente." },
    { id: "sch-4", projetoId: "prj-cftv", processoId: "prc-infra", statusId: "st-nao", nome: "Infraestrutura metálica e eletrodutos", responsavel: "Campo", inicioPrev: "2026-11-03", fimPrev: "2026-11-14", inicioReal: "", fimReal: "", progresso: 0, observacoes: "", dependeDe: ["sch-3"] },
    { id: "sch-5", projetoId: "prj-cftv", processoId: "prc-cabo", statusId: "st-nao", nome: "Lançamento de UTP e fibra", responsavel: "Campo", inicioPrev: "2026-11-10", fimPrev: "2026-11-21", inicioReal: "", fimReal: "", progresso: 0, observacoes: "", dependeDe: ["sch-4"] },
    { id: "sch-6", projetoId: "prj-cftv", processoId: "prc-com", statusId: "st-nao", nome: "Comissionamento e As Built", responsavel: "Rogério", inicioPrev: "2026-11-24", fimPrev: "2026-11-28", inicioReal: "", fimReal: "", progresso: 0, observacoes: "", dependeDe: ["sch-5"] },
  ];
}

function normalizeProducts(products: Product[]): Product[] {
  return products.map((product) => {
    const foto = product.foto ?? "";
    const componentes = product.componentes ?? [];
    const descricao = product.id === "prd-kit-rack" && product.descricao === "Kit rack 12U" ? "Rack indoor" : product.descricao;
    if (product.foto === foto && product.componentes && product.descricao === descricao) return product;
    return { ...product, foto, componentes, descricao };
  });
}

export const useCrm = create<State>()(
  persist(
    (set, get) => ({
      initialized: false,
      view: "painel",
      suppliers: [],
      products: [],
      services: [],
      clients: [],
      projects: [],
      proposals: [],
      processes: defaultProcesses(),
      statuses: defaultStatuses(),
      schedule: [],
      moves: [],
      assets: [],
      encargos: defaultEncargos(),
      vinculos: defaultVinculos(),
      pessoas: [],
      alocacoes: [],
      docs: [],
      eventos: [],
      usuarios: defaultUsuarios(),
      taxas: defaultTaxas(),
      mensagens: [],
      rdos: [],
      currentUserId: "",
      query: "",
      dataDe: "",
      dataAte: "",
      warehouseProposalId: "",
      draft: emptyDraft(),
      notice: "",
      gruposMigrados: false,
      setView: (view) => set({ view, notice: "" }),
      setNotice: (notice) => set({ notice }),
      setQuery: (query) => set({ query }),
      setPeriodo: (dataDe, dataAte) => set({ dataDe, dataAte }),
      seedIfEmpty: () => {
        const s = get();
        const services = s.services.map((sv) =>
          sv.nivel ? sv : { ...sv, nivel: sv.id === "srv-cam" ? (2 as const) : (1 as const) },
        );
        let products = normalizeProducts(s.products);
        if (!s.gruposMigrados && !products.some((product) => product.tipo === "grupo")) {
          const ids = new Set(products.map((product) => product.id));
          if (ids.has("prd-rack") && ids.has("prd-sw") && ids.has("prd-ups")) {
            products = [
              ...products,
              {
                id: "prd-kit-rack",
                codigo: "KIT-RACK",
                descricao: "Rack indoor",
                fabricante: "",
                unidade: "CJ",
                categoria: "Racks e Organização",
                fornecedorId: "",
                custo: 4250,
                tipo: "grupo" as const,
                foto: "",
                componentes: [
                  { productId: "prd-rack", qtd: 1 },
                  { productId: "prd-sw", qtd: 1 },
                  { productId: "prd-ups", qtd: 1 },
                ],
              },
            ];
          }
        }
        const patchedServices = services.some((sv, index) => sv !== s.services[index]);
        const patchedProducts = products.some((product, index) => product !== s.products[index]) || products.length !== s.products.length;
        const patch = {
          ...(patchedServices ? { services } : {}),
          ...(patchedProducts ? { products } : {}),
          ...(!s.gruposMigrados ? { gruposMigrados: true } : {}),
          ...(s.processes.length === 0 ? { processes: defaultProcesses() } : {}),
          ...(s.statuses.length === 0 ? { statuses: defaultStatuses() } : {}),
          ...((s.encargos ?? []).length === 0 ? { encargos: defaultEncargos() } : {}),
          ...((s.vinculos ?? []).length === 0 ? { vinculos: defaultVinculos() } : {}),
          ...(s.docs == null ? { docs: [] } : {}),
          ...(s.eventos == null ? { eventos: [] } : {}),
          ...(s.alocacoes == null ? { alocacoes: [] } : {}),
          ...((s.usuarios ?? []).length === 0 ? { usuarios: defaultUsuarios() } : {}),
          ...((s.taxas ?? []).length === 0 ? { taxas: defaultTaxas() } : {}),
          ...(s.mensagens == null ? { mensagens: [] } : {}),
          ...(s.rdos == null ? { rdos: [] } : {}),
        };
        if (s.initialized) {
          if (Object.keys(patch).length > 0) set(patch);
          return;
        }
        const empty =
          s.suppliers.length + s.products.length + s.services.length + s.clients.length + s.projects.length + s.proposals.length ===
          0;
        if (!empty) {
          set({ initialized: true, ...patch });
          return;
        }
        set({ ...seedBundle(), initialized: true, gruposMigrados: true, processes: defaultProcesses(), statuses: defaultStatuses(), schedule: sampleSchedule() });
      },
      upsertSupplier: (row) =>
        set((s) => ({
          suppliers: s.suppliers.some((x) => x.id === row.id)
            ? s.suppliers.map((x) => (x.id === row.id ? row : x))
            : [row, ...s.suppliers],
        })),
      removeSupplier: (id) => set((s) => ({ suppliers: s.suppliers.filter((x) => x.id !== id) })),
      upsertProduct: (row) =>
        set((s) => ({
          products: s.products.some((x) => x.id === row.id)
            ? s.products.map((x) => (x.id === row.id ? row : x))
            : [row, ...s.products],
        })),
      removeProduct: (id) =>
        set((s) => ({
          products: s.products
            .filter((product) => product.id !== id)
            .map((product) =>
              product.tipo === "grupo"
                ? { ...product, componentes: (product.componentes ?? []).filter((item) => item.productId !== id) }
                : product,
            ),
        })),
      upsertService: (row) =>
        set((s) => ({
          services: s.services.some((x) => x.id === row.id)
            ? s.services.map((x) => (x.id === row.id ? row : x))
            : [row, ...s.services],
        })),
      removeService: (id) => set((s) => ({ services: s.services.filter((x) => x.id !== id) })),
      upsertClient: (row) =>
        set((s) => ({
          clients: s.clients.some((x) => x.id === row.id)
            ? s.clients.map((x) => (x.id === row.id ? row : x))
            : [row, ...s.clients],
        })),
      removeClient: (id) => set((s) => ({ clients: s.clients.filter((x) => x.id !== id) })),
      upsertProject: (row) =>
        set((s) => ({
          projects: s.projects.some((x) => x.id === row.id)
            ? s.projects.map((x) => (x.id === row.id ? row : x))
            : [row, ...s.projects],
        })),
      removeProject: (id) => set((s) => ({ projects: s.projects.filter((x) => x.id !== id) })),
      patchDraft: (patch) => set((s) => ({ draft: { ...s.draft, ...patch } })),
      addProductLine: (productId, qtd, justificativa) => {
        const product = get().products.find((p) => p.id === productId);
        if (!product || qtd <= 0) return;
        const margem = get().draft.margem;
        const kits = round2(qtd);
        if (product.tipo === "grupo") {
          const grupoId = uid();
          const filhos = (product.componentes ?? []).flatMap((comp) => {
            const origem = get().products.find((item) => item.id === comp.productId);
            if (!origem || origem.tipo === "grupo" || comp.qtd <= 0) return [];
            const base = round2(comp.qtd);
            return [
              {
                id: uid(),
                origemId: origem.id,
                tipo: "produto" as const,
                secao: origem.categoria,
                codigo: origem.codigo,
                descricao: origem.descricao,
                fabricante: origem.fabricante,
                qtd: round2(base * kits),
                qtdBase: base,
                unidade: origem.unidade,
                custo: origem.custo,
                margem,
                justificativa,
                hhBase: 0,
                nivel: 0,
                hh: 0,
                grupoId,
                grupoNome: product.descricao,
                cabecalho: false,
              },
            ];
          });
          if (filhos.length === 0) return;
          const header = {
            id: grupoId,
            origemId: product.id,
            tipo: "produto" as const,
            secao: product.categoria,
            codigo: product.codigo,
            descricao: product.descricao,
            fabricante: product.fabricante,
            qtd: kits,
            unidade: product.unidade || "CJ",
            custo: 0,
            margem,
            justificativa,
            hhBase: 0,
            nivel: 0,
            hh: 0,
            grupoId,
            grupoNome: product.descricao,
            cabecalho: true,
          };
          set((s) => ({
            draft: { ...s.draft, itens: [...s.draft.itens, header, ...filhos] },
          }));
          return;
        }
        set((s) => ({
          draft: {
            ...s.draft,
            itens: [
              ...s.draft.itens,
              {
                id: uid(),
                origemId: product.id,
                tipo: "produto" as const,
                secao: product.categoria,
                codigo: product.codigo,
                descricao: product.descricao,
                fabricante: product.fabricante,
                qtd: kits,
                unidade: product.unidade,
                custo: product.custo,
                margem,
                justificativa,
                hhBase: 0,
                nivel: 0,
                hh: 0,
              },
            ],
          },
        }));
      },
      addToGroup: (grupoId, productId, qtd) => {
        const product = get().products.find((item) => item.id === productId);
        const header = get().draft.itens.find((line) => line.grupoId === grupoId && line.cabecalho);
        if (!product || product.tipo === "grupo" || !header || qtd <= 0) return;
        const kits = header.qtd > 0 ? header.qtd : 1;
        const quantidade = round2(qtd);
        set((s) => {
          const atual = s.draft.itens.find(
            (line) => line.grupoId === grupoId && !line.cabecalho && line.origemId === product.id,
          );
          if (atual) {
            const qtdNova = round2(atual.qtd + quantidade);
            return {
              draft: {
                ...s.draft,
                itens: s.draft.itens.map((line) =>
                  line.id === atual.id ? { ...line, qtd: qtdNova, qtdBase: round2(qtdNova / kits) } : line,
                ),
              },
            };
          }
          return {
            draft: {
              ...s.draft,
              itens: [
                ...s.draft.itens,
                {
                  id: uid(),
                  origemId: product.id,
                  tipo: "produto" as const,
                  secao: product.categoria,
                  codigo: product.codigo,
                  descricao: product.descricao,
                  fabricante: product.fabricante,
                  qtd: quantidade,
                  qtdBase: round2(quantidade / kits),
                  unidade: product.unidade,
                  custo: product.custo,
                  margem: header.margem,
                  justificativa: "",
                  hhBase: 0,
                  nivel: 0,
                  hh: 0,
                  grupoId,
                  grupoNome: header.descricao,
                  cabecalho: false,
                },
              ],
            },
          };
        });
      },
      setGroupQty: (grupoId, qtd) => {
        const kits = round2(qtd);
        if (kits <= 0) return;
        set((s) => ({
          draft: {
            ...s.draft,
            itens: s.draft.itens.map((line) => {
              if (line.grupoId !== grupoId) return line;
              if (line.cabecalho) return { ...line, qtd: kits };
              const base = line.qtdBase ?? line.qtd;
              return { ...line, qtdBase: base, qtd: round2(base * kits) };
            }),
          },
        }));
      },
      removeGroup: (grupoId) =>
        set((s) => ({
          draft: { ...s.draft, itens: s.draft.itens.filter((line) => line.grupoId !== grupoId) },
        })),
      addServiceLine: (serviceId, qtd, justificativa, nivel) => {
        const service = get().services.find((p) => p.id === serviceId);
        if (!service || qtd <= 0) return;
        const margem = get().draft.margem;
        const nivelLinha = normalizeNivel(nivel || service.nivel);
        const quantidade = round2(qtd);
        set((s) => ({
          draft: {
            ...s.draft,
            itens: [
              ...s.draft.itens,
              {
                id: uid(),
                origemId: service.id,
                tipo: "servico",
                secao: service.categoria || "Serviços",
                codigo: service.codigo,
                descricao: service.descricao,
                fabricante: "",
                qtd: quantidade,
                unidade: service.unidade,
                custo: service.custo,
                margem,
                justificativa,
                hhBase: service.hhBase,
                nivel: nivelLinha,
                hh: hhFinal(service.hhBase, quantidade, nivelLinha),
              },
            ],
          },
        }));
      },
      patchLine: (id, patch) =>
        set((s) => ({
          draft: {
            ...s.draft,
            itens: s.draft.itens.map((line) => {
              if (line.id !== id) return line;
              const next = { ...line, ...patch };
              if (next.tipo === "servico" && (patch.qtd != null || patch.nivel != null)) {
                next.nivel = normalizeNivel(next.nivel);
                const base = next.hhBase || s.services.find((sv) => sv.id === line.origemId)?.hhBase || 0;
                next.hhBase = base;
                next.hh = hhFinal(base, next.qtd, next.nivel);
              }
              if (patch.qtd != null && next.grupoId && !next.cabecalho) {
                const header = s.draft.itens.find((item) => item.grupoId === next.grupoId && item.cabecalho);
                const kits = header && header.qtd > 0 ? header.qtd : 1;
                next.qtdBase = round2(next.qtd / kits);
              }
              return next;
            }),
          },
        })),
      removeLine: (id) =>
        set((s) => {
          const alvo = s.draft.itens.find((line) => line.id === id);
          let itens = s.draft.itens.filter((line) => line.id !== id);
          if (alvo?.grupoId && !alvo.cabecalho && !itens.some((line) => line.grupoId === alvo.grupoId && !line.cabecalho)) {
            itens = itens.filter((line) => line.grupoId !== alvo.grupoId);
          }
          return { draft: { ...s.draft, itens } };
        }),
      applyMarginAll: () =>
        set((s) => ({
          draft: {
            ...s.draft,
            itens: s.draft.itens.map((l) => ({ ...l, margem: s.draft.margem })),
          },
        })),
      newDraft: () => set({ draft: emptyDraft(), view: "proposta", notice: "" }),
      loadProposal: (id) => {
        const proposal = get().proposals.find((p) => p.id === id);
        if (!proposal) return;
        set({
          view: "proposta",
          notice: "",
          draft: {
            id: proposal.id,
            titulo: proposal.titulo,
            clienteId: proposal.clienteId,
            projetoId: proposal.projetoId,
            status: proposal.status,
            margem: proposal.margem,
            observacoes: proposal.observacoes,
            itens: proposal.itens.map((i) => ({ ...i })),
          },
        });
      },
      saveProposal: () => {
        const { draft } = get();
        const titulo = draft.titulo.trim();
        if (!titulo) return "Informe o título da proposta.";
        if (draft.itens.length === 0) return "Inclua ao menos um item.";
        const saved: Proposal = {
          id: draft.id ?? uid(),
          titulo,
          clienteId: draft.clienteId,
          projetoId: draft.projetoId,
          status: draft.status,
          margem: draft.margem,
          observacoes: draft.observacoes.trim(),
          data: new Date().toISOString(),
          itens: draft.itens.map((i) => ({ ...i })),
        };
        set((s) => ({
          proposals: s.proposals.some((p) => p.id === saved.id)
            ? s.proposals.map((p) => (p.id === saved.id ? saved : p))
            : [saved, ...s.proposals],
          draft: { ...s.draft, id: saved.id },
          notice: "Proposta salva neste navegador.",
          view: "historico",
          eventos: [
            {
              id: uid(),
              data: new Date().toISOString().slice(0, 10),
              autor: "Equipe",
              origem: "Proposta",
              texto: `Salvou a proposta ${saved.titulo}`,
              projetoId: saved.projetoId,
            },
            ...s.eventos,
          ],
        }));
        return null;
      },
      removeProposal: (id) =>
        set((s) => ({
          proposals: s.proposals.filter((p) => p.id !== id),
          draft: s.draft.id === id ? emptyDraft() : s.draft,
        })),
      duplicateProposal: (id) => {
        const proposal = get().proposals.find((p) => p.id === id);
        if (!proposal) return;
        const grupos = new Map<string, string>();
        for (const item of proposal.itens) {
          if (item.grupoId && !grupos.has(item.grupoId)) grupos.set(item.grupoId, uid());
        }
        const copy: Proposal = {
          ...proposal,
          id: uid(),
          titulo: `${proposal.titulo} (cópia)`,
          status: "rascunho",
          data: new Date().toISOString(),
          itens: proposal.itens.map((item) => ({
            ...item,
            id: uid(),
            grupoId: item.grupoId ? grupos.get(item.grupoId) : undefined,
          })),
        };
        set((s) => ({ proposals: [copy, ...s.proposals], notice: "Cópia criada como rascunho." }));
      },
      upsertProcess: (row) =>
        set((s) => ({
          processes: s.processes.some((x) => x.id === row.id)
            ? s.processes.map((x) => (x.id === row.id ? row : x))
            : [...s.processes, row],
        })),
      removeProcess: (id) =>
        set((s) => ({
          processes: s.processes.filter((x) => x.id !== id),
          schedule: s.schedule.map((item) => (item.processoId === id ? { ...item, processoId: "" } : item)),
        })),
      upsertStatus: (row) =>
        set((s) => ({
          statuses: s.statuses.some((x) => x.id === row.id)
            ? s.statuses.map((x) => (x.id === row.id ? row : x))
            : [...s.statuses, row],
        })),
      removeStatus: (id) =>
        set((s) => ({
          statuses: s.statuses.filter((x) => x.id !== id),
          schedule: s.schedule.map((item) => (item.statusId === id ? { ...item, statusId: "" } : item)),
        })),
      upsertSchedule: (row) =>
        set((s) => ({
          schedule: s.schedule.some((x) => x.id === row.id)
            ? s.schedule.map((x) => (x.id === row.id ? row : x))
            : [row, ...s.schedule],
          eventos: s.schedule.some((x) => x.id === row.id)
            ? s.eventos
            : [
                {
                  id: uid(),
                  data: row.inicioPrev || new Date().toISOString().slice(0, 10),
                  autor: row.responsavel || "Equipe",
                  origem: "Prazo",
                  texto: `Criou a demanda ${row.nome}`,
                  projetoId: row.projetoId,
                },
                ...s.eventos,
              ],
        })),
      removeSchedule: (id) => set((s) => ({ schedule: s.schedule.filter((x) => x.id !== id) })),
      openWarehouse: (proposalId) => set({ warehouseProposalId: proposalId, view: "almoxarifado", notice: "" }),
      addMove: (row) => {
        const s = get();
        const qtd = Math.abs(row.qtd);
        if (qtd <= 0) return;
        const proposal = s.proposals.find((p) => p.id === row.proposalId);
        const line = proposal ? materialLines(proposal).find((l) => l.id === row.lineId) : undefined;
        const atual = stockOf(row.lineId, s.moves.filter((m) => m.proposalId === row.proposalId));
        if (row.tipo === "entrada" && line && atual.recebido + qtd > line.qtd + 0.001) {
          set({ notice: "Entrada acima do previsto. O material previsto não pode ficar negativo." });
          return;
        }
        if ((row.tipo === "saida" || row.tipo === "devolucao") && atual.saldo + 0.001 < qtd) {
          set({ notice: "Saída maior que o saldo. O estoque não fica negativo." });
          return;
        }
        const evento: Evento = {
          id: uid(),
          data: row.data,
          autor: row.responsavel || "Equipe",
          origem: "Almoxarifado",
          texto: `${row.tipo === "entrada" ? "Recebeu" : row.tipo === "saida" ? "Aplicou" : row.tipo === "devolucao" ? "Devolveu" : "Ajustou"} ${qtd} de ${line?.descricao ?? "item"}`,
          projetoId: proposal?.projetoId ?? "",
        };
        set((state) => ({
          moves: [{ ...row, qtd }, ...state.moves],
          eventos: [evento, ...state.eventos],
          notice: "",
        }));
      },
      removeMove: (id) => set((s) => ({ moves: s.moves.filter((m) => m.id !== id) })),
      upsertAsset: (row) =>
        set((s) => ({
          assets: s.assets.some((x) => x.id === row.id) ? s.assets.map((x) => (x.id === row.id ? row : x)) : [row, ...s.assets],
        })),
      removeAsset: (id) => set((s) => ({ assets: s.assets.filter((x) => x.id !== id) })),
      upsertEncargo: (row) =>
        set((s) => ({
          encargos: s.encargos.some((x) => x.id === row.id) ? s.encargos.map((x) => (x.id === row.id ? row : x)) : [...s.encargos, row],
        })),
      removeEncargo: (id) =>
        set((s) => ({
          encargos: s.encargos.filter((x) => x.id !== id),
          vinculos: s.vinculos.map((v) => ({ ...v, encargoIds: v.encargoIds.filter((e) => e !== id) })),
        })),
      upsertVinculo: (row) =>
        set((s) => ({
          vinculos: s.vinculos.some((x) => x.id === row.id) ? s.vinculos.map((x) => (x.id === row.id ? row : x)) : [...s.vinculos, row],
        })),
      removeVinculo: (id) =>
        set((s) => ({
          vinculos: s.vinculos.filter((x) => x.id !== id),
          pessoas: s.pessoas.map((p) => (p.vinculoId === id ? { ...p, vinculoId: "" } : p)),
        })),
      upsertPessoa: (row) =>
        set((s) => ({
          pessoas: s.pessoas.some((x) => x.id === row.id) ? s.pessoas.map((x) => (x.id === row.id ? row : x)) : [row, ...s.pessoas],
        })),
      removePessoa: (id) =>
        set((s) => ({
          pessoas: s.pessoas.filter((x) => x.id !== id),
          alocacoes: s.alocacoes.filter((a) => a.pessoaId !== id),
        })),
      upsertAlocacao: (row) =>
        set((s) => ({
          alocacoes: s.alocacoes.some((x) => x.id === row.id)
            ? s.alocacoes.map((x) => (x.id === row.id ? row : x))
            : [row, ...s.alocacoes],
          eventos: [
            {
              id: uid(),
              data: row.inicio || new Date().toISOString().slice(0, 10),
              autor: "Equipe",
              origem: "Pessoal",
              texto: `Alocou na obra`,
              projetoId: row.projetoId,
            },
            ...s.eventos,
          ],
        })),
      removeAlocacao: (id) => set((s) => ({ alocacoes: s.alocacoes.filter((x) => x.id !== id) })),
      upsertDoc: (row) =>
        set((s) => ({
          docs: s.docs.some((x) => x.id === row.id) ? s.docs.map((x) => (x.id === row.id ? row : x)) : [row, ...s.docs],
          eventos: [
            { id: uid(), data: row.data, autor: row.autor || "Equipe", origem: "Documento", texto: `Anexou ${row.nome}`, projetoId: row.projetoId },
            ...s.eventos,
          ],
        })),
      removeDoc: (id) => set((s) => ({ docs: s.docs.filter((x) => x.id !== id) })),
      logEvento: (row) => set((s) => ({ eventos: [{ ...row, id: uid() }, ...s.eventos] })),
      login: (email, senha) => {
        const user = get().usuarios.find(
          (u) => u.ativo && u.email.toLowerCase() === email.trim().toLowerCase() && u.senha === senha,
        );
        if (!user) return "E-mail ou senha inválidos.";
        set({ currentUserId: user.id, notice: "" });
        return null;
      },
      logout: () => set({ currentUserId: "", view: "painel" }),
      upsertUsuario: (row) =>
        set((s) => ({
          usuarios: s.usuarios.some((x) => x.id === row.id) ? s.usuarios.map((x) => (x.id === row.id ? row : x)) : [row, ...s.usuarios],
        })),
      removeUsuario: (id) => set((s) => ({ usuarios: s.usuarios.filter((x) => x.id !== id) })),
      upsertTaxa: (row) =>
        set((s) => ({
          taxas: s.taxas.some((x) => x.id === row.id) ? s.taxas.map((x) => (x.id === row.id ? row : x)) : [row, ...s.taxas],
        })),
      removeTaxa: (id) => set((s) => ({ taxas: s.taxas.filter((x) => x.id !== id) })),
      upsertMensagem: (row) =>
        set((s) => ({
          mensagens: s.mensagens.some((x) => x.id === row.id)
            ? s.mensagens.map((x) => (x.id === row.id ? row : x))
            : [row, ...s.mensagens],
        })),
      removeMensagem: (id) => set((s) => ({ mensagens: s.mensagens.filter((x) => x.id !== id) })),
      upsertRdo: (row) =>
        set((s) => ({
          rdos: s.rdos.some((x) => x.id === row.id) ? s.rdos.map((x) => (x.id === row.id ? row : x)) : [row, ...s.rdos],
          eventos: [
            {
              id: uid(),
              data: row.data,
              autor: row.responsavel || "Equipe",
              origem: "RDO",
              texto: `RDO ${row.numero} ${row.status === "assinado" ? "assinado" : "salvo"}`,
              projetoId: row.projetoId,
            },
            ...s.eventos,
          ],
        })),
      removeRdo: (id) => set((s) => ({ rdos: s.rdos.filter((x) => x.id !== id) })),
    }),
    { name: "ausec-crm-v1", skipHydration: true },
  ),
);

export function proposalTotals(itens: Draft["itens"]) {
  const linhas = itens.filter((line) => !line.cabecalho);
  const custo = round2(linhas.reduce((acc, line) => acc + line.custo * line.qtd, 0));
  const venda = round2(linhas.reduce((acc, line) => acc + lineTotal(line), 0));
  const hh = round2(linhas.reduce((acc, line) => acc + line.hh, 0));
  return { custo, venda, margemValor: round2(venda - custo), hh, preco: precoUnit };
}
