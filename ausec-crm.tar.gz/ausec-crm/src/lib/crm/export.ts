import { fatorLabel, labelStatusProposta, lineTotal, precoUnit, type Client, type Proposal, type Project } from "./model";

function cell(value: string | number): string {
  return `"${String(value).replaceAll('"', '""')}"`;
}

export function proposalCsv(proposal: Proposal, client?: Client, project?: Project): string {
  const header = [
    "Seção",
    "Item",
    "Descrição",
    "Fabricante",
    "Qtd",
    "Und",
    "Justificativa",
    "Custo unit.",
    "Margem %",
    "Preço unit.",
    "Total",
    "HH base",
    "Nível",
    "Fator",
    "HH final",
  ];
  const lines = [
    ["Proposta", proposal.titulo],
    ["Cliente", client?.nome ?? ""],
    ["Projeto", project?.nome ?? ""],
    ["Status", labelStatusProposta(proposal.status)],
    ["Data", new Date(proposal.data).toLocaleString("pt-BR")],
    [],
    header,
    ...proposal.itens.filter((item) => !item.cabecalho).map((item) => [
      item.secao,
      item.codigo,
      item.grupoNome ? `${item.grupoNome} · ${item.descricao}` : item.descricao,
      item.fabricante,
      item.qtd,
      item.unidade,
      item.justificativa,
      item.custo,
      item.margem,
      precoUnit(item.custo, item.margem),
      lineTotal(item),
      item.tipo === "servico" ? item.hhBase || "" : "",
      item.tipo === "servico" ? item.nivel || "" : "",
      item.tipo === "servico" ? fatorLabel(item.nivel) : "",
      item.hh,
    ]),
  ];
  return `\uFEFF${lines.map((row) => row.map(cell).join(";")).join("\r\n")}`;
}

export function downloadText(filename: string, content: string, type: string) {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  URL.revokeObjectURL(url);
}
