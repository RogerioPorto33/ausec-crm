export type Supplier = {
  id: string;
  nome: string;
  contato: string;
  email: string;
  telefone: string;
  cnpj: string;
  observacoes: string;
};

export type ComponenteGrupo = {
  productId: string;
  qtd: number;
};

export type Product = {
  id: string;
  codigo: string;
  descricao: string;
  fabricante: string;
  unidade: string;
  categoria: string;
  fornecedorId: string;
  custo: number;
  tipo: "produto" | "equipamento" | "grupo";
  foto?: string;
  componentes?: ComponenteGrupo[];
};

export type ServiceRec = {
  id: string;
  codigo: string;
  descricao: string;
  unidade: string;
  categoria: string;
  hhBase: number;
  nivel: NivelCriticidade;
  custo: number;
};

export type NivelCriticidade = 1 | 2 | 3 | 4;

export const NIVEIS: { nivel: NivelCriticidade; fator: number; descricao: string }[] = [
  { nivel: 1, fator: 1, descricao: "Acesso fácil, solo, sem interferência" },
  { nivel: 2, fator: 1.15, descricao: "Altura até 4 m ou acesso moderado" },
  { nivel: 3, fator: 1.3, descricao: "Altura > 4 m, PTA, espaço confinado ou interferência operacional relevante" },
  { nivel: 4, fator: 1.45, descricao: "Combinação de dois ou mais fatores de dificuldade" },
];

export function normalizeNivel(value: unknown): NivelCriticidade {
  const n = Number(value);
  if (n === 2 || n === 3 || n === 4) return n;
  return 1;
}

export function fatorNivel(nivel: number): number {
  return NIVEIS.find((item) => item.nivel === normalizeNivel(nivel))?.fator ?? 1;
}

export function fatorLabel(nivel: number): string {
  return fatorNivel(nivel).toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

/** HH final = teto de (HH base × qtd × fator do nível × 1,10). */
export function hhFinal(hhBase: number, qtd: number, nivel: number): number {
  const raw = hhBase * qtd * fatorNivel(nivel) * 1.1;
  if (!Number.isFinite(raw) || raw <= 0) return 0;
  const stable = Math.round(raw * 10000) / 10000;
  return Math.ceil(stable - 1e-6);
}

export type Client = {
  id: string;
  nome: string;
  contato: string;
  email: string;
  telefone: string;
  cidade: string;
  estado: string;
};

export type ProjectStatus = "em_analise" | "proposta" | "aprovado" | "concluido";

export type Project = {
  id: string;
  clienteId: string;
  nome: string;
  descricao: string;
  status: ProjectStatus;
};

export type ProposalStatus = "rascunho" | "enviada" | "aprovada" | "recusada";

export type Line = {
  id: string;
  origemId: string;
  tipo: "produto" | "servico";
  secao: string;
  codigo: string;
  descricao: string;
  fabricante: string;
  qtd: number;
  unidade: string;
  custo: number;
  margem: number;
  justificativa: string;
  hhBase: number;
  nivel: number;
  hh: number;
  grupoId?: string;
  grupoNome?: string;
  cabecalho?: boolean;
  qtdBase?: number;
};

export type Proposal = {
  id: string;
  titulo: string;
  clienteId: string;
  projetoId: string;
  status: ProposalStatus;
  margem: number;
  observacoes: string;
  data: string;
  itens: Line[];
};

export type Draft = {
  id: string | null;
  titulo: string;
  clienteId: string;
  projetoId: string;
  status: ProposalStatus;
  margem: number;
  observacoes: string;
  itens: Line[];
};

export const CATEGORIAS = [
  "Infraestrutura Metálica",
  "Cabeamento Estruturado e Óptico",
  "Racks e Organização",
  "Ativos / Switching",
  "Energia / Nobreak",
  "Câmeras e Fixação",
  "Complementares",
  "Serviços",
] as const;

export const UNIDADES = ["UND", "MT", "M²", "M³", "CJ", "PCT", "KG", "LIC", "DIA", "SV", "HH"] as const;

export const STATUS_PROJETO: { id: ProjectStatus; label: string }[] = [
  { id: "em_analise", label: "Em análise" },
  { id: "proposta", label: "Proposta" },
  { id: "aprovado", label: "Aprovado" },
  { id: "concluido", label: "Concluído" },
];

export const STATUS_PROPOSTA: { id: ProposalStatus; label: string }[] = [
  { id: "rascunho", label: "Rascunho" },
  { id: "enviada", label: "Enviada" },
  { id: "aprovada", label: "Aprovada" },
  { id: "recusada", label: "Recusada" },
];

export function uid(): string {
  return crypto.randomUUID();
}

export function round2(n: number): number {
  return Math.round((Number.isFinite(n) ? n : 0) * 100) / 100;
}

export function custoDeGrupo(grupo: Product, products: Product[]): number {
  return round2(
    (grupo.componentes ?? []).reduce((acc, item) => {
      const product = products.find((entry) => entry.id === item.productId);
      if (!product || product.tipo === "grupo") return acc;
      return acc + product.custo * item.qtd;
    }, 0),
  );
}

export function precoUnit(custo: number, margem: number): number {
  return round2(custo * (1 + margem / 100));
}

export function lineTotal(line: Line): number {
  return round2(precoUnit(line.custo, line.margem) * line.qtd);
}

export function lineCost(line: Line): number {
  return round2(line.custo * line.qtd);
}

export function brl(n: number): string {
  return n.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

export function emptyDraft(): Draft {
  return {
    id: null,
    titulo: "",
    clienteId: "",
    projetoId: "",
    status: "rascunho",
    margem: 30,
    observacoes: "",
    itens: [],
  };
}

export function labelStatusProposta(id: ProposalStatus): string {
  return STATUS_PROPOSTA.find((s) => s.id === id)?.label ?? id;
}

export function labelStatusProjeto(id: ProjectStatus): string {
  return STATUS_PROJETO.find((s) => s.id === id)?.label ?? id;
}

export type StatusTom = "ok" | "warn" | "danger" | "muted" | "primary";

export type ProcessRec = {
  id: string;
  nome: string;
  ordem: number;
};

export type StatusRec = {
  id: string;
  nome: string;
  tom: StatusTom;
  ordem: number;
  encerra: boolean;
};

export type ScheduleItem = {
  id: string;
  projetoId: string;
  processoId: string;
  statusId: string;
  nome: string;
  responsavel: string;
  inicioPrev: string;
  fimPrev: string;
  inicioReal: string;
  fimReal: string;
  progresso: number;
  observacoes: string;
  dependeDe?: string[];
};

export const STATUS_TONS: { id: StatusTom; label: string }[] = [
  { id: "muted", label: "Neutro" },
  { id: "primary", label: "Em curso" },
  { id: "warn", label: "Atenção" },
  { id: "danger", label: "Crítico" },
  { id: "ok", label: "Concluído" },
];

export function defaultProcesses(): ProcessRec[] {
  return [
    { id: "prc-vistoria", nome: "Levantamento / vistoria", ordem: 1 },
    { id: "prc-projeto", nome: "Projeto executivo", ordem: 2 },
    { id: "prc-aprovacao", nome: "Aprovação do cliente", ordem: 3 },
    { id: "prc-mobilizacao", nome: "Mobilização", ordem: 4 },
    { id: "prc-infra", nome: "Infraestrutura", ordem: 5 },
    { id: "prc-cabo", nome: "Cabeamento", ordem: 6 },
    { id: "prc-ativos", nome: "Ativos e racks", ordem: 7 },
    { id: "prc-com", nome: "Comissionamento", ordem: 8 },
    { id: "prc-asbuilt", nome: "As Built / entrega", ordem: 9 },
  ];
}

export function defaultStatuses(): StatusRec[] {
  return [
    { id: "st-nao", nome: "Não iniciado", tom: "muted", ordem: 1, encerra: false },
    { id: "st-andamento", nome: "Em andamento", tom: "primary", ordem: 2, encerra: false },
    { id: "st-cliente", nome: "Aguardando cliente", tom: "warn", ordem: 3, encerra: false },
    { id: "st-material", nome: "Aguardando material", tom: "warn", ordem: 4, encerra: false },
    { id: "st-atrasado", nome: "Atrasado", tom: "danger", ordem: 5, encerra: false },
    { id: "st-parado", nome: "Paralisado", tom: "danger", ordem: 6, encerra: false },
    { id: "st-ok", nome: "Concluído", tom: "ok", ordem: 7, encerra: true },
  ];
}

export function todayIso(): string {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, "0");
  const d = String(now.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

export function parseIso(value: string): number | null {
  if (!value) return null;
  const time = Date.parse(`${value}T00:00:00`);
  return Number.isFinite(time) ? time : null;
}

export function formatIso(value: string): string {
  const time = parseIso(value);
  if (time == null) return "—";
  return new Date(time).toLocaleDateString("pt-BR");
}

export function itemAtrasado(item: ScheduleItem, status?: StatusRec): boolean {
  if (status?.encerra) return false;
  const fim = parseIso(item.fimPrev);
  if (fim == null) return false;
  const hoje = parseIso(todayIso());
  return hoje != null && fim < hoje;
}

export function dependenciasAbertas(item: ScheduleItem, itens: ScheduleItem[], statuses: StatusRec[]): ScheduleItem[] {
  return (item.dependeDe ?? [])
    .map((id) => itens.find((outro) => outro.id === id))
    .filter((outro): outro is ScheduleItem => Boolean(outro))
    .filter((outro) => !statuses.find((s) => s.id === outro.statusId)?.encerra);
}

export function itemBloqueado(item: ScheduleItem, itens: ScheduleItem[], statuses: StatusRec[]): boolean {
  return dependenciasAbertas(item, itens, statuses).length > 0;
}

export type MoveKind = "entrada" | "saida" | "devolucao" | "ajuste";

export type StockMove = {
  id: string;
  proposalId: string;
  lineId: string;
  tipo: MoveKind;
  qtd: number;
  data: string;
  responsavel: string;
  local: string;
  documento: string;
  observacoes: string;
};

export type AssetStatus = "em_estoque" | "em_uso" | "instalado" | "baixado";

export type AssetRec = {
  id: string;
  proposalId: string;
  lineId: string;
  patrimonio: string;
  serie: string;
  descricao: string;
  status: AssetStatus;
  local: string;
  responsavel: string;
  data: string;
};

export const MOVE_LABEL: Record<MoveKind, string> = {
  entrada: "Entrada",
  saida: "Saída / aplicação",
  devolucao: "Devolução",
  ajuste: "Ajuste",
};

export const ASSET_STATUS: { id: AssetStatus; label: string }[] = [
  { id: "em_estoque", label: "Em estoque" },
  { id: "em_uso", label: "Em uso" },
  { id: "instalado", label: "Instalado" },
  { id: "baixado", label: "Baixado" },
];

export function materialLines(proposal: Proposal): Line[] {
  return proposal.itens.filter((line) => !line.cabecalho && line.tipo !== "servico");
}

export function stockOf(lineId: string, moves: StockMove[]) {
  const of = moves.filter((m) => m.lineId === lineId);
  const sum = (tipo: MoveKind) => of.filter((m) => m.tipo === tipo).reduce((acc, m) => acc + Math.max(0, m.qtd), 0);
  const recebido = sum("entrada");
  const aplicado = sum("saida");
  const devolvido = sum("devolucao");
  const ajuste = of.filter((m) => m.tipo === "ajuste").reduce((acc, m) => acc + m.qtd, 0);
  return {
    recebido: round2(recebido),
    aplicado: round2(aplicado),
    devolvido: round2(devolvido),
    ajuste: round2(ajuste),
    saldo: round2(Math.max(0, recebido - aplicado - devolvido + ajuste)),
  };
}

export function aReceber(previsto: number, recebido: number): number {
  return round2(Math.max(0, previsto - recebido));
}

export type DocTipo = "contrato" | "nota" | "projeto" | "pdf" | "outro";

export type DocRec = {
  id: string;
  projetoId: string;
  proposalId: string;
  nome: string;
  tipo: DocTipo;
  data: string;
  autor: string;
  nomeArquivo: string;
  arquivo: string;
};

export type Evento = {
  id: string;
  data: string;
  autor: string;
  origem: string;
  texto: string;
  projetoId: string;
};

export const DOC_TIPOS: { id: DocTipo; label: string }[] = [
  { id: "contrato", label: "Contrato" },
  { id: "nota", label: "Nota fiscal" },
  { id: "projeto", label: "Projeto" },
  { id: "pdf", label: "PDF" },
  { id: "outro", label: "Outro" },
];

export type Encargo = {
  id: string;
  nome: string;
  percentual: number;
};

export type Vinculo = {
  id: string;
  nome: string;
  encargoIds: string[];
};

export type Pessoa = {
  id: string;
  nome: string;
  funcao: string;
  vinculoId: string;
  ativo: boolean;
};

export type Alocacao = {
  id: string;
  pessoaId: string;
  projetoId: string;
  funcao: string;
  inicio: string;
  fim: string;
};

export function defaultEncargos(): Encargo[] {
  return [
    { id: "enc-inss", nome: "INSS patronal", percentual: 20 },
    { id: "enc-fgts", nome: "FGTS", percentual: 8 },
    { id: "enc-13", nome: "13º", percentual: 8.33 },
    { id: "enc-ferias", nome: "Férias + 1/3", percentual: 11.11 },
    { id: "enc-sistema", nome: "Sistema S / terceiros", percentual: 5.8 },
    { id: "enc-rat", nome: "RAT", percentual: 2 },
  ];
}

export function defaultVinculos(): Vinculo[] {
  return [
    { id: "vin-clt", nome: "CLT", encargoIds: ["enc-inss", "enc-fgts", "enc-13", "enc-ferias", "enc-sistema", "enc-rat"] },
    { id: "vin-pj", nome: "PJ", encargoIds: [] },
    { id: "vin-estagio", nome: "Estágio", encargoIds: [] },
    { id: "vin-temp", nome: "Temporário", encargoIds: ["enc-inss", "enc-fgts", "enc-13", "enc-ferias"] },
    { id: "vin-autonomo", nome: "Autônomo", encargoIds: ["enc-inss"] },
  ];
}

export function somaEncargos(vinculo: Vinculo | undefined, encargos: Encargo[]): number {
  if (!vinculo) return 0;
  return round2(
    encargos.filter((e) => vinculo.encargoIds.includes(e.id)).reduce((acc, e) => acc + e.percentual, 0),
  );
}

export function custoPessoa(): number {
  return 0;
}

export type Papel = "admin" | "equipe";

export type Usuario = {
  id: string;
  nome: string;
  email: string;
  senha: string;
  papel: Papel;
  ativo: boolean;
};

export type TaxaTipo = "imposto" | "taxa" | "margem";

export type Taxa = {
  id: string;
  nome: string;
  percentual: number;
  tipo: TaxaTipo;
};

export type MensagemStatus = "rascunho" | "enviada";

export type Mensagem = {
  id: string;
  deId: string;
  paraIds: string[];
  assunto: string;
  corpo: string;
  data: string;
  status: MensagemStatus;
  lidaPor: string[];
};

export type RdoStatus = "rascunho" | "assinado";

export type Rdo = {
  id: string;
  projetoId: string;
  numero: number;
  data: string;
  turno: "manha" | "tarde" | "integral" | "noite";
  responsavel: string;
  registro: string;
  climaManha: string;
  climaTarde: string;
  praticavel: boolean;
  efetivo: string;
  atividades: string;
  materiais: string;
  equipamentos: string;
  ocorrencias: string;
  ddsTema: string;
  ddsParticipantes: string;
  fotos: string;
  pendencias: string;
  status: RdoStatus;
};

export function defaultUsuarios(): Usuario[] {
  return [
    { id: "usr-admin", nome: "Administrador", email: "admin@ausec.local", senha: "ausec", papel: "admin", ativo: true },
    { id: "usr-equipe", nome: "Equipe", email: "equipe@ausec.local", senha: "ausec", papel: "equipe", ativo: true },
  ];
}

export function defaultTaxas(): Taxa[] {
  return [
    { id: "tx-icms", nome: "ICMS", percentual: 18, tipo: "imposto" },
    { id: "tx-frete", nome: "Frete", percentual: 3, tipo: "taxa" },
    { id: "tx-adm", nome: "Administrativo", percentual: 8, tipo: "taxa" },
    { id: "tx-com", nome: "Comercial", percentual: 5, tipo: "taxa" },
    { id: "tx-mkp", nome: "Margem", percentual: 15, tipo: "margem" },
  ];
}

export function somaTaxas(taxas: Taxa[]): number {
  return round2(taxas.reduce((acc, t) => acc + t.percentual, 0));
}

export function precoComTaxas(custo: number, taxas: Taxa[]): number {
  const soma = somaTaxas(taxas);
  if (soma >= 100) return custo;
  return round2(custo / (1 - soma / 100));
}
