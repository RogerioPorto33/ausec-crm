import { useMemo, useState, type ReactNode } from "react";
import { Plus, Trash2 } from "lucide-react";
import { formatIso, todayIso, uid, type Mensagem } from "@/lib/crm/model";
import { useCrm } from "@/lib/crm/store";

const inputClass =
  "h-11 w-full rounded-md border border-line bg-surface px-3 text-sm text-ink outline-none focus:border-primary";

type Caixa = "recebidos" | "enviados" | "rascunhos";

export function Mensagens() {
  const mensagens = useCrm((s) => s.mensagens);
  const usuarios = useCrm((s) => s.usuarios);
  const me = useCrm((s) => s.currentUserId);
  const upsert = useCrm((s) => s.upsertMensagem);
  const remove = useCrm((s) => s.removeMensagem);
  const [caixa, setCaixa] = useState<Caixa>("recebidos");
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<Mensagem>(() => emptyMsg(me));
  const [lida, setLida] = useState<string | null>(null);

  const lista = useMemo(() => {
    return mensagens.filter((m) => {
      if (caixa === "rascunhos") return m.deId === me && m.status === "rascunho";
      if (caixa === "enviados") return m.deId === me && m.status === "enviada";
      return m.paraIds.includes(me) && m.status === "enviada";
    });
  }, [mensagens, caixa, me]);

  const nome = (id: string) => usuarios.find((u) => u.id === id)?.nome ?? "Usuário";

  return (
    <section>
      <div className="mb-5 flex items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Mensagens</h1>
          <p className="mt-1 text-sm text-muted">Marque @nome no texto. Quem for citado recebe a mensagem.</p>
        </div>
        <button type="button" onClick={() => { setForm(emptyMsg(me)); setOpen(true); }} className="inline-flex h-11 items-center gap-2 rounded-lg bg-primary px-4 text-sm font-semibold text-primary-fg">
          <Plus className="size-4" aria-hidden="true" />
          Nova
        </button>
      </div>
      <div className="mb-4 flex gap-2" role="tablist">
        {(
          [
            ["recebidos", "Recebidos"],
            ["enviados", "Enviados"],
            ["rascunhos", "Rascunhos"],
          ] as const
        ).map(([id, label]) => (
          <button key={id} type="button" role="tab" aria-selected={caixa === id} onClick={() => setCaixa(id)} className={"h-10 rounded-full px-4 text-sm font-medium " + (caixa === id ? "bg-primary text-primary-fg" : "bg-surface text-muted")}>
            {label}
          </button>
        ))}
      </div>
      {open ? (
        <Composer
          form={form}
          setForm={setForm}
          usuarios={usuarios}
          onClose={() => setOpen(false)}
          onSave={(status) => {
            const mencionados = usuarios.filter((u) => form.corpo.toLowerCase().includes(`@${u.nome.toLowerCase()}`)).map((u) => u.id);
            const para = Array.from(new Set([...form.paraIds, ...mencionados])).filter((id) => id && id !== me);
            if (status === "enviada" && para.length === 0) return;
            upsert({ ...form, paraIds: para, status, data: todayIso() });
            setOpen(false);
          }}
        />
      ) : null}
      {lista.length === 0 ? (
        <p className="text-sm text-muted">Nada nesta caixa.</p>
      ) : (
        <ul className="divide-y divide-line rounded-xl border border-line bg-surface">
          {lista.map((m) => (
            <li key={m.id}>
              <button type="button" onClick={() => { setLida(lida === m.id ? null : m.id); if (!m.lidaPor.includes(me)) upsert({ ...m, lidaPor: [...m.lidaPor, me] }); }} className="flex w-full items-start justify-between gap-3 px-4 py-3 text-left">
                <div>
                  <p className="font-medium">{m.assunto || "(sem assunto)"}</p>
                  <p className="text-xs text-muted">{caixa === "recebidos" ? nome(m.deId) : m.paraIds.map(nome).join(", ") || "sem destinatário"} · {formatIso(m.data)}</p>
                </div>
                <button type="button" onClick={(e) => { e.stopPropagation(); remove(m.id); }} className="text-danger" aria-label="Excluir"><Trash2 className="size-4" aria-hidden="true" /></button>
              </button>
              {lida === m.id ? <p className="px-4 pb-3 text-sm whitespace-pre-wrap">{m.corpo}</p> : null}
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}

function Composer({
  form,
  setForm,
  usuarios,
  onClose,
  onSave,
}: {
  form: Mensagem;
  setForm: (m: Mensagem) => void;
  usuarios: { id: string; nome: string }[];
  onClose: () => void;
  onSave: (status: Mensagem["status"]) => void;
}) {
  const [sugestao, setSugestao] = useState("");
  const opcoes = sugestao
    ? usuarios.filter((u) => u.nome.toLowerCase().includes(sugestao.toLowerCase()))
    : [];
  return (
    <article className="card mb-4 space-y-3 p-4">
      <Field label="Assunto"><input className={inputClass} value={form.assunto} onChange={(e) => setForm({ ...form, assunto: e.target.value })} /></Field>
      <Field label="Mensagem">
        <textarea
          className="min-h-28 w-full rounded-md border border-line bg-surface px-3 py-2 text-sm outline-none focus:border-primary"
          value={form.corpo}
          onChange={(e) => {
            const value = e.target.value;
            setForm({ ...form, corpo: value });
            const match = value.match(/@([\p{L}0-9 ]*)$/u);
            setSugestao(match ? match[1] : "");
          }}
          placeholder="Escreva e marque @nome"
        />
      </Field>
      {opcoes.length > 0 ? (
        <ul className="rounded-md border border-line bg-bg">
          {opcoes.map((u) => (
            <li key={u.id}>
              <button
                type="button"
                className="block w-full px-3 py-2 text-left text-sm hover:bg-surface"
                onClick={() => {
                  setForm({ ...form, corpo: form.corpo.replace(/@[\p{L}0-9 ]*$/u, `@${u.nome} `), paraIds: Array.from(new Set([...form.paraIds, u.id])) });
                  setSugestao("");
                }}
              >
                @{u.nome}
              </button>
            </li>
          ))}
        </ul>
      ) : null}
      <div className="flex gap-2">
        <button type="button" onClick={() => onSave("rascunho")} className="h-10 rounded-md border border-line px-3 text-sm">Salvar rascunho</button>
        <button type="button" onClick={() => onSave("enviada")} className="h-10 rounded-md bg-primary px-3 text-sm font-semibold text-primary-fg">Enviar</button>
        <button type="button" onClick={onClose} className="h-10 px-3 text-sm text-muted">Cancelar</button>
      </div>
    </article>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="block text-sm">
      <span className="mb-1 block font-medium">{label}</span>
      {children}
    </label>
  );
}

function emptyMsg(deId: string): Mensagem {
  return { id: uid(), deId, paraIds: [], assunto: "", corpo: "", data: todayIso(), status: "rascunho", lidaPor: [] };
}
