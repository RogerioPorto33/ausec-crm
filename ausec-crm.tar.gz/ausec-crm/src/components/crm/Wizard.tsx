import { useEffect, useState, type ReactNode } from "react";

export type WizardStep = {
  title: string;
  body: ReactNode;
  valid?: () => string | null;
};

export function Wizard({
  open,
  title,
  steps,
  onClose,
  onSave,
}: {
  open: boolean;
  title: string;
  steps: WizardStep[];
  onClose: () => void;
  onSave: () => string | null;
}) {
  const [step, setStep] = useState(0);
  const [error, setError] = useState("");
  const current = steps[Math.min(step, steps.length - 1)];
  const last = step >= steps.length - 1;

  useEffect(() => {
    if (open) {
      setStep(0);
      setError("");
    }
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open || !current) return null;

  function advance() {
    const message = current.valid?.() ?? null;
    if (message) {
      setError(message);
      return;
    }
    setError("");
    if (last) {
      const saveError = onSave();
      if (saveError) setError(saveError);
      return;
    }
    setStep((value) => value + 1);
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-ink/40 p-3 sm:items-center" role="presentation" onClick={onClose}>
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="wizard-title"
        className="flex max-h-[90vh] w-full max-w-xl flex-col rounded-2xl border border-line bg-surface shadow-xl"
        onClick={(event) => event.stopPropagation()}
      >
        <div className="border-b border-line px-5 pt-5 pb-4">
          <p className="font-mono text-xs tracking-widest text-primary uppercase">Passo {step + 1} de {steps.length}</p>
          <h2 id="wizard-title" className="mt-1 text-xl font-semibold">
            {title}
          </h2>
          <p className="mt-1 text-sm text-muted">{current.title}</p>
          <div className="mt-3 flex gap-1" aria-hidden="true">
            {steps.map((item, index) => (
              <span key={item.title} className={"h-1 flex-1 rounded-sm " + (index <= step ? "bg-primary" : "bg-line")} />
            ))}
          </div>
        </div>
        <div className="overflow-y-auto px-5 py-4">{current.body}</div>
        {error ? <p className="px-5 pb-2 text-sm text-danger">{error}</p> : null}
        <div className="flex gap-2 border-t border-line px-5 py-4">
          <button
            type="button"
            onClick={() => (step === 0 ? onClose() : setStep((value) => value - 1))}
            className="h-11 rounded-md border border-line px-4 text-sm"
          >
            {step === 0 ? "Cancelar" : "Voltar"}
          </button>
          <button type="button" onClick={advance} className="h-11 flex-1 rounded-md bg-accent px-4 text-sm font-semibold text-accent-fg">
            {last ? "Salvar" : "Continuar"}
          </button>
        </div>
      </div>
    </div>
  );
}
