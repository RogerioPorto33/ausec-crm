import { useState, type ReactNode } from "react";
import { Plus, Trash2 } from "lucide-react";
import { Wizard } from "@/components/crm/Wizard";
import { formatIso, todayIso, uid, type Rdo } from "@/lib/crm/model";
import { useCrm } from "@/lib/crm/store";

const inputClass =
  "h-11 w-full rounded-md border border-line bg-surface px-3 text-sm text-ink outline-none focus:border-primary";
const areaClass = "min-h-20 w-full rounded-md border border-line bg-surface px-3 py-2 text-sm outline-none focus:border-primary";

export function RdoLista({ projetoId }: { projetoId: string }) {
  const rdos = useCrm((s) => s.rdos);
  const projects = useCrm((s) => s.projects);
  const upsert = useCrm((s) => s.upsertRdo);
  const remove = useCrm((s) => s.removeRdo);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<Rdo>(() => emptyRdo(projetoId, 1));
  const lista = rdos.filter((r) => !projetoId || r.projetoId === projetoId).sort((a, b) => b.data.localeCompare(a.data) || b.numero - a.numero);
  const obra = projetoId || projects[0]?.id || "";

  function novo() {
    const ultimo = lista[0];
    const base = ultimo
      ? { ...ultimo, id: uid(), numero: ultimo.numero + 1, data: todayIso(), status: "rascunho" as const }
      : emptyRdo(obra, 1);
    setForm(base);
    setOpen(true);
  }

  return (
    <div className="space-y-4">
      <button type="button" onClick={novo} className="inline-flex h-11 items-center gap-2 rounded-lg bg-primary px-4 text-sm font-semibold text-primary-fg">
        <Plus className="size-4" aria-hidden="true" />
        Novo RDO
      </button>
      <Wizard
        open={open}
        title={`RDO ${form.numero}`}
        onClose={() => setOpen(false)}
        onSave={() => {
          if (!form.projetoId || !form.data) return "Informe a obra e a data.";
          upsert(form);
          setOpen(false);
          return null;
        }}
        steps={[
          {
            title: "Identificação",
            valid: () => (form.projetoId && form.data ? null : "Informe a obra e a data."),
            body: (
              <div className="grid gap-3 sm:grid-cols-2">
                <Field label="Obra">
                  <select className={inputClass} value={form.projetoId} onChange={(e) => setForm({ ...form, projetoId: e.target.value })}>
                    {projects.map((p) => <option key={p.id} value={p.id}>{p.nome}</option>)}
                  </select>
                </Field>
                <Field label="Data"><input className={inputClass} type="date" value={form.data} onChange={(e) => setForm({ ...form, data: e.target.value })} /></Field>
                <Field label="Turno">
                  <select className={inputClass} value={form.turno} onChange={(e) => setForm({ ...form, turno: e.target.value as Rdo["turno"] })}>
                    <option value="manha">Manhã</option>
                    <option value="tarde">Tarde</option>
                    <option value="integral">Integral</option>
                    <option value="noite">Noite</option>
                  </select>
                </Field>
                <Field label="Responsável"><input className={inputClass} value={form.responsavel} onChange={(e) => setForm({ ...form, responsavel: e.target.value })} /></Field>
                <Field label="CREA / CAU"><input className={inputClass} value={form.registro} onChange={(e) => setForm({ ...form, registro: e.target.value })} /></Field>
              </div>
            ),
          },
          {
            title: "Clima e efetivo",
            body: (
              <div className="grid gap-3">
                <Field label="Clima manhã"><input className={inputClass} value={form.climaManha} onChange={(e) => setForm({ ...form, climaManha: e.target.value })} placeholder="Claro, nublado, chuva até 10h" /></Field>
                <Field label="Clima tarde"><input className={inputClass} value={form.climaTarde} onChange={(e) => setForm({ ...form, climaTarde: e.target.value })} /></Field>
                <label className="flex items-center gap-2 text-sm">
                  <input type="checkbox" checked={form.praticavel} onChange={(e) => setForm({ ...form, praticavel: e.target.checked })} />
                  Dia praticável
                </label>
                <Field label="Efetivo"><textarea className={areaClass} value={form.efetivo} onChange={(e) => setForm({ ...form, efetivo: e.target.value })} placeholder="2 técnicos, 1 auxiliar" /></Field>
              </div>
            ),
          },
          {
            title: "Execução",
            body: (
              <div className="grid gap-3">
                <Field label="Atividades"><textarea className={areaClass} value={form.atividades} onChange={(e) => setForm({ ...form, atividades: e.target.value })} placeholder="Serviço, local e quantidade" /></Field>
                <Field label="Materiais"><textarea className={areaClass} value={form.materiais} onChange={(e) => setForm({ ...form, materiais: e.target.value })} placeholder="Recebido e aplicado" /></Field>
                <Field label="Equipamentos"><textarea className={areaClass} value={form.equipamentos} onChange={(e) => setForm({ ...form, equipamentos: e.target.value })} /></Field>
              </div>
            ),
          },
          {
            title: "Ocorrências e fechamento",
            body: (
              <div className="grid gap-3">
                <Field label="Ocorrências"><textarea className={areaClass} value={form.ocorrencias} onChange={(e) => setForm({ ...form, ocorrencias: e.target.value })} placeholder="Causa, consequência e providência" /></Field>
                <Field label="DDS — tema"><input className={inputClass} value={form.ddsTema} onChange={(e) => setForm({ ...form, ddsTema: e.target.value })} /></Field>
                <Field label="DDS — participantes"><input className={inputClass} value={form.ddsParticipantes} onChange={(e) => setForm({ ...form, ddsParticipantes: e.target.value })} /></Field>
                <Field label="Fotos / legendas"><textarea className={areaClass} value={form.fotos} onChange={(e) => setForm({ ...form, fotos: e.target.value })} /></Field>
                <Field label="Pendências"><textarea className={areaClass} value={form.pendencias} onChange={(e) => setForm({ ...form, pendencias: e.target.value })} /></Field>
                <Field label="Status">
                  <select className={inputClass} value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value as Rdo["status"] })}>
                    <option value="rascunho">Rascunho</option>
                    <option value="assinado">Assinado</option>
                  </select>
                </Field>
              </div>
            ),
          },
        ]}
      />
      {lista.length === 0 ? (
        <p className="text-sm text-muted">Nenhum diário nesta obra. O próximo copia o anterior.</p>
      ) : (
        <ul className="divide-y divide-line rounded-xl border border-line bg-surface">
          {lista.map((r) => (
            <li key={r.id} className="flex items-start justify-between gap-3 px-4 py-3">
              <div>
                <p className="font-medium">RDO {r.numero} · {formatIso(r.data)}</p>
                <p className="text-xs text-muted">{r.responsavel || "sem responsável"} · {r.status} · {r.praticavel ? "praticável" : "impraticável"}</p>
                {r.atividades ? <p className="mt-1 line-clamp-2 text-sm">{r.atividades}</p> : null}
              </div>
              <button type="button" onClick={() => remove(r.id)} className="text-danger" aria-label="Excluir RDO"><Trash2 className="size-4" aria-hidden="true" /></button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="block text-sm">
      <span className="mb-1 block font-medium">{label}</span>
      {children}
    </label>
  );
}

function emptyRdo(projetoId: string, numero: number): Rdo {
  return {
    id: uid(),
    projetoId,
    numero,
    data: todayIso(),
    turno: "integral",
    responsavel: "",
    registro: "",
    climaManha: "",
    climaTarde: "",
    praticavel: true,
    efetivo: "",
    atividades: "",
    materiais: "",
    equipamentos: "",
    ocorrencias: "",
    ddsTema: "",
    ddsParticipantes: "",
    fotos: "",
    pendencias: "",
    status: "rascunho",
  };
}
