import { useState, type ReactNode } from "react";
import { Plus, Trash2 } from "lucide-react";
import { Wizard } from "@/components/crm/Wizard";
import { precoComTaxas, somaTaxas, uid, type Taxa, type TaxaTipo, type Usuario } from "@/lib/crm/model";
import { useCrm } from "@/lib/crm/store";

const inputClass =
  "h-11 w-full rounded-md border border-line bg-surface px-3 text-sm text-ink outline-none focus:border-primary";

type Aba = "usuarios" | "taxas" | "bases";

export function Admin() {
  const [aba, setAba] = useState<Aba>("usuarios");
  const papel = useCrm((s) => s.usuarios.find((u) => u.id === s.currentUserId)?.papel);
  if (papel !== "admin") {
    return <p className="text-sm text-muted">Só o administrador entra nesta central.</p>;
  }
  return (
    <section>
      <div className="mb-5">
        <h1 className="text-2xl font-semibold tracking-tight">Administração</h1>
        <p className="mt-1 max-w-2xl text-sm text-muted">Central das bases, dos usuários e das taxas usadas na precificação.</p>
      </div>
      <div className="mb-4 flex gap-2 overflow-x-auto" role="tablist">
        {(
          [
            ["usuarios", "Usuários"],
            ["taxas", "Taxas e impostos"],
            ["bases", "Bases"],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            type="button"
            role="tab"
            aria-selected={aba === id}
            onClick={() => setAba(id)}
            className={"h-10 shrink-0 rounded-full px-4 text-sm font-medium " + (aba === id ? "bg-primary text-primary-fg" : "bg-surface text-muted")}
          >
            {label}
          </button>
        ))}
      </div>
      {aba === "usuarios" ? <Usuarios /> : null}
      {aba === "taxas" ? <Taxas /> : null}
      {aba === "bases" ? <Bases /> : null}
    </section>
  );
}

function Usuarios() {
  const usuarios = useCrm((s) => s.usuarios);
  const upsert = useCrm((s) => s.upsertUsuario);
  const remove = useCrm((s) => s.removeUsuario);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<Usuario>(() => emptyUsuario());
  return (
    <div className="space-y-4">
      <button type="button" onClick={() => { setForm(emptyUsuario()); setOpen(true); }} className="inline-flex h-11 items-center gap-2 rounded-lg bg-primary px-4 text-sm font-semibold text-primary-fg">
        <Plus className="size-4" aria-hidden="true" />
        Novo usuário
      </button>
      <Wizard
        open={open}
        title="Usuário"
        onClose={() => setOpen(false)}
        onSave={() => {
          if (!form.nome.trim() || !form.email.trim() || !form.senha) return "Informe nome, e-mail e senha.";
          upsert({ ...form, nome: form.nome.trim(), email: form.email.trim().toLowerCase() });
          setOpen(false);
          return null;
        }}
        steps={[
          {
            title: "Acesso",
            valid: () => (form.nome.trim() && form.email.trim() && form.senha ? null : "Informe nome, e-mail e senha."),
            body: (
              <div className="grid gap-3">
                <Field label="Nome"><input className={inputClass} value={form.nome} onChange={(e) => setForm({ ...form, nome: e.target.value })} /></Field>
                <Field label="E-mail"><input className={inputClass} value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></Field>
                <Field label="Senha"><input className={inputClass} type="password" value={form.senha} onChange={(e) => setForm({ ...form, senha: e.target.value })} /></Field>
                <Field label="Papel">
                  <select className={inputClass} value={form.papel} onChange={(e) => setForm({ ...form, papel: e.target.value as Usuario["papel"] })}>
                    <option value="equipe">Equipe</option>
                    <option value="admin">Administrador</option>
                  </select>
                </Field>
              </div>
            ),
          },
        ]}
      />
      <ul className="divide-y divide-line rounded-xl border border-line bg-surface">
        {usuarios.map((u) => (
          <li key={u.id} className="flex items-center justify-between gap-3 px-4 py-3">
            <div>
              <p className="font-medium">{u.nome}</p>
              <p className="text-xs text-muted">{u.email} · {u.papel}{u.ativo ? "" : " · inativo"}</p>
            </div>
            <div className="flex items-center gap-3">
              <button type="button" onClick={() => upsert({ ...u, ativo: !u.ativo })} className="text-sm text-primary">{u.ativo ? "Inativar" : "Ativar"}</button>
              <button type="button" onClick={() => remove(u.id)} className="text-danger" aria-label="Excluir usuário"><Trash2 className="size-4" aria-hidden="true" /></button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

function Taxas() {
  const taxas = useCrm((s) => s.taxas);
  const upsert = useCrm((s) => s.upsertTaxa);
  const remove = useCrm((s) => s.removeTaxa);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<Taxa>(() => emptyTaxa());
  const soma = somaTaxas(taxas);
  return (
    <div className="space-y-4">
      <article className="card px-5 py-4">
        <p className="text-xs font-medium text-muted">Soma das taxas</p>
        <p className="tabular mt-2 text-2xl font-semibold">{soma.toLocaleString("pt-BR")}%</p>
        <p className="mt-1 text-sm text-muted">R$ 100 de custo vira {precoComTaxas(100, taxas).toLocaleString("pt-BR", { style: "currency", currency: "BRL" })} de venda.</p>
      </article>
      <button type="button" onClick={() => { setForm(emptyTaxa()); setOpen(true); }} className="inline-flex h-11 items-center gap-2 rounded-lg bg-primary px-4 text-sm font-semibold text-primary-fg">
        <Plus className="size-4" aria-hidden="true" />
        Nova taxa
      </button>
      <Wizard
        open={open}
        title="Taxa"
        onClose={() => setOpen(false)}
        onSave={() => {
          if (!form.nome.trim()) return "Informe o nome.";
          upsert({ ...form, nome: form.nome.trim() });
          setOpen(false);
          return null;
        }}
        steps={[
          {
            title: "Alíquota",
            valid: () => (form.nome.trim() ? null : "Informe o nome."),
            body: (
              <div className="grid gap-3">
                <Field label="Nome"><input className={inputClass} value={form.nome} onChange={(e) => setForm({ ...form, nome: e.target.value })} /></Field>
                <Field label="Tipo">
                  <select className={inputClass} value={form.tipo} onChange={(e) => setForm({ ...form, tipo: e.target.value as TaxaTipo })}>
                    <option value="imposto">Imposto</option>
                    <option value="taxa">Taxa</option>
                    <option value="margem">Margem</option>
                  </select>
                </Field>
                <Field label="Percentual"><input className={inputClass} type="number" min={0} step="0.01" value={form.percentual} onChange={(e) => setForm({ ...form, percentual: Number(e.target.value) })} /></Field>
              </div>
            ),
          },
        ]}
      />
      <ul className="divide-y divide-line rounded-xl border border-line bg-surface">
        {taxas.map((t) => (
          <li key={t.id} className="flex items-center justify-between gap-3 px-4 py-3">
            <div>
              <p className="font-medium">{t.nome}</p>
              <p className="text-xs text-muted">{t.tipo}</p>
            </div>
            <div className="flex items-center gap-3">
              <input className="h-9 w-24 rounded-md border border-line px-2 text-sm" type="number" value={t.percentual} onChange={(e) => upsert({ ...t, percentual: Number(e.target.value) })} />
              <button type="button" onClick={() => remove(t.id)} className="text-danger" aria-label="Excluir taxa"><Trash2 className="size-4" aria-hidden="true" /></button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

function Bases() {
  const setView = useCrm((s) => s.setView);
  const itens = [
    ["fornecedores", "Fornecedores"],
    ["produtos", "Produtos e grupos"],
    ["servicos", "Serviços"],
    ["clientes", "Clientes"],
    ["projetos", "Projetos"],
  ] as const;
  return (
    <ul className="grid gap-3 sm:grid-cols-2">
      {itens.map(([id, label]) => (
        <li key={id}>
          <button type="button" onClick={() => setView(id)} className="card flex h-20 w-full items-center px-5 text-left text-sm font-medium">
            {label}
          </button>
        </li>
      ))}
    </ul>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="block text-sm">
      <span className="mb-1 block font-medium">{label}</span>
      {children}
    </label>
  );
}

function emptyUsuario(): Usuario {
  return { id: uid(), nome: "", email: "", senha: "", papel: "equipe", ativo: true };
}

function emptyTaxa(): Taxa {
  return { id: uid(), nome: "", percentual: 0, tipo: "taxa" };
}
