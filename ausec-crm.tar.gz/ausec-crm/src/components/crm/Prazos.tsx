import { useMemo, useState, type ReactNode } from "react";
import { CalendarRange, Plus, Trash2 } from "lucide-react";
import { Wizard } from "@/components/crm/Wizard";
import {
  dependenciasAbertas,
  formatIso,
  itemAtrasado,
  itemBloqueado,
  parseIso,
  STATUS_TONS,
  todayIso,
  uid,
  type ProcessRec,
  type ScheduleItem,
  type StatusRec,
  type StatusTom,
} from "@/lib/crm/model";
import { useCrm } from "@/lib/crm/store";

const inputClass =
  "h-11 w-full rounded-md border border-line bg-surface px-3 text-sm text-ink outline-none focus:border-primary";

const tomClass: Record<StatusTom, string> = {
  ok: "bg-ok text-primary-fg",
  warn: "bg-warn text-primary-fg",
  danger: "bg-danger text-primary-fg",
  muted: "bg-line text-ink",
  primary: "bg-primary text-primary-fg",
};

const barClass: Record<StatusTom, string> = {
  ok: "bg-ok",
  warn: "bg-warn",
  danger: "bg-danger",
  muted: "bg-muted",
  primary: "bg-primary",
};

type Aba = "cronograma" | "processos" | "status";

export function Prazos() {
  const projects = useCrm((s) => s.projects);
  const clients = useCrm((s) => s.clients);
  const processes = useCrm((s) => s.processes);
  const statuses = useCrm((s) => s.statuses);
  const schedule = useCrm((s) => s.schedule);
  const [aba, setAba] = useState<Aba>("cronograma");
  const [projetoId, setProjetoId] = useState(projects[0]?.id ?? "");
  const [processoFiltro, setProcessoFiltro] = useState("");
  const [statusFiltro, setStatusFiltro] = useState("");
  const query = useCrm((s) => s.query).trim().toLowerCase();
  const dataDe = useCrm((s) => s.dataDe);
  const dataAte = useCrm((s) => s.dataAte);
  const setPeriodo = useCrm((s) => s.setPeriodo);

  const processos = useMemo(() => [...processes].sort((a, b) => a.ordem - b.ordem || a.nome.localeCompare(b.nome)), [processes]);
  const statusLista = useMemo(() => [...statuses].sort((a, b) => a.ordem - b.ordem || a.nome.localeCompare(b.nome)), [statuses]);

  const itens = useMemo(() => {
    return schedule
      .filter((item) => !projetoId || item.projetoId === projetoId)
      .filter((item) => !processoFiltro || item.processoId === processoFiltro)
      .filter((item) => !statusFiltro || item.statusId === statusFiltro)
      .filter((item) => !query || `${item.nome} ${item.responsavel} ${item.observacoes}`.toLowerCase().includes(query))
      .filter((item) => !dataDe || !item.fimPrev || item.fimPrev >= dataDe)
      .filter((item) => !dataAte || !item.inicioPrev || item.inicioPrev <= dataAte)
      .sort((a, b) => (a.inicioPrev || "9999").localeCompare(b.inicioPrev || "9999") || a.nome.localeCompare(b.nome));
  }, [schedule, projetoId, processoFiltro, statusFiltro, query, dataDe, dataAte]);

  const resumo = useMemo(() => {
    const base = schedule.filter((item) => !projetoId || item.projetoId === projetoId);
    const atrasados = base.filter((item) => itemAtrasado(item, statuses.find((s) => s.id === item.statusId))).length;
    const concluidos = base.filter((item) => statuses.find((s) => s.id === item.statusId)?.encerra).length;
    const progresso = base.length ? Math.round(base.reduce((acc, item) => acc + item.progresso, 0) / base.length) : 0;
    return { total: base.length, atrasados, concluidos, progresso };
  }, [schedule, projetoId, statuses]);

  const projeto = projects.find((p) => p.id === projetoId);
  const cliente = clients.find((c) => c.id === projeto?.clienteId);

  return (
    <section>
      <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Cronograma</h1>
          <p className="mt-1 max-w-2xl text-sm text-pretty text-muted">
            Demandas da obra, com dependência e o período do topo da tela.
          </p>
        </div>
      </div>

      <div className="mb-4 flex gap-2 overflow-x-auto" role="tablist" aria-label="Controle">
        {(
          [
            ["cronograma", "Cronograma"],
            ["processos", "Processos"],
            ["status", "Status"],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            type="button"
            role="tab"
            aria-selected={aba === id}
            onClick={() => setAba(id)}
            className={
              "h-11 shrink-0 rounded-md px-4 text-sm font-medium " +
              (aba === id ? "bg-primary text-primary-fg" : "border border-line bg-surface text-ink")
            }
          >
            {label}
          </button>
        ))}
      </div>

      {aba === "cronograma" ? (
        <>
          <div className="mb-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
            <Metric label="Itens" value={String(resumo.total)} hint={projeto ? projeto.nome : "todos os projetos"} />
            <Metric label="Avanço médio" value={`${resumo.progresso}%`} hint="média dos itens filtrados" />
            <Metric label="Atrasados" value={String(resumo.atrasados)} hint="fim previsto já passou" />
            <Metric label="Concluídos" value={String(resumo.concluidos)} hint="status que encerra" />
          </div>

          <div className="mb-4 grid gap-3 rounded-lg border border-line bg-surface p-4 sm:grid-cols-3 xl:grid-cols-5">
            <label className="block text-sm">
              <span className="mb-1 block font-medium">Projeto</span>
              <select className={inputClass} value={projetoId} onChange={(e) => setProjetoId(e.target.value)}>
                <option value="">Todos</option>
                {projects.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.nome}
                  </option>
                ))}
              </select>
            </label>
            <label className="block text-sm">
              <span className="mb-1 block font-medium">Processo</span>
              <select className={inputClass} value={processoFiltro} onChange={(e) => setProcessoFiltro(e.target.value)}>
                <option value="">Todos</option>
                {processos.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.nome}
                  </option>
                ))}
              </select>
            </label>
            <label className="block text-sm">
              <span className="mb-1 block font-medium">Status</span>
              <select className={inputClass} value={statusFiltro} onChange={(e) => setStatusFiltro(e.target.value)}>
                <option value="">Todos</option>
                {statusLista.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.nome}
                  </option>
                ))}
              </select>
            </label>
            <label className="block text-sm">
              <span className="mb-1 block font-medium">De</span>
              <input className={inputClass} type="date" value={dataDe} onChange={(e) => setPeriodo(e.target.value, dataAte)} />
            </label>
            <label className="block text-sm">
              <span className="mb-1 block font-medium">Até</span>
              <input className={inputClass} type="date" value={dataAte} onChange={(e) => setPeriodo(dataDe, e.target.value)} />
            </label>
          </div>

          {cliente ? <p className="mb-3 text-sm text-muted">Cliente: {cliente.nome}</p> : null}

          <Gantt itens={itens} todos={schedule} processos={processos} statuses={statusLista} />
          <ItemForm
            projetoId={projetoId || projects[0]?.id || ""}
            processos={processos}
            statuses={statusLista}
            projects={projects}
            existentes={schedule}
          />
          <ItemTable itens={itens} todos={schedule} processos={processos} statuses={statusLista} projects={projects} />
        </>
      ) : null}

      {aba === "processos" ? <CatalogoProcessos processos={processos} /> : null}
      {aba === "status" ? <CatalogoStatus statuses={statusLista} /> : null}
    </section>
  );
}

function Metric({ label, value, hint }: { label: string; value: string; hint: string }) {
  return (
    <article className="card px-5 py-4">
      <p className="text-xs font-medium text-muted">{label}</p>
      <p className="tabular mt-2 text-2xl font-semibold tracking-tight">{value}</p>
      <p className="mt-1 text-sm text-muted">{hint}</p>
    </article>
  );
}

function Gantt({
  itens,
  todos,
  processos,
  statuses,
}: {
  itens: ScheduleItem[];
  todos: ScheduleItem[];
  processos: ProcessRec[];
  statuses: StatusRec[];
}) {
  const range = useMemo(() => {
    const stamps = itens.flatMap((item) => [parseIso(item.inicioPrev), parseIso(item.fimPrev)]).filter((n): n is number => n != null);
    if (stamps.length === 0) return null;
    const min = Math.min(...stamps);
    const max = Math.max(...stamps, parseIso(todayIso()) ?? 0);
    const span = Math.max(max - min, 86_400_000);
    return { min, max, span };
  }, [itens]);

  if (!range) {
    return (
      <article className="mb-4 rounded-lg border border-dashed border-line bg-surface px-4 py-8 text-center text-sm text-muted">
        <CalendarRange className="mx-auto mb-2 size-5" aria-hidden="true" />
        Nenhum item com data prevista neste filtro.
      </article>
    );
  }

  const hoje = parseIso(todayIso());
  const hojeLeft = hoje == null ? null : ((hoje - range.min) / range.span) * 100;

  return (
    <article className="mb-4 overflow-x-auto rounded-lg border border-line bg-surface">
      <div className="min-w-[720px] p-4">
        <div className="mb-3 flex items-center justify-between text-xs text-muted">
          <span>{new Date(range.min).toLocaleDateString("pt-BR")}</span>
          <span>Cronograma previsto</span>
          <span>{new Date(range.max).toLocaleDateString("pt-BR")}</span>
        </div>
        <div className="relative">
          {hojeLeft != null && hojeLeft >= 0 && hojeLeft <= 100 ? (
            <div className="absolute top-0 bottom-0 z-10 w-px bg-accent" style={{ left: `${hojeLeft}%` }} title="Hoje" />
          ) : null}
          <ul className="space-y-2">
            {itens.map((item) => {
              const start = parseIso(item.inicioPrev);
              const end = parseIso(item.fimPrev);
              const status = statuses.find((s) => s.id === item.statusId);
              const processo = processos.find((p) => p.id === item.processoId);
              const late = itemAtrasado(item, status);
              const bloqueado = itemBloqueado(item, todos, statuses);
              const abertas = dependenciasAbertas(item, todos, statuses);
              const left = start == null ? 0 : ((start - range.min) / range.span) * 100;
              const width = start == null || end == null ? 8 : Math.max(((end - start) / range.span) * 100, 2);
              return (
                <li key={item.id} className="grid grid-cols-[180px_1fr] items-center gap-3">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium">{item.nome}</p>
                    <p className="truncate text-xs text-muted">
                      {processo?.nome ?? "Sem processo"}
                      {bloqueado ? " · aguarda conclusão" : ""}
                    </p>
                  </div>
                  <div className="relative h-8 rounded-sm bg-bg">
                    <div
                      className={"absolute top-1 h-6 rounded-sm " + (late ? barClass.danger : barClass[status?.tom ?? "muted"])}
                      style={{ left: `${left}%`, width: `${width}%` }}
                    />
                    <span className="absolute inset-y-0 left-2 flex items-center text-xs font-medium text-ink">
                      {item.progresso}%
                    </span>
                  </div>
                </li>
              );
            })}
          </ul>
        </div>
      </div>
    </article>
  );
}

function ItemForm({
  projetoId,
  processos,
  statuses,
  projects,
  existentes,
}: {
  projetoId: string;
  processos: ProcessRec[];
  statuses: StatusRec[];
  projects: { id: string; nome: string }[];
  existentes: ScheduleItem[];
}) {
  const upsert = useCrm((s) => s.upsertSchedule);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<ScheduleItem>(() => emptyItem(projetoId, processos[0]?.id ?? "", statuses[0]?.id ?? ""));

  if (!open) {
    return (
      <button
        type="button"
        onClick={() => {
          setForm(emptyItem(projetoId, processos[0]?.id ?? "", statuses[0]?.id ?? ""));
          setOpen(true);
        }}
        className="mb-4 inline-flex h-11 items-center gap-2 rounded-md bg-accent px-4 text-sm font-semibold text-accent-fg"
      >
        <Plus className="size-4" aria-hidden="true" />
        Novo item
      </button>
    );
  }

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="mb-4 inline-flex h-11 items-center gap-2 rounded-md bg-accent px-4 text-sm font-semibold text-accent-fg"
      >
        <Plus className="size-4" aria-hidden="true" />
        Novo item
      </button>
      <Wizard
        open={open}
        title="Novo item do cronograma"
        onClose={() => setOpen(false)}
        onSave={() => {
          if (!form.nome.trim() || !form.projetoId) return "Informe o item e o projeto.";
          upsert({ ...form, nome: form.nome.trim(), progresso: clamp(form.progresso) });
          setOpen(false);
          return null;
        }}
        steps={[
          {
            title: "O que entra no prazo",
            valid: () => (form.nome.trim() && form.projetoId ? null : "Informe o item e o projeto."),
            body: (
              <div className="grid gap-3">
                <Field label="Item">
                  <input className={inputClass} value={form.nome} onChange={(e) => setForm({ ...form, nome: e.target.value })} />
                </Field>
                <Field label="Projeto">
                  <select className={inputClass} value={form.projetoId} onChange={(e) => setForm({ ...form, projetoId: e.target.value })}>
                    <option value="">Selecione</option>
                    {projects.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.nome}
                      </option>
                    ))}
                  </select>
                </Field>
                <Field label="Processo">
                  <select className={inputClass} value={form.processoId} onChange={(e) => setForm({ ...form, processoId: e.target.value })}>
                    <option value="">Sem processo</option>
                    {processos.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.nome}
                      </option>
                    ))}
                  </select>
                </Field>
              </div>
            ),
          },
          {
            title: "Status e responsável",
            body: (
              <div className="grid gap-3">
                <Field label="Status">
                  <select className={inputClass} value={form.statusId} onChange={(e) => setForm({ ...form, statusId: e.target.value })}>
                    <option value="">Sem status</option>
                    {statuses.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.nome}
                      </option>
                    ))}
                  </select>
                </Field>
                <Field label="Responsável">
                  <input className={inputClass} value={form.responsavel} onChange={(e) => setForm({ ...form, responsavel: e.target.value })} />
                </Field>
                <Field label="Avanço %">
                  <input className={inputClass} type="number" min={0} max={100} value={form.progresso} onChange={(e) => setForm({ ...form, progresso: Number(e.target.value) })} />
                </Field>
              </div>
            ),
          },
          {
            title: "Datas",
            body: (
              <div className="grid gap-3 sm:grid-cols-2">
                <Field label="Início previsto">
                  <input className={inputClass} type="date" value={form.inicioPrev} onChange={(e) => setForm({ ...form, inicioPrev: e.target.value })} />
                </Field>
                <Field label="Fim previsto">
                  <input className={inputClass} type="date" value={form.fimPrev} onChange={(e) => setForm({ ...form, fimPrev: e.target.value })} />
                </Field>
                <Field label="Início real">
                  <input className={inputClass} type="date" value={form.inicioReal} onChange={(e) => setForm({ ...form, inicioReal: e.target.value })} />
                </Field>
                <Field label="Fim real">
                  <input className={inputClass} type="date" value={form.fimReal} onChange={(e) => setForm({ ...form, fimReal: e.target.value })} />
                </Field>
                <div className="sm:col-span-2">
                  <Field label="Observações">
                    <input className={inputClass} value={form.observacoes} onChange={(e) => setForm({ ...form, observacoes: e.target.value })} />
                  </Field>
                </div>
              </div>
            ),
          },
          {
            title: "Depende de",
            body: (
              <div className="grid gap-2">
                <p className="text-sm text-muted">Só libera quando as marcadas estiverem concluídas.</p>
                {existentes.filter((item) => item.projetoId === form.projetoId && item.id !== form.id).map((item) => {
                  const on = (form.dependeDe ?? []).includes(item.id);
                  return (
                    <label key={item.id} className="flex items-center gap-2 text-sm">
                      <input
                        type="checkbox"
                        checked={on}
                        onChange={() =>
                          setForm({
                            ...form,
                            dependeDe: on ? (form.dependeDe ?? []).filter((id) => id !== item.id) : [...(form.dependeDe ?? []), item.id],
                          })
                        }
                      />
                      {item.nome}
                    </label>
                  );
                })}
              </div>
            ),
          },
        ]}
      />
    </>
  );
}

function ItemTable({
  itens,
  todos,
  processos,
  statuses,
  projects,
}: {
  itens: ScheduleItem[];
  todos: ScheduleItem[];
  processos: ProcessRec[];
  statuses: StatusRec[];
  projects: { id: string; nome: string }[];
}) {
  const upsert = useCrm((s) => s.upsertSchedule);
  const remove = useCrm((s) => s.removeSchedule);

  if (itens.length === 0) {
    return <p className="text-sm text-muted">Nenhum item neste filtro. Cadastre o primeiro acima.</p>;
  }

  return (
    <div className="overflow-x-auto rounded-lg border border-line bg-surface">
      <table className="w-full min-w-[860px] text-left text-sm">
        <thead className="text-xs tracking-wide text-muted uppercase">
          <tr>
            {["Item", "Processo", "Status", "Previsto", "Real", "Avanço", ""].map((h) => (
              <th key={h || "acao"} className="px-3 py-2 font-medium">
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {itens.map((item) => {
            const status = statuses.find((s) => s.id === item.statusId);
            const late = itemAtrasado(item, status);
            const bloqueado = itemBloqueado(item, todos, statuses);
            const abertas = dependenciasAbertas(item, todos, statuses);
            return (
              <tr key={item.id} className="border-t border-line align-top">
                <td className="px-3 py-3">
                  <p className="font-medium">{item.nome}</p>
                  <p className="text-xs text-muted">
                    {projects.find((p) => p.id === item.projetoId)?.nome ?? "Sem projeto"}
                    {item.responsavel ? ` · ${item.responsavel}` : ""}
                  </p>
                  {item.observacoes ? <p className="mt-1 text-xs text-muted">{item.observacoes}</p> : null}
                </td>
                <td className="px-3 py-3">{processos.find((p) => p.id === item.processoId)?.nome ?? "—"}</td>
                <td className="px-3 py-3">
                  <select
                    className="h-9 rounded-md border border-line bg-surface px-2 text-sm"
                    value={item.statusId}
                    onChange={(e) => upsert({ ...item, statusId: e.target.value })}
                  >
                    <option value="">—</option>
                    {statuses.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.nome}
                      </option>
                    ))}
                  </select>
                  {late ? <p className="mt-1 text-xs font-medium text-danger">Fora do prazo</p> : null}
                  {bloqueado ? (
                    <p className="mt-1 text-xs font-medium text-warn">Aguarda: {abertas.map((d) => d.nome).join(", ")}</p>
                  ) : null}
                </td>
                <td className="tabular px-3 py-3 text-xs">
                  {formatIso(item.inicioPrev)}
                  <br />
                  {formatIso(item.fimPrev)}
                </td>
                <td className="tabular px-3 py-3 text-xs">
                  {formatIso(item.inicioReal)}
                  <br />
                  {formatIso(item.fimReal)}
                </td>
                <td className="px-3 py-3">
                  <input
                    className="h-9 w-20 rounded-md border border-line px-2 text-sm"
                    type="number"
                    min={0}
                    max={100}
                    value={item.progresso}
                    onChange={(e) => upsert({ ...item, progresso: clamp(Number(e.target.value)) })}
                  />
                </td>
                <td className="px-3 py-3">
                  <button type="button" onClick={() => remove(item.id)} className="inline-flex h-9 items-center text-danger" aria-label="Excluir item">
                    <Trash2 className="size-4" aria-hidden="true" />
                  </button>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

function CatalogoProcessos({ processos }: { processos: ProcessRec[] }) {
  const upsert = useCrm((s) => s.upsertProcess);
  const remove = useCrm((s) => s.removeProcess);
  const [open, setOpen] = useState(false);
  const [nome, setNome] = useState("");

  return (
    <div className="space-y-4">
      <button type="button" onClick={() => setOpen(true)} className="h-11 rounded-md bg-primary px-4 text-sm font-semibold text-primary-fg">
        Novo processo
      </button>
      <Wizard
        open={open}
        title="Novo processo"
        onClose={() => setOpen(false)}
        onSave={() => {
          if (!nome.trim()) return "Informe o nome.";
          upsert({ id: uid(), nome: nome.trim(), ordem: processos.length + 1 });
          setNome("");
          setOpen(false);
          return null;
        }}
        steps={[
          {
            title: "Nome do processo",
            valid: () => (nome.trim() ? null : "Informe o nome."),
            body: (
              <Field label="Processo">
                <input className={inputClass} value={nome} onChange={(e) => setNome(e.target.value)} placeholder="Ex.: Mobilização" />
              </Field>
            ),
          },
        ]}
      />
      <ul className="divide-y divide-line rounded-lg border border-line bg-surface">
        {processos.map((p) => (
          <li key={p.id} className="flex items-center gap-3 px-4 py-3">
            <span className="tabular w-8 text-sm text-muted">{p.ordem}</span>
            <input
              className="h-9 flex-1 rounded-md border border-line px-2 text-sm"
              value={p.nome}
              onChange={(e) => upsert({ ...p, nome: e.target.value })}
            />
            <input
              className="h-9 w-16 rounded-md border border-line px-2 text-sm"
              type="number"
              value={p.ordem}
              onChange={(e) => upsert({ ...p, ordem: Number(e.target.value) })}
              aria-label="Ordem"
            />
            <button type="button" onClick={() => remove(p.id)} className="text-danger" aria-label="Excluir processo">
              <Trash2 className="size-4" aria-hidden="true" />
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

function CatalogoStatus({ statuses }: { statuses: StatusRec[] }) {
  const upsert = useCrm((s) => s.upsertStatus);
  const remove = useCrm((s) => s.removeStatus);
  const [open, setOpen] = useState(false);
  const [nome, setNome] = useState("");
  const [tom, setTom] = useState<StatusTom>("primary");
  const [encerra, setEncerra] = useState(false);

  return (
    <div className="space-y-4">
      <button type="button" onClick={() => setOpen(true)} className="h-11 rounded-md bg-primary px-4 text-sm font-semibold text-primary-fg">
        Novo status
      </button>
      <Wizard
        open={open}
        title="Novo status"
        onClose={() => setOpen(false)}
        onSave={() => {
          if (!nome.trim()) return "Informe o nome.";
          upsert({ id: uid(), nome: nome.trim(), tom, ordem: statuses.length + 1, encerra });
          setNome("");
          setEncerra(false);
          setOpen(false);
          return null;
        }}
        steps={[
          {
            title: "Como se chama",
            valid: () => (nome.trim() ? null : "Informe o nome."),
            body: (
              <Field label="Status">
                <input className={inputClass} value={nome} onChange={(e) => setNome(e.target.value)} placeholder="Ex.: Aguardando ART" />
              </Field>
            ),
          },
          {
            title: "Como aparece",
            body: (
              <div className="grid gap-3">
                <Field label="Tom">
                  <select className={inputClass} value={tom} onChange={(e) => setTom(e.target.value as StatusTom)}>
                    {STATUS_TONS.map((t) => (
                      <option key={t.id} value={t.id}>
                        {t.label}
                      </option>
                    ))}
                  </select>
                </Field>
                <label className="flex items-center gap-2 text-sm">
                  <input type="checkbox" checked={encerra} onChange={(e) => setEncerra(e.target.checked)} />
                  Encerra o item
                </label>
              </div>
            ),
          },
        ]}
      />
      <ul className="divide-y divide-line rounded-lg border border-line bg-surface">
        {statuses.map((s) => (
          <li key={s.id} className="flex flex-wrap items-center gap-3 px-4 py-3">
            <span className={"inline-flex h-7 items-center rounded-sm px-2 text-xs font-medium " + tomClass[s.tom]}>{s.nome}</span>
            <input
              className="h-9 min-w-40 flex-1 rounded-md border border-line px-2 text-sm"
              value={s.nome}
              onChange={(e) => upsert({ ...s, nome: e.target.value })}
            />
            <select className="h-9 rounded-md border border-line px-2 text-sm" value={s.tom} onChange={(e) => upsert({ ...s, tom: e.target.value as StatusTom })}>
              {STATUS_TONS.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.label}
                </option>
              ))}
            </select>
            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" checked={s.encerra} onChange={(e) => upsert({ ...s, encerra: e.target.checked })} />
              Encerra
            </label>
            <button type="button" onClick={() => remove(s.id)} className="text-danger" aria-label="Excluir status">
              <Trash2 className="size-4" aria-hidden="true" />
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="block text-sm">
      <span className="mb-1 block font-medium">{label}</span>
      {children}
    </label>
  );
}

function emptyItem(projetoId: string, processoId: string, statusId: string): ScheduleItem {
  return {
    id: uid(),
    projetoId,
    processoId,
    statusId,
    nome: "",
    responsavel: "",
    inicioPrev: todayIso(),
    fimPrev: "",
    inicioReal: "",
    fimReal: "",
    progresso: 0,
    observacoes: "",
    dependeDe: [],
  };
}

function clamp(n: number): number {
  if (!Number.isFinite(n)) return 0;
  return Math.max(0, Math.min(100, Math.round(n)));
}
