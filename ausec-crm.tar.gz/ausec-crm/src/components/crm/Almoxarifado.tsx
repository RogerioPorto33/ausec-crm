import { useMemo, useState, type ReactNode } from "react";
import { PackageCheck, Plus, Trash2 } from "lucide-react";
import { Wizard } from "@/components/crm/Wizard";
import {
  ASSET_STATUS,
  aReceber,
  formatIso,
  materialLines,
  MOVE_LABEL,
  stockOf,
  todayIso,
  uid,
  type AssetRec,
  type AssetStatus,
  type MoveKind,
  type StockMove,
} from "@/lib/crm/model";
import { useCrm } from "@/lib/crm/store";

const inputClass =
  "h-11 w-full rounded-md border border-line bg-surface px-3 text-sm text-ink outline-none focus:border-primary";

type Aba = "estoque" | "movimentos" | "ativos";

export function Almoxarifado() {
  const proposals = useCrm((s) => s.proposals);
  const clients = useCrm((s) => s.clients);
  const projects = useCrm((s) => s.projects);
  const moves = useCrm((s) => s.moves);
  const assets = useCrm((s) => s.assets);
  const selectedId = useCrm((s) => s.warehouseProposalId);
  const openWarehouse = useCrm((s) => s.openWarehouse);
  const [aba, setAba] = useState<Aba>("estoque");

  const ordered = useMemo(
    () => [...proposals].sort((a, b) => Number(b.status === "aprovada") - Number(a.status === "aprovada") || b.data.localeCompare(a.data)),
    [proposals],
  );
  const proposal = ordered.find((p) => p.id === selectedId) ?? ordered.find((p) => p.status === "aprovada") ?? ordered[0];
  const lines = proposal ? materialLines(proposal) : [];
  const ofProposal = moves.filter((m) => m.proposalId === proposal?.id);
  const assetsOf = assets.filter((a) => a.proposalId === proposal?.id);

  const resumo = useMemo(() => {
    return lines.reduce(
      (acc, line) => {
        const s = stockOf(line.id, ofProposal);
        acc.previsto += line.qtd;
        acc.recebido += s.recebido;
        acc.aplicado += s.aplicado;
        acc.saldo += s.saldo;
        return acc;
      },
      { previsto: 0, recebido: 0, aplicado: 0, saldo: 0 },
    );
  }, [lines, ofProposal]);

  const cliente = clients.find((c) => c.id === proposal?.clienteId);
  const projeto = projects.find((p) => p.id === proposal?.projetoId);

  return (
    <section>
      <div className="mb-6">
        <h1 className="text-2xl font-semibold tracking-tight">Almoxarifado da obra</h1>
        <p className="mt-1 max-w-2xl text-sm text-pretty text-muted">
          A lista vem da proposta. O que foi comprado entra, o que foi aplicado sai, e o saldo fica na obra.
        </p>
      </div>

      {ordered.length === 0 ? (
        <article className="rounded-lg border border-dashed border-line bg-surface px-4 py-8 text-center text-sm text-muted">
          Nenhuma proposta ainda. Monte e salve a lista em Montar proposta. Depois abra o almoxarifado dela.
        </article>
      ) : (
        <>
          <label className="mb-4 block max-w-xl text-sm">
            <span className="mb-1 block font-medium">Proposta da obra</span>
            <select className={inputClass} value={proposal?.id ?? ""} onChange={(e) => openWarehouse(e.target.value)}>
              {ordered.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.titulo}
                  {p.status === "aprovada" ? " · aprovada" : ""}
                </option>
              ))}
            </select>
          </label>
          {proposal ? (
            <p className="mb-4 text-sm text-muted">
              {cliente?.nome ?? "Sem cliente"}
              {projeto ? ` · ${projeto.nome}` : ""} · {lines.length} itens de material
            </p>
          ) : null}

          <div className="mb-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
            <Metric label="Previsto" value={fmt(resumo.previsto)} hint="quantidade da proposta" />
            <Metric label="Recebido" value={fmt(resumo.recebido)} hint="entradas no almoxarifado" />
            <Metric label="Aplicado" value={fmt(resumo.aplicado)} hint="saídas para a obra" />
            <Metric label="Saldo" value={fmt(resumo.saldo)} hint="em estoque agora" />
          </div>

          <div className="mb-4 flex gap-2 overflow-x-auto" role="tablist">
            {(
              [
                ["estoque", "Estoque"],
                ["movimentos", "Movimentos"],
                ["ativos", "Ativos"],
              ] as const
            ).map(([id, label]) => (
              <button
                key={id}
                type="button"
                role="tab"
                aria-selected={aba === id}
                onClick={() => setAba(id)}
                className={
                  "h-11 shrink-0 rounded-md px-4 text-sm font-medium " +
                  (aba === id ? "bg-primary text-primary-fg" : "border border-line bg-surface")
                }
              >
                {label}
              </button>
            ))}
          </div>

          {proposal && aba === "estoque" ? <Estoque proposalId={proposal.id} lines={lines} moves={ofProposal} /> : null}
          {proposal && aba === "movimentos" ? <Movimentos proposalId={proposal.id} lines={lines} moves={ofProposal} /> : null}
          {proposal && aba === "ativos" ? <Ativos proposalId={proposal.id} lines={lines} assets={assetsOf} /> : null}
        </>
      )}
    </section>
  );
}

function Estoque({
  proposalId,
  lines,
  moves,
}: {
  proposalId: string;
  lines: ReturnType<typeof materialLines>;
  moves: StockMove[];
}) {
  const addMove = useCrm((s) => s.addMove);
  const [open, setOpen] = useState(false);
  const [lineId, setLineId] = useState(lines[0]?.id ?? "");
  const [tipo, setTipo] = useState<MoveKind>("entrada");
  const [qtd, setQtd] = useState(1);
  const [responsavel, setResponsavel] = useState("");
  const [local, setLocal] = useState("");
  const [documento, setDocumento] = useState("");

  if (lines.length === 0) {
    return <p className="text-sm text-muted">Esta proposta não tem material. Serviço não entra no almoxarifado.</p>;
  }

  return (
    <div className="space-y-4">
      <button type="button" onClick={() => setOpen(true)} className="inline-flex h-11 items-center gap-2 rounded-md bg-accent px-4 text-sm font-semibold text-accent-fg">
        <Plus className="size-4" aria-hidden="true" />
        Lançar movimento
      </button>
      <Wizard
        open={open}
        title="Movimento de estoque"
        onClose={() => setOpen(false)}
        onSave={() => {
          if (!lineId || qtd === 0) return "Informe o item e a quantidade.";
          addMove({
            id: uid(),
            proposalId,
            lineId,
            tipo,
            qtd: Math.abs(qtd),
            data: todayIso(),
            responsavel: responsavel.trim(),
            local: local.trim(),
            documento: documento.trim(),
            observacoes: "",
          });
          setQtd(1);
          setDocumento("");
          setOpen(false);
          return null;
        }}
        steps={[
          {
            title: "O que movimenta",
            valid: () => (lineId ? null : "Escolha o item."),
            body: (
              <div className="grid gap-3">
                <Field label="Item da proposta">
                  <select className={inputClass} value={lineId} onChange={(e) => setLineId(e.target.value)}>
                    {lines.map((line) => (
                      <option key={line.id} value={line.id}>
                        {line.codigo ? `${line.codigo} · ` : ""}
                        {line.descricao}
                      </option>
                    ))}
                  </select>
                </Field>
                <Field label="Movimento">
                  <select className={inputClass} value={tipo} onChange={(e) => setTipo(e.target.value as MoveKind)}>
                    {(Object.keys(MOVE_LABEL) as MoveKind[]).map((k) => (
                      <option key={k} value={k}>
                        {MOVE_LABEL[k]}
                      </option>
                    ))}
                  </select>
                </Field>
              </div>
            ),
          },
          {
            title: "Quantidade e origem",
            valid: () => (qtd > 0 ? null : "Informe a quantidade."),
            body: (
              <div className="grid gap-3">
                <Field label="Quantidade">
                  <input className={inputClass} type="number" min={0} step="0.01" value={qtd} onChange={(e) => setQtd(Number(e.target.value))} />
                </Field>
                <Field label="Responsável">
                  <input className={inputClass} value={responsavel} onChange={(e) => setResponsavel(e.target.value)} />
                </Field>
                <Field label="Local / frente">
                  <input className={inputClass} value={local} onChange={(e) => setLocal(e.target.value)} placeholder="Galpão, portaria, rack" />
                </Field>
                <Field label="NF / requisição">
                  <input className={inputClass} value={documento} onChange={(e) => setDocumento(e.target.value)} />
                </Field>
              </div>
            ),
          },
        ]}
      />

      <div className="overflow-x-auto rounded-lg border border-line bg-surface">
        <table className="w-full min-w-[760px] text-left text-sm">
          <thead className="text-xs tracking-wide text-muted uppercase">
            <tr>
              {["Item", "Und", "Previsto", "Recebido", "A receber", "Aplicado", "Saldo", "Uso"].map((h) => (
                <th key={h} className="px-3 py-2 font-medium">
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {lines.map((line) => {
              const s = stockOf(line.id, moves);
              const previsto = Math.max(0, line.qtd);
              const receber = aReceber(previsto, s.recebido);
              const uso = previsto > 0 ? Math.round((s.aplicado / previsto) * 100) : 0;
              return (
                <tr key={line.id} className="border-t border-line">
                  <td className="px-3 py-3">
                    <p className="font-medium">{line.descricao}</p>
                    <p className="text-xs text-muted">
                      {line.codigo || "sem código"}
                      {line.grupoNome ? ` · ${line.grupoNome}` : ""} · {line.secao}
                    </p>
                  </td>
                  <td className="px-3 py-3">{line.unidade}</td>
                  <td className="tabular px-3 py-3">{fmt(previsto)}</td>
                  <td className={"tabular px-3 py-3 " + (receber > 0 ? "text-warn" : "")}>{fmt(s.recebido)}</td>
                  <td className="tabular px-3 py-3">{fmt(receber)}</td>
                  <td className="tabular px-3 py-3">{fmt(s.aplicado)}</td>
                  <td className="tabular px-3 py-3 font-medium">{fmt(s.saldo)}</td>
                  <td className="px-3 py-3">
                    <div className="h-2 w-24 rounded-sm bg-bg">
                      <div className="h-2 rounded-sm bg-primary" style={{ width: `${Math.min(uso, 100)}%` }} />
                    </div>
                    <p className="tabular mt-1 text-xs text-muted">{uso}%</p>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function Movimentos({
  proposalId,
  lines,
  moves,
}: {
  proposalId: string;
  lines: ReturnType<typeof materialLines>;
  moves: StockMove[];
}) {
  const remove = useCrm((s) => s.removeMove);
  const lista = moves.filter((m) => m.proposalId === proposalId);
  if (lista.length === 0) {
    return (
      <p className="flex items-center gap-2 text-sm text-muted">
        <PackageCheck className="size-4" aria-hidden="true" />
        Nenhum movimento nesta obra.
      </p>
    );
  }
  return (
    <ul className="divide-y divide-line rounded-lg border border-line bg-surface">
      {lista.map((m) => {
        const line = lines.find((l) => l.id === m.lineId);
        return (
          <li key={m.id} className="flex items-start justify-between gap-3 px-4 py-3">
            <div>
              <p className="font-medium">
                {MOVE_LABEL[m.tipo]} · {fmt(m.qtd)} {line?.unidade ?? ""}
              </p>
              <p className="text-sm text-muted">{line?.descricao ?? "Item removido da proposta"}</p>
              <p className="text-xs text-muted">
                {formatIso(m.data)}
                {m.responsavel ? ` · ${m.responsavel}` : ""}
                {m.local ? ` · ${m.local}` : ""}
                {m.documento ? ` · ${m.documento}` : ""}
              </p>
            </div>
            <button type="button" onClick={() => remove(m.id)} className="text-danger" aria-label="Excluir movimento">
              <Trash2 className="size-4" aria-hidden="true" />
            </button>
          </li>
        );
      })}
    </ul>
  );
}

function Ativos({
  proposalId,
  lines,
  assets,
}: {
  proposalId: string;
  lines: ReturnType<typeof materialLines>;
  assets: AssetRec[];
}) {
  const upsert = useCrm((s) => s.upsertAsset);
  const remove = useCrm((s) => s.removeAsset);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<AssetRec>(() => emptyAsset(proposalId, lines[0]?.id ?? ""));

  return (
    <div className="space-y-4">
      <button
        type="button"
        onClick={() => {
          setForm(emptyAsset(proposalId, lines[0]?.id ?? ""));
          setOpen(true);
        }}
        className="h-11 rounded-md bg-primary px-4 text-sm font-semibold text-primary-fg"
      >
        Cadastrar ativo
      </button>
      <Wizard
        open={open}
        title="Novo ativo"
        onClose={() => setOpen(false)}
        onSave={() => {
          if (!form.descricao.trim() && !form.patrimonio.trim()) return "Informe o patrimônio ou a descrição.";
          upsert({ ...form, descricao: form.descricao.trim() || lines.find((l) => l.id === form.lineId)?.descricao || "Ativo" });
          setOpen(false);
          return null;
        }}
        steps={[
          {
            title: "De qual item",
            body: (
              <div className="grid gap-3">
                <Field label="Item da proposta">
                  <select className={inputClass} value={form.lineId} onChange={(e) => setForm({ ...form, lineId: e.target.value })}>
                    {lines.map((line) => (
                      <option key={line.id} value={line.id}>
                        {line.descricao}
                      </option>
                    ))}
                  </select>
                </Field>
                <Field label="Descrição">
                  <input className={inputClass} value={form.descricao} onChange={(e) => setForm({ ...form, descricao: e.target.value })} />
                </Field>
              </div>
            ),
          },
          {
            title: "Identificação",
            body: (
              <div className="grid gap-3">
                <Field label="Patrimônio">
                  <input className={inputClass} value={form.patrimonio} onChange={(e) => setForm({ ...form, patrimonio: e.target.value })} />
                </Field>
                <Field label="Série">
                  <input className={inputClass} value={form.serie} onChange={(e) => setForm({ ...form, serie: e.target.value })} />
                </Field>
                <Field label="Status">
                  <select className={inputClass} value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value as AssetStatus })}>
                    {ASSET_STATUS.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.label}
                      </option>
                    ))}
                  </select>
                </Field>
                <Field label="Local">
                  <input className={inputClass} value={form.local} onChange={(e) => setForm({ ...form, local: e.target.value })} />
                </Field>
                <Field label="Responsável">
                  <input className={inputClass} value={form.responsavel} onChange={(e) => setForm({ ...form, responsavel: e.target.value })} />
                </Field>
              </div>
            ),
          },
        ]}
      />

      {assets.length === 0 ? (
        <p className="text-sm text-muted">Nenhum ativo patrimonial nesta obra. Use para rack, câmera, switch e nobreak com série.</p>
      ) : (
        <ul className="divide-y divide-line rounded-lg border border-line bg-surface">
          {assets.map((a) => (
            <li key={a.id} className="flex flex-wrap items-center gap-3 px-4 py-3">
              <div className="min-w-40 flex-1">
                <p className="font-medium">{a.descricao}</p>
                <p className="text-xs text-muted">
                  {a.patrimonio || "sem patrimônio"}
                  {a.serie ? ` · série ${a.serie}` : ""}
                  {a.local ? ` · ${a.local}` : ""}
                </p>
              </div>
              <select
                className="h-9 rounded-md border border-line px-2 text-sm"
                value={a.status}
                onChange={(e) => upsert({ ...a, status: e.target.value as AssetStatus })}
              >
                {ASSET_STATUS.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.label}
                  </option>
                ))}
              </select>
              <button type="button" onClick={() => remove(a.id)} className="text-danger" aria-label="Excluir ativo">
                <Trash2 className="size-4" aria-hidden="true" />
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function Metric({ label, value, hint }: { label: string; value: string; hint: string }) {
  return (
    <article className="card px-5 py-4">
      <p className="text-xs font-medium text-muted">{label}</p>
      <p className="tabular mt-2 text-2xl font-semibold tracking-tight">{value}</p>
      <p className="mt-1 text-sm text-muted">{hint}</p>
    </article>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="block text-sm">
      <span className="mb-1 block font-medium">{label}</span>
      {children}
    </label>
  );
}

function emptyAsset(proposalId: string, lineId: string): AssetRec {
  return {
    id: uid(),
    proposalId,
    lineId,
    patrimonio: "",
    serie: "",
    descricao: "",
    status: "em_estoque",
    local: "",
    responsavel: "",
    data: todayIso(),
  };
}

function fmt(n: number): string {
  return n.toLocaleString("pt-BR", { maximumFractionDigits: 2 });
}
