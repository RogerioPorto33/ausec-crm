import { useMemo, useState, type ReactNode } from "react";
import { FileText, Plus, Trash2 } from "lucide-react";
import { Almoxarifado } from "@/components/crm/Almoxarifado";
import { RdoLista } from "@/components/crm/Rdo";
import { Prazos } from "@/components/crm/Prazos";
import { Wizard } from "@/components/crm/Wizard";
import {
  DOC_TIPOS,
  formatIso,
  labelStatusProposta,
  todayIso,
  uid,
  type Alocacao,
  type DocRec,
  type DocTipo,
  type Evento,
} from "@/lib/crm/model";
import { proposalTotals, useCrm } from "@/lib/crm/store";

const inputClass =
  "h-11 w-full rounded-md border border-line bg-surface px-3 text-sm text-ink outline-none focus:border-primary";

type Aba = "panorama" | "almoxarifado" | "pessoal" | "prazos" | "documentos" | "historico" | "rdo";

export function AdmObra() {
  const proposals = useCrm((s) => s.proposals);
  const projects = useCrm((s) => s.projects);
  const clients = useCrm((s) => s.clients);
  const [aba, setAba] = useState<Aba>("panorama");
  const [projetoId, setProjetoId] = useState(projects[0]?.id ?? "");

  return (
    <section>
      <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Adm de obra</h1>
          <p className="mt-1 max-w-2xl text-sm text-muted">
            Tudo o que a obra gerou: material, equipe, prazo, documento e o que cada um fez.
          </p>
        </div>
        <label className="block min-w-56 text-sm">
          <span className="mb-1 block font-medium">Obra</span>
          <select className={inputClass} value={projetoId} onChange={(e) => setProjetoId(e.target.value)}>
            <option value="">Todas</option>
            {projects.map((p) => (
              <option key={p.id} value={p.id}>
                {p.nome}
              </option>
            ))}
          </select>
        </label>
      </div>

      <div className="mb-4 flex gap-2 overflow-x-auto" role="tablist">
        {(
          [
            ["panorama", "Panorama"],
            ["almoxarifado", "Almoxarifado"],
            ["pessoal", "Pessoal"],
            ["prazos", "Cronograma"],
            ["documentos", "Documentos"],
            ["rdo", "RDO"],
            ["historico", "Histórico"],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            type="button"
            role="tab"
            aria-selected={aba === id}
            onClick={() => setAba(id)}
            className={"h-10 shrink-0 rounded-full px-4 text-sm font-medium " + (aba === id ? "bg-primary text-primary-fg" : "bg-surface text-muted")}
          >
            {label}
          </button>
        ))}
      </div>

      {aba === "panorama" ? <Panorama projetoId={projetoId} /> : null}
      {aba === "almoxarifado" ? <Almoxarifado /> : null}
      {aba === "pessoal" ? <EquipeObra projetoId={projetoId} /> : null}
      {aba === "prazos" ? <Prazos /> : null}
      {aba === "documentos" ? <Documentos projetoId={projetoId} /> : null}
      {aba === "rdo" ? <RdoLista projetoId={projetoId} /> : null}
      {aba === "historico" ? <LinhaDoTempo projetoId={projetoId} proposals={proposals} clients={clients} /> : null}
    </section>
  );
}

function Panorama({ projetoId }: { projetoId: string }) {
  const proposals = useCrm((s) => s.proposals);
  const schedule = useCrm((s) => s.schedule);
  const pessoas = useCrm((s) => s.pessoas);
  const alocacoes = useCrm((s) => s.alocacoes);
  const docs = useCrm((s) => s.docs);
  const moves = useCrm((s) => s.moves);
  const daObra = proposals.filter((p) => !projetoId || p.projetoId === projetoId);
  const prazos = schedule.filter((i) => !projetoId || i.projetoId === projetoId);
  const equipe = alocacoes.filter((a) => !projetoId || a.projetoId === projetoId);
  const arquivos = docs.filter((d) => !projetoId || d.projetoId === projetoId);
  const venda = daObra.reduce((acc, p) => acc + proposalTotals(p.itens).venda, 0);

  return (
    <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
      <Card label="Propostas" value={String(daObra.length)} hint={venda.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })} />
      <Card label="Demandas" value={String(prazos.length)} hint="prazos da obra" />
      <Card label="Equipe" value={String(equipe.length)} hint="alocados nesta obra" />
      <Card label="Documentos" value={String(arquivos.length)} hint={`${moves.length} movimentos de material`} />
    </div>
  );
}

function EquipeObra({ projetoId }: { projetoId: string }) {
  const pessoas = useCrm((s) => s.pessoas);
  const alocacoes = useCrm((s) => s.alocacoes);
  const projects = useCrm((s) => s.projects);
  const upsert = useCrm((s) => s.upsertAlocacao);
  const remove = useCrm((s) => s.removeAlocacao);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<Alocacao>(() => emptyAlocacao(projetoId, pessoas[0]?.id ?? ""));
  const obra = projetoId || projects[0]?.id || "";
  const daObra = alocacoes.filter((a) => !projetoId || a.projetoId === projetoId);

  return (
    <div className="space-y-4">
      <button
        type="button"
        onClick={() => {
          setForm(emptyAlocacao(obra, pessoas[0]?.id ?? ""));
          setOpen(true);
        }}
        className="inline-flex h-11 items-center gap-2 rounded-lg bg-primary px-4 text-sm font-semibold text-primary-fg"
      >
        <Plus className="size-4" aria-hidden="true" />
        Montar equipe
      </button>
      <Wizard
        open={open}
        title="Alocar na obra"
        onClose={() => setOpen(false)}
        onSave={() => {
          if (!form.pessoaId || !form.projetoId) return "Escolha a pessoa e a obra.";
          upsert(form);
          setOpen(false);
          return null;
        }}
        steps={[
          {
            title: "Quem entra",
            valid: () => (form.pessoaId && form.projetoId ? null : "Escolha a pessoa e a obra."),
            body: (
              <div className="grid gap-3">
                <Field label="Pessoa">
                  <select className={inputClass} value={form.pessoaId} onChange={(e) => setForm({ ...form, pessoaId: e.target.value })}>
                    <option value="">Selecione</option>
                    {pessoas.filter((p) => p.ativo).map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.nome}
                      </option>
                    ))}
                  </select>
                </Field>
                <Field label="Obra">
                  <select className={inputClass} value={form.projetoId} onChange={(e) => setForm({ ...form, projetoId: e.target.value })}>
                    {projects.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.nome}
                      </option>
                    ))}
                  </select>
                </Field>
                <Field label="Função nesta obra">
                  <input className={inputClass} value={form.funcao} onChange={(e) => setForm({ ...form, funcao: e.target.value })} placeholder="Técnico de campo, líder, auxiliar" />
                </Field>
              </div>
            ),
          },
          {
            title: "Período",
            body: (
              <div className="grid gap-3 sm:grid-cols-2">
                <Field label="Início">
                  <input className={inputClass} type="date" value={form.inicio} onChange={(e) => setForm({ ...form, inicio: e.target.value })} />
                </Field>
                <Field label="Fim">
                  <input className={inputClass} type="date" value={form.fim} onChange={(e) => setForm({ ...form, fim: e.target.value })} />
                </Field>
              </div>
            ),
          },
        ]}
      />
      {daObra.length === 0 ? (
        <p className="text-sm text-muted">Ninguém alocado nesta obra. Cadastre a pessoa em Pessoal e monte a equipe aqui.</p>
      ) : (
        <ul className="divide-y divide-line rounded-xl border border-line bg-surface">
          {daObra.map((a) => {
            const pessoa = pessoas.find((p) => p.id === a.pessoaId);
            return (
              <li key={a.id} className="flex items-center justify-between gap-3 px-4 py-3">
                <div>
                  <p className="font-medium">{pessoa?.nome ?? "Pessoa removida"}</p>
                  <p className="text-xs text-muted">
                    {a.funcao || pessoa?.funcao || "sem função"}
                    {a.inicio ? ` · ${formatIso(a.inicio)}` : ""}
                    {a.fim ? ` a ${formatIso(a.fim)}` : ""}
                  </p>
                </div>
                <button type="button" onClick={() => remove(a.id)} className="text-danger" aria-label="Remover da obra">
                  <Trash2 className="size-4" aria-hidden="true" />
                </button>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}

function emptyAlocacao(projetoId: string, pessoaId: string): Alocacao {
  return { id: uid(), pessoaId, projetoId, funcao: "", inicio: todayIso(), fim: "" };
}

function Documentos({ projetoId }: { projetoId: string }) {
  const docs = useCrm((s) => s.docs);
  const projects = useCrm((s) => s.projects);
  const proposals = useCrm((s) => s.proposals);
  const upsert = useCrm((s) => s.upsertDoc);
  const remove = useCrm((s) => s.removeDoc);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<DocRec>(() => emptyDoc(projetoId));
  const lista = docs.filter((d) => !projetoId || d.projetoId === projetoId);

  return (
    <div className="space-y-4">
      <button
        type="button"
        onClick={() => {
          setForm(emptyDoc(projetoId || projects[0]?.id || ""));
          setOpen(true);
        }}
        className="inline-flex h-11 items-center gap-2 rounded-lg bg-primary px-4 text-sm font-semibold text-primary-fg"
      >
        <Plus className="size-4" aria-hidden="true" />
        Anexar documento
      </button>
      <Wizard
        open={open}
        title="Novo documento"
        onClose={() => setOpen(false)}
        onSave={() => {
          if (!form.nome.trim()) return "Informe o nome.";
          if (!form.arquivo) return "Anexe o arquivo.";
          upsert({ ...form, nome: form.nome.trim() });
          setOpen(false);
          return null;
        }}
        steps={[
          {
            title: "O que é",
            valid: () => (form.nome.trim() ? null : "Informe o nome."),
            body: (
              <div className="grid gap-3">
                <Field label="Nome">
                  <input className={inputClass} value={form.nome} onChange={(e) => setForm({ ...form, nome: e.target.value })} />
                </Field>
                <Field label="Tipo">
                  <select className={inputClass} value={form.tipo} onChange={(e) => setForm({ ...form, tipo: e.target.value as DocTipo })}>
                    {DOC_TIPOS.map((t) => (
                      <option key={t.id} value={t.id}>
                        {t.label}
                      </option>
                    ))}
                  </select>
                </Field>
                <Field label="Obra">
                  <select className={inputClass} value={form.projetoId} onChange={(e) => setForm({ ...form, projetoId: e.target.value })}>
                    <option value="">Sem obra</option>
                    {projects.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.nome}
                      </option>
                    ))}
                  </select>
                </Field>
                <Field label="Proposta">
                  <select className={inputClass} value={form.proposalId} onChange={(e) => setForm({ ...form, proposalId: e.target.value })}>
                    <option value="">Sem proposta</option>
                    {proposals.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.titulo}
                      </option>
                    ))}
                  </select>
                </Field>
              </div>
            ),
          },
          {
            title: "Arquivo",
            valid: () => (form.arquivo ? null : "Anexe o arquivo."),
            body: (
              <div className="grid gap-3">
                <Field label="Autor">
                  <input className={inputClass} value={form.autor} onChange={(e) => setForm({ ...form, autor: e.target.value })} />
                </Field>
                <Field label="Arquivo">
                  <input
                    className={inputClass}
                    type="file"
                    accept=".pdf,.png,.jpg,.jpeg,.doc,.docx,.xls,.xlsx"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (!file) return;
                      if (file.size > 1_500_000) {
                        setForm({ ...form, nomeArquivo: "", arquivo: "" });
                        return;
                      }
                      const reader = new FileReader();
                      reader.onload = () => setForm({ ...form, nomeArquivo: file.name, arquivo: String(reader.result ?? "") });
                      reader.readAsDataURL(file);
                    }}
                  />
                </Field>
                <p className="text-sm text-muted">{form.nomeArquivo || "PDF, imagem ou planilha, até 1,5 MB."}</p>
              </div>
            ),
          },
        ]}
      />
      {lista.length === 0 ? (
        <p className="flex items-center gap-2 text-sm text-muted">
          <FileText className="size-4" aria-hidden="true" />
          Nenhum documento nesta obra.
        </p>
      ) : (
        <ul className="divide-y divide-line rounded-xl border border-line bg-surface">
          {lista.map((d) => (
            <li key={d.id} className="flex items-center justify-between gap-3 px-4 py-3">
              <div>
                <p className="font-medium">{d.nome}</p>
                <p className="text-xs text-muted">
                  {DOC_TIPOS.find((t) => t.id === d.tipo)?.label} · {formatIso(d.data)}
                  {d.autor ? ` · ${d.autor}` : ""}
                  {d.nomeArquivo ? ` · ${d.nomeArquivo}` : ""}
                </p>
              </div>
              <div className="flex items-center gap-3">
                {d.arquivo ? (
                  <a href={d.arquivo} download={d.nomeArquivo || d.nome} className="text-sm font-medium text-primary">
                    Baixar
                  </a>
                ) : null}
                <button type="button" onClick={() => remove(d.id)} className="text-danger" aria-label="Excluir documento">
                  <Trash2 className="size-4" aria-hidden="true" />
                </button>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function LinhaDoTempo({
  projetoId,
  proposals,
  clients,
}: {
  projetoId: string;
  proposals: { id: string; titulo: string; projetoId: string; status: string; data: string }[];
  clients: { id: string; nome: string }[];
}) {
  const eventos = useCrm((s) => s.eventos);
  const dataDe = useCrm((s) => s.dataDe);
  const dataAte = useCrm((s) => s.dataAte);
  const moves = useCrm((s) => s.moves);
  const schedule = useCrm((s) => s.schedule);
  const docs = useCrm((s) => s.docs);
  const loadProposal = useCrm((s) => s.loadProposal);

  const linha = useMemo(() => {
    const itens: Evento[] = [
      ...eventos,
      ...proposals.map((p) => ({
        id: `prop-${p.id}`,
        data: p.data.slice(0, 10),
        autor: "Equipe",
        origem: "Proposta",
        texto: `${p.titulo} · ${labelStatusProposta(p.status as "rascunho")}`,
        projetoId: p.projetoId,
      })),
      ...moves.map((m) => ({
        id: `mov-${m.id}`,
        data: m.data,
        autor: m.responsavel || "Equipe",
        origem: "Almoxarifado",
        texto: `${m.tipo} de ${m.qtd}${m.documento ? ` · ${m.documento}` : ""}`,
        projetoId: proposals.find((p) => p.id === m.proposalId)?.projetoId ?? "",
      })),
      ...schedule.map((s) => ({
        id: `sch-${s.id}`,
        data: s.inicioPrev || todayIso(),
        autor: s.responsavel || "Equipe",
        origem: "Prazo",
        texto: s.nome,
        projetoId: s.projetoId,
      })),
      ...docs.map((d) => ({
        id: `doc-${d.id}`,
        data: d.data,
        autor: d.autor || "Equipe",
        origem: "Documento",
        texto: d.nome,
        projetoId: d.projetoId,
      })),
    ];
    const vistos = new Set<string>();
    return itens
      .filter((item) => !projetoId || item.projetoId === projetoId)
      .filter((item) => !dataDe || item.data >= dataDe)
      .filter((item) => !dataAte || item.data <= dataAte)
      .filter((item) => {
        const chave = `${item.origem}|${item.texto}|${item.data}`;
        if (vistos.has(chave)) return false;
        vistos.add(chave);
        return true;
      })
      .sort((a, b) => a.data.localeCompare(b.data) || a.texto.localeCompare(b.texto));
  }, [eventos, proposals, moves, schedule, docs, projetoId, dataDe, dataAte]);

  if (linha.length === 0) return <p className="text-sm text-muted">Nada registrado nesta obra ainda.</p>;

  return (
    <ol className="space-y-3">
      {linha.map((item) => (
        <li key={item.id} className="card flex gap-4 px-4 py-3">
          <div className="w-24 shrink-0 text-xs text-muted">{formatIso(item.data)}</div>
          <div className="min-w-0">
            <p className="text-xs font-medium text-primary">{item.origem}</p>
            <p className="text-sm">{item.texto}</p>
            <p className="text-xs text-muted">{item.autor}</p>
          </div>
        </li>
      ))}
      {proposals[0] ? (
        <li>
          <button type="button" onClick={() => loadProposal(proposals[0].id)} className="text-sm font-medium text-primary">
            Abrir última proposta
          </button>
        </li>
      ) : null}
      {clients.length === 0 ? null : null}
    </ol>
  );
}

function Card({ label, value, hint }: { label: string; value: string; hint: string }) {
  return (
    <article className="card px-5 py-4">
      <p className="text-xs font-medium text-muted">{label}</p>
      <p className="tabular mt-2 text-2xl font-semibold">{value}</p>
      <p className="mt-1 text-sm text-muted">{hint}</p>
    </article>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="block text-sm">
      <span className="mb-1 block font-medium">{label}</span>
      {children}
    </label>
  );
}

function emptyDoc(projetoId: string): DocRec {
  return {
    id: uid(),
    projetoId,
    proposalId: "",
    nome: "",
    tipo: "pdf",
    data: todayIso(),
    autor: "",
    nomeArquivo: "",
    arquivo: "",
  };
}
