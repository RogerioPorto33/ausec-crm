import { useEffect, useMemo, useState, type ReactNode } from "react";
import {
  Building2,
  CalendarRange,
  ChevronDown,
  Database,
  Download,
  FilePlus2,
  FolderKanban,
  History,
  LayoutDashboard,
  Mail,
  Package,
  Plus,
  Search,
  Trash2,
  Truck,
  Users,
  Warehouse,
  Wrench,
} from "lucide-react";
import { downloadText, proposalCsv } from "@/lib/crm/export";
import {
  brl,
  CATEGORIAS,
  custoDeGrupo,
  fatorLabel,
  hhFinal,
  labelStatusProjeto,
  labelStatusProposta,
  lineTotal,
  NIVEIS,
  normalizeNivel,
  precoUnit,
  STATUS_PROJETO,
  STATUS_PROPOSTA,
  uid,
  UNIDADES,
  type Client,
  type Line,
  type NivelCriticidade,
  type Product,
  type Project,
  type Proposal,
  type ProposalStatus,
  type ServiceRec,
  type Supplier,
} from "@/lib/crm/model";
import { proposalTotals, useCrm, type ViewId } from "@/lib/crm/store";
import { Admin } from "@/components/crm/Admin";
import { Mensagens } from "@/components/crm/Mensagens";
import { AdmObra } from "@/components/crm/AdmObra";
import { Prazos } from "@/components/crm/Prazos";
import { Almoxarifado } from "@/components/crm/Almoxarifado";
import { Pessoal } from "@/components/crm/Pessoal";
import { Wizard, type WizardStep } from "@/components/crm/Wizard";

const MATRIZES: { id: ViewId; label: string; icon: typeof LayoutDashboard }[] = [
  { id: "fornecedores", label: "Fornecedores", icon: Truck },
  { id: "produtos", label: "Produtos", icon: Package },
  { id: "servicos", label: "Serviços", icon: Wrench },
  { id: "clientes", label: "Clientes", icon: Building2 },
  { id: "projetos", label: "Projetos", icon: FolderKanban },
];

const NAV: { id: ViewId; label: string; icon: typeof LayoutDashboard }[] = [
  { id: "painel", label: "Painel", icon: LayoutDashboard },
  { id: "prazos", label: "Cronograma", icon: CalendarRange },
  { id: "almoxarifado", label: "Almoxarifado", icon: Warehouse },
  { id: "pessoal", label: "Pessoal", icon: Users },
  { id: "proposta", label: "Montar proposta", icon: FilePlus2 },
  { id: "mensagens", label: "Mensagens", icon: Mail },
  { id: "historico", label: "Adm de obra", icon: History },
  { id: "admin", label: "Administração", icon: Database },
];

export function CrmApp() {
  const [ready, setReady] = useState(false);
  const [matrizesAbertas, setMatrizesAbertas] = useState(true);
  const view = useCrm((s) => s.view);
  const notice = useCrm((s) => s.notice);
  const query = useCrm((s) => s.query);
  const dataDe = useCrm((s) => s.dataDe);
  const dataAte = useCrm((s) => s.dataAte);
  const setView = useCrm((s) => s.setView);
  const setQuery = useCrm((s) => s.setQuery);
  const setPeriodo = useCrm((s) => s.setPeriodo);
  const currentUserId = useCrm((s) => s.currentUserId);
  const usuarios = useCrm((s) => s.usuarios);
  const login = useCrm((s) => s.login);
  const logout = useCrm((s) => s.logout);
  const emMatriz = MATRIZES.some((item) => item.id === view);
  const me = usuarios.find((u) => u.id === currentUserId);

  useEffect(() => {
    let cancel = false;
    const finish = () => {
      if (cancel) return;
      useCrm.getState().seedIfEmpty();
      setReady(true);
    };
    if (useCrm.persist.hasHydrated()) finish();
    const unsub = useCrm.persist.onFinishHydration(finish);
    void useCrm.persist.rehydrate();
    return () => {
      cancel = true;
      unsub();
    };
  }, []);

  if (!ready) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-bg px-6 text-ink">
        <div>
          <p className="font-mono text-xs tracking-widest text-primary uppercase">AUSEC</p>
          <h1 className="mt-2 text-2xl font-semibold">Abrindo o CRM</h1>
          <p className="mt-2 text-muted">Bases, listagens e propostas.</p>
        </div>
      </main>
    );
  }

  if (!me) return <Login onLogin={login} />;

  return (
    <div className="min-h-screen bg-bg text-ink">
      <header className="sticky top-0 z-30 border-b border-line bg-surface lg:hidden">
        <div className="flex items-center justify-between px-4 pt-3">
          <p className="text-sm font-semibold text-primary">AUSEC CRM</p>
          <span className="flex size-9 items-center justify-center rounded-full bg-primary text-xs font-semibold text-primary-fg">A</span>
        </div>
        <nav className="flex gap-2 overflow-x-auto px-3 py-3" aria-label="Seções">
          {NAV.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setView(item.id)}
              className={
                "inline-flex h-10 shrink-0 items-center gap-2 rounded-full px-3 text-sm font-medium " +
                (view === item.id ? "bg-primary text-primary-fg" : "bg-bg text-muted")
              }
            >
              <item.icon className="size-4" aria-hidden="true" />
              {item.label}
            </button>
          ))}
          {MATRIZES.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setView(item.id)}
              className={
                "inline-flex h-10 shrink-0 items-center gap-2 rounded-full px-3 text-sm font-medium " +
                (view === item.id ? "bg-primary text-primary-fg" : "bg-bg text-muted")
              }
            >
              {item.label}
            </button>
          ))}
        </nav>
      </header>

      <div className="lg:grid lg:min-h-screen lg:grid-cols-[220px_1fr]">
        <aside className="hidden border-r border-line bg-surface lg:flex lg:flex-col">
          <div className="px-5 pt-6 pb-4">
            <p className="text-sm font-semibold tracking-wide text-primary">AUSEC</p>
            <p className="mt-1 text-xs text-muted">CRM de listagens</p>
          </div>
          <nav className="flex flex-1 flex-col gap-1 px-3" aria-label="Seções">
            {NAV.slice(0, 1).map((item) => (
              <NavButton key={item.id} item={item} active={view === item.id} onClick={() => setView(item.id)} />
            ))}
            <button
              type="button"
              onClick={() => setMatrizesAbertas((v) => !v)}
              className={
                "flex h-10 items-center gap-3 rounded-lg px-3 text-left text-sm font-medium " +
                (emMatriz ? "bg-primary/10 text-primary" : "text-muted hover:bg-bg hover:text-ink")
              }
            >
              <Database className="size-4" aria-hidden="true" />
              Matrizes
            </button>
            {matrizesAbertas
              ? MATRIZES.map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setView(item.id)}
                    className={
                      "flex h-9 items-center gap-3 rounded-lg pr-3 pl-9 text-left text-sm " +
                      (view === item.id ? "bg-primary/10 font-medium text-primary" : "text-muted hover:bg-bg hover:text-ink")
                    }
                  >
                    {item.label}
                  </button>
                ))
              : null}
            {NAV.slice(1).map((item) => (
              <NavButton key={item.id} item={item} active={view === item.id} onClick={() => setView(item.id)} />
            ))}
          </nav>
          <p className="px-5 py-5 text-xs leading-relaxed text-muted">Dados salvos neste navegador.</p>
        </aside>

        <div className="min-w-0">
          <header className="sticky top-0 z-20 hidden items-center gap-3 border-b border-line bg-surface/90 px-6 py-3 backdrop-blur lg:flex">
            <label className="relative max-w-xs flex-1">
              <Search className="pointer-events-none absolute top-2.5 left-3 size-4 text-muted" aria-hidden="true" />
              <input
                className="h-10 w-full rounded-lg border border-line bg-bg pr-3 pl-9 text-sm outline-none focus:border-primary"
                placeholder="Buscar nesta página"
                aria-label="Buscar"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
              />
            </label>
            <label className="inline-flex h-10 items-center gap-2 rounded-lg border border-line bg-bg px-3 text-sm text-muted">
              <CalendarRange className="size-4" aria-hidden="true" />
              <span className="sr-only">De</span>
              <input type="date" className="bg-transparent text-sm text-ink outline-none" value={dataDe} onChange={(e) => setPeriodo(e.target.value, dataAte)} aria-label="Data inicial" />
              <span>até</span>
              <span className="sr-only">Até</span>
              <input type="date" className="bg-transparent text-sm text-ink outline-none" value={dataAte} onChange={(e) => setPeriodo(dataDe, e.target.value)} aria-label="Data final" />
            </label>
            <span className="ml-auto flex items-center gap-2">
              <span className="text-sm text-muted">{me.nome}</span>
              <button type="button" onClick={logout} className="h-9 rounded-lg border border-line px-3 text-sm">Sair</button>
            </span>
          </header>
          <main className="mx-auto w-full max-w-6xl px-4 py-6 lg:px-8 lg:py-7">
            {notice ? <p className="mb-4 rounded-lg border border-line bg-surface px-4 py-3 text-sm text-ok">{notice}</p> : null}
            {view === "painel" ? <Painel /> : null}
            {view === "fornecedores" ? <Fornecedores /> : null}
            {view === "produtos" ? <Produtos /> : null}
            {view === "servicos" ? <Servicos /> : null}
            {view === "clientes" ? <Clientes /> : null}
            {view === "projetos" ? <Projetos /> : null}
            {view === "prazos" ? <Prazos /> : null}
            {view === "almoxarifado" ? <Almoxarifado /> : null}
            {view === "pessoal" ? <Pessoal /> : null}
            {view === "proposta" ? <Proposta /> : null}
            {view === "mensagens" ? <Mensagens /> : null}
            {view === "historico" ? <AdmObra /> : null}
            {view === "admin" ? <Admin /> : null}
          </main>
        </div>
      </div>
    </div>
  );
}

function Login({ onLogin }: { onLogin: (email: string, senha: string) => string | null }) {
  const [email, setEmail] = useState("admin@ausec.local");
  const [senha, setSenha] = useState("ausec");
  const [erro, setErro] = useState("");
  return (
    <main className="flex min-h-screen items-center justify-center bg-bg px-6 text-ink">
      <form
        className="card w-full max-w-sm space-y-3 p-6"
        onSubmit={(e) => {
          e.preventDefault();
          const msg = onLogin(email, senha);
          setErro(msg ?? "");
        }}
      >
        <p className="font-mono text-xs tracking-widest text-primary uppercase">AUSEC</p>
        <h1 className="text-2xl font-semibold">Entrar</h1>
        <label className="block text-sm">
          E-mail
          <input className="mt-1 h-11 w-full rounded-md border border-line px-3" value={email} onChange={(e) => setEmail(e.target.value)} />
        </label>
        <label className="block text-sm">
          Senha
          <input className="mt-1 h-11 w-full rounded-md border border-line px-3" type="password" value={senha} onChange={(e) => setSenha(e.target.value)} />
        </label>
        {erro ? <p className="text-sm text-danger">{erro}</p> : null}
        <button type="submit" className="h-11 w-full rounded-md bg-primary text-sm font-semibold text-primary-fg">Entrar</button>
        <p className="text-xs text-muted">Demo: admin@ausec.local / ausec</p>
      </form>
    </main>
  );
}

function PageHead({ title, text, action }: { title: string; text: string; action?: ReactNode }) {
  return (
    <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">{title}</h1>
        <p className="mt-1 max-w-2xl text-sm text-pretty text-muted">{text}</p>
      </div>
      {action}
    </div>
  );
}

function NavButton({
  item,
  active,
  onClick,
}: {
  item: { id: ViewId; label: string; icon: typeof LayoutDashboard };
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={
        "flex h-10 items-center gap-3 rounded-lg px-3 text-left text-sm font-medium " +
        (active ? "bg-primary/10 text-primary" : "text-muted hover:bg-bg hover:text-ink")
      }
    >
      <item.icon className="size-4" aria-hidden="true" />
      {item.label}
    </button>
  );
}

function Painel() {
  const products = useCrm((s) => s.products);
  const services = useCrm((s) => s.services);
  const clients = useCrm((s) => s.clients);
  const proposals = useCrm((s) => s.proposals);
  const pessoas = useCrm((s) => s.pessoas);
  const schedule = useCrm((s) => s.schedule);
  const setView = useCrm((s) => s.setView);
  const newDraft = useCrm((s) => s.newDraft);
  const pipeline = proposals.reduce((acc, p) => acc + proposalTotals(p.itens).venda, 0);
  const aprovadas = proposals.filter((p) => p.status === "aprovada").length;
  const taxa = proposals.length ? Math.round((aprovadas / proposals.length) * 100) : 0;
  const porStatus = STATUS_PROPOSTA.map((s) => proposals.filter((p) => p.status === s.id).length);

  return (
    <section>
      <PageHead
        title="Painel"
        text="O essencial primeiro. Detalhe fica um clique abaixo."
        action={
          <button type="button" onClick={newDraft} className="inline-flex h-10 items-center gap-2 rounded-lg bg-primary px-4 text-sm font-semibold text-primary-fg">
            <Plus className="size-4" aria-hidden="true" />
            Nova proposta
          </button>
        }
      />
      <div className="grid gap-4 xl:grid-cols-[240px_1fr]">
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-1">
          <article className="card px-5 py-5">
            <p className="text-xs font-medium text-muted">Propostas</p>
            <p className="tabular mt-3 text-4xl font-semibold tracking-tight">{proposals.length}</p>
            <div className="mt-3 h-1.5 w-20 rounded-full bg-primary" />
          </article>
          <article className="card px-5 py-5">
            <p className="text-xs font-medium text-muted">Valor em carteira</p>
            <p className="tabular mt-3 text-3xl font-semibold tracking-tight">{brl(pipeline)}</p>
            <div className="mt-3 h-1.5 w-20 rounded-full bg-primary/40" />
          </article>
        </div>
        <article className="card p-5">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-sm font-semibold">Valor das propostas</h2>
            <span className="text-xs text-muted">histórico</span>
          </div>
          <LineChart values={proposals.slice(0, 8).map((p) => proposalTotals(p.itens).venda)} />
        </article>
      </div>
      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        <article className="card p-5">
          <h2 className="text-sm font-semibold">Aprovação</h2>
          <Donut value={taxa} />
          <div className="mt-3 space-y-1 text-xs text-muted">
            <p className="flex justify-between"><span>Aprovadas</span><span className="tabular text-ink">{aprovadas}</span></p>
            <p className="flex justify-between"><span>Total</span><span className="tabular text-ink">{proposals.length}</span></p>
          </div>
        </article>
        <article className="card p-5">
          <h2 className="text-sm font-semibold">Últimas propostas</h2>
          {proposals.length === 0 ? (
            <p className="mt-4 text-sm text-muted">Nenhuma proposta ainda.</p>
          ) : (
            <ul className="mt-3 space-y-3">
              {proposals.slice(0, 4).map((p) => (
                <li key={p.id} className="flex items-center gap-3">
                  <span className="size-2 rounded-full bg-primary/40" />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium">{p.titulo}</p>
                    <p className="text-xs text-muted">{labelStatusProposta(p.status)}</p>
                  </div>
                  <p className="tabular text-xs text-muted">{brl(proposalTotals(p.itens).venda)}</p>
                </li>
              ))}
            </ul>
          )}
          <button type="button" onClick={() => setView("historico")} className="mt-4 text-sm font-medium text-primary">
            Abrir adm de obra
          </button>
        </article>
        <article className="card p-5">
          <h2 className="text-sm font-semibold">Base e equipe</h2>
          <Bars values={[products.length, services.length, clients.length, pessoas.length, schedule.length]} labels={["Prod.", "Serv.", "Cli.", "Pess.", "Praz."]} />
          <div className="mt-4 grid grid-cols-2 gap-2 text-xs text-muted">
            {porStatus.map((n, i) => (
              <p key={STATUS_PROPOSTA[i].id} className="flex justify-between">
                <span>{STATUS_PROPOSTA[i].label}</span>
                <span className="tabular text-ink">{n}</span>
              </p>
            ))}
          </div>
        </article>
      </div>
    </section>
  );
}

function LineChart({ values }: { values: number[] }) {
  const data = values.length ? values : [0];
  const max = Math.max(...data, 1);
  const w = 520;
  const h = 180;
  const points = data
    .map((v, i) => {
      const x = data.length === 1 ? w / 2 : (i / (data.length - 1)) * (w - 24) + 12;
      const y = h - 16 - (v / max) * (h - 32);
      return `${x},${y}`;
    })
    .join(" ");
  const area = `12,${h - 16} ${points} ${w - 12},${h - 16}`;
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="h-44 w-full" role="img" aria-label="Gráfico de valor">
      {[0.25, 0.5, 0.75].map((t) => (
        <line key={t} x1="12" x2={w - 12} y1={h - 16 - t * (h - 32)} y2={h - 16 - t * (h - 32)} stroke="#e6edf5" />
      ))}
      <polygon points={area} fill="#2563eb" opacity="0.12" />
      <polyline points={points} fill="none" stroke="#2563eb" strokeWidth="3" strokeLinejoin="round" strokeLinecap="round" />
    </svg>
  );
}

function Donut({ value }: { value: number }) {
  const r = 42;
  const c = 2 * Math.PI * r;
  const dash = (Math.min(value, 100) / 100) * c;
  return (
    <div className="relative mx-auto mt-4 size-36">
      <svg viewBox="0 0 120 120" className="size-full -rotate-90">
        <circle cx="60" cy="60" r={r} fill="none" stroke="#e6edf5" strokeWidth="12" />
        <circle cx="60" cy="60" r={r} fill="none" stroke="#2563eb" strokeWidth="12" strokeDasharray={`${dash} ${c - dash}`} strokeLinecap="round" />
      </svg>
      <p className="tabular absolute inset-0 flex items-center justify-center text-2xl font-semibold">{value}%</p>
    </div>
  );
}

function Bars({ values, labels }: { values: number[]; labels: string[] }) {
  const max = Math.max(...values, 1);
  return (
    <div className="mt-5 flex h-28 items-end gap-3">
      {values.map((v, i) => (
        <div key={labels[i]} className="flex flex-1 flex-col items-center gap-2">
          <div className="flex h-20 w-full items-end">
            <div className="w-full rounded-sm bg-primary/80" style={{ height: `${Math.max(8, (v / max) * 100)}%` }} />
          </div>
          <span className="text-[10px] text-muted">{labels[i]}</span>
        </div>
      ))}
    </div>
  );
}

function Metric({ label, value, hint }: { label: string; value: string; hint: string }) {
  return (
    <article className="card px-5 py-4">
      <p className="text-xs font-medium text-muted">{label}</p>
      <p className="tabular mt-2 text-2xl font-semibold tracking-tight">{value}</p>
      <p className="mt-1 text-sm text-muted">{hint}</p>
    </article>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="block text-sm">
      <span className="mb-1 block font-medium">{label}</span>
      {children}
    </label>
  );
}

const inputClass =
  "h-11 w-full rounded-md border border-line bg-surface px-3 text-sm text-ink outline-none focus:border-primary";
const areaClass =
  "min-h-20 w-full rounded-md border border-line bg-surface px-3 py-2 text-sm text-ink outline-none focus:border-primary";

function Fornecedores() {
  const rows = useCrm((s) => s.suppliers);
  const upsert = useCrm((s) => s.upsertSupplier);
  const remove = useCrm((s) => s.removeSupplier);
  const blank = (): Supplier => ({ id: uid(), nome: "", contato: "", email: "", telefone: "", cnpj: "", observacoes: "" });
  return (
    <EditorList
      title="Fornecedores"
      text="Quem fornece equipamento e material. O vínculo entra no cadastro do produto."
      rows={rows}
      blank={blank}
      onSave={upsert}
      onRemove={remove}
      searchOf={(r) => `${r.nome} ${r.contato} ${r.cnpj}`}
      columns={[
        { key: "nome", label: "Nome" },
        { key: "contato", label: "Contato" },
        { key: "telefone", label: "Telefone" },
      ]}
      form={(row, set) => (
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Nome">
            <input className={inputClass} value={row.nome} onChange={(e) => set({ ...row, nome: e.target.value })} />
          </Field>
          <Field label="Contato">
            <input className={inputClass} value={row.contato} onChange={(e) => set({ ...row, contato: e.target.value })} />
          </Field>
          <Field label="E-mail">
            <input className={inputClass} value={row.email} onChange={(e) => set({ ...row, email: e.target.value })} />
          </Field>
          <Field label="Telefone">
            <input className={inputClass} value={row.telefone} onChange={(e) => set({ ...row, telefone: e.target.value })} />
          </Field>
          <Field label="CNPJ">
            <input className={inputClass} value={row.cnpj} onChange={(e) => set({ ...row, cnpj: e.target.value })} />
          </Field>
          <Field label="Observações">
            <input className={inputClass} value={row.observacoes} onChange={(e) => set({ ...row, observacoes: e.target.value })} />
          </Field>
        </div>
      )}
      steps={(row, set) => [
        {
          title: "Quem é o fornecedor",
          valid: () => (row.nome.trim() ? null : "Informe o nome."),
          body: (
            <div className="grid gap-3">
              <Field label="Nome">
                <input className={inputClass} value={row.nome} onChange={(e) => set({ ...row, nome: e.target.value })} />
              </Field>
              <Field label="Contato">
                <input className={inputClass} value={row.contato} onChange={(e) => set({ ...row, contato: e.target.value })} />
              </Field>
              <Field label="CNPJ">
                <input className={inputClass} value={row.cnpj} onChange={(e) => set({ ...row, cnpj: e.target.value })} />
              </Field>
            </div>
          ),
        },
        {
          title: "Como falar com ele",
          body: (
            <div className="grid gap-3">
              <Field label="E-mail">
                <input className={inputClass} value={row.email} onChange={(e) => set({ ...row, email: e.target.value })} />
              </Field>
              <Field label="Telefone">
                <input className={inputClass} value={row.telefone} onChange={(e) => set({ ...row, telefone: e.target.value })} />
              </Field>
              <Field label="Observações">
                <input className={inputClass} value={row.observacoes} onChange={(e) => set({ ...row, observacoes: e.target.value })} />
              </Field>
            </div>
          ),
        },
      ]}
      valid={(row) => (row.nome.trim() ? null : "Informe o nome.")}
    />
  );
}

function Produtos() {
  const rows = useCrm((s) => s.products);
  const suppliers = useCrm((s) => s.suppliers);
  const upsert = useCrm((s) => s.upsertProduct);
  const remove = useCrm((s) => s.removeProduct);
  const blank = (): Product => ({
    id: uid(),
    codigo: "",
    descricao: "",
    fabricante: "",
    unidade: "UND",
    categoria: CATEGORIAS[0],
    fornecedorId: "",
    custo: 0,
    tipo: "produto",
    foto: "",
    componentes: [],
  });
  return (
    <EditorList
      title="Produtos e equipamentos"
      text="Foto no item. Um grupo, como o rack indoor, reúne produtos já cadastrados."
      rows={rows}
      blank={blank}
      onSave={(row) =>
        upsert({
          ...row,
          foto: row.foto ?? "",
          fabricante: row.tipo === "grupo" ? "" : row.fabricante,
          componentes: row.tipo === "grupo" ? (row.componentes ?? []).filter((item) => item.qtd > 0) : [],
          custo: row.tipo === "grupo" ? custoDeGrupo(row, rows) : row.custo,
        })
      }
      onRemove={remove}
      searchOf={(r) => `${r.codigo} ${r.descricao} ${r.fabricante} ${r.categoria} ${r.tipo}`}
      columns={[
        {
          key: "foto",
          label: "Foto",
          render: (r) =>
            r.foto ? <img src={r.foto} alt="" className="h-11 w-11 rounded-md object-cover" /> : <span className="text-muted">—</span>,
        },
        { key: "codigo", label: "Código" },
        { key: "descricao", label: "Descrição" },
        {
          key: "tipo",
          label: "Tipo",
          render: (r) => (r.tipo === "grupo" ? `Grupo · ${(r.componentes ?? []).length}` : r.tipo === "equipamento" ? "Equipamento" : "Produto"),
        },
        {
          key: "custo",
          label: "Custo",
          render: (r) => brl(r.tipo === "grupo" ? custoDeGrupo(r, rows) : r.custo),
        },
      ]}
      form={(row, set) => <ProductFields row={row} set={set} products={rows} suppliers={suppliers} />}
      steps={(row, set) => [
        {
          title: "O que é o item",
          valid: () => (row.descricao.trim() ? null : "Informe a descrição."),
          body: (
            <div className="grid gap-3">
              <Field label="Tipo">
                <select className={inputClass} value={row.tipo} onChange={(e) => set({ ...row, tipo: e.target.value as Product["tipo"] })}>
                  <option value="produto">Produto</option>
                  <option value="equipamento">Equipamento</option>
                  <option value="grupo">Grupo de itens</option>
                </select>
              </Field>
              <Field label="Código">
                <input className={inputClass} value={row.codigo} onChange={(e) => set({ ...row, codigo: e.target.value })} />
              </Field>
              <Field label={row.tipo === "grupo" ? "Nome do grupo" : "Descrição"}>
                <input className={inputClass} value={row.descricao} onChange={(e) => set({ ...row, descricao: e.target.value })} />
              </Field>
            </div>
          ),
        },
        {
          title: "Classificação e custo",
          body: <ProductFields row={row} set={set} products={rows} suppliers={suppliers} compact />,
        },
      ]}
      valid={(row) => {
        if (!row.descricao.trim()) return "Informe a descrição.";
        if (row.tipo === "grupo" && (row.componentes ?? []).length === 0) return "Inclua ao menos um item no grupo.";
        return null;
      }}
    />
  );
}

function ProductFields({
  row,
  set,
  products,
  suppliers,
  compact,
}: {
  row: Product;
  set: (row: Product) => void;
  products: Product[];
  suppliers: Supplier[];
  compact?: boolean;
}) {
  const [compId, setCompId] = useState("");
  const [compQtd, setCompQtd] = useState(1);
  const [fotoErro, setFotoErro] = useState("");
  const avulsos = products.filter((product) => product.id !== row.id && product.tipo !== "grupo");
  const componentes = row.componentes ?? [];

  return (
    <div className="grid gap-3 sm:grid-cols-2">
      <div className="sm:col-span-2 flex flex-wrap items-center gap-3">
        <label className="flex h-24 w-24 cursor-pointer items-center justify-center overflow-hidden rounded-md border border-dashed border-line bg-bg text-center text-xs text-muted">
          {row.foto ? (
            <img src={row.foto} alt="Foto do item" className="h-full w-full object-cover" />
          ) : (
            "Inserir foto"
          )}
          <input
            className="sr-only"
            type="file"
            accept="image/*"
            onChange={(event) => {
              const file = event.target.files?.[0];
              event.target.value = "";
              if (!file) return;
              void compressImage(file)
                .then((foto) => {
                  setFotoErro("");
                  set({ ...row, foto });
                })
                .catch(() => setFotoErro("Não foi possível ler essa imagem."));
            }}
          />
        </label>
        <div>
          <p className="text-sm text-muted">A foto fica salva só neste navegador.</p>
          {row.foto ? (
            <button type="button" onClick={() => set({ ...row, foto: "" })} className="mt-2 h-10 text-sm text-danger">
              Remover foto
            </button>
          ) : null}
          {fotoErro ? <p className="mt-1 text-sm text-danger">{fotoErro}</p> : null}
        </div>
      </div>
      <Field label="Código">
        <input className={inputClass} value={row.codigo} onChange={(e) => set({ ...row, codigo: e.target.value })} />
      </Field>
      {compact ? null : (
        <>
          <Field label="Tipo">
            <select className={inputClass} value={row.tipo} onChange={(e) => set({ ...row, tipo: e.target.value as Product["tipo"] })}>
              <option value="produto">Produto</option>
              <option value="equipamento">Equipamento</option>
              <option value="grupo">Grupo de itens</option>
            </select>
          </Field>
          <div className="sm:col-span-2">
            <Field label={row.tipo === "grupo" ? "Nome do grupo" : "Descrição"}>
              <input className={inputClass} value={row.descricao} onChange={(e) => set({ ...row, descricao: e.target.value })} />
            </Field>
          </div>
        </>
      )}
      {row.tipo === "grupo" ? null : (
        <Field label="Fabricante">
          <input className={inputClass} value={row.fabricante} onChange={(e) => set({ ...row, fabricante: e.target.value })} />
        </Field>
      )}
      <Field label="Fornecedor">
        <select className={inputClass} value={row.fornecedorId} onChange={(e) => set({ ...row, fornecedorId: e.target.value })}>
          <option value="">Sem vínculo</option>
          {suppliers.map((supplier) => (
            <option key={supplier.id} value={supplier.id}>
              {supplier.nome}
            </option>
          ))}
        </select>
      </Field>
      <Field label="Seção">
        <select className={inputClass} value={row.categoria} onChange={(e) => set({ ...row, categoria: e.target.value })}>
          {CATEGORIAS.map((categoria) => (
            <option key={categoria}>{categoria}</option>
          ))}
        </select>
      </Field>
      <Field label="Unidade">
        <select className={inputClass} value={row.unidade} onChange={(e) => set({ ...row, unidade: e.target.value })}>
          {UNIDADES.map((unidade) => (
            <option key={unidade}>{unidade}</option>
          ))}
          <option value="CX">CX</option>
        </select>
      </Field>
      {row.tipo === "grupo" ? (
        <div className="sm:col-span-2 rounded-md border border-line p-3">
          <p className="text-sm font-medium">Itens do grupo</p>
          <p className="mt-1 text-sm text-muted">Somente produtos já cadastrados. O custo do grupo é a soma.</p>
          <div className="mt-3 grid gap-3 sm:grid-cols-[1fr_120px_auto]">
            <select className={inputClass} value={compId} onChange={(e) => setCompId(e.target.value)} aria-label="Item do grupo">
              <option value="">Selecionar item</option>
              {avulsos.map((product) => (
                <option key={product.id} value={product.id}>
                  {product.codigo ? `${product.codigo} · ` : ""}
                  {product.descricao}
                </option>
              ))}
            </select>
            <input
              className={inputClass}
              type="number"
              min={0}
              step="1"
              value={compQtd}
              aria-label="Quantidade no grupo"
              onChange={(e) => setCompQtd(Number(e.target.value))}
            />
            <button
              type="button"
              className="h-11 rounded-md bg-primary px-4 text-sm font-semibold text-primary-fg"
              onClick={() => {
                if (!compId || compQtd <= 0) return;
                const atuais = row.componentes ?? [];
                const existente = atuais.find((item) => item.productId === compId);
                const componentesNovos = existente
                  ? atuais.map((item) => (item.productId === compId ? { ...item, qtd: item.qtd + compQtd } : item))
                  : [...atuais, { productId: compId, qtd: compQtd }];
                set({ ...row, componentes: componentesNovos });
                setCompId("");
                setCompQtd(1);
              }}
            >
              Incluir
            </button>
          </div>
          {componentes.length === 0 ? (
            <p className="mt-3 text-sm text-muted">Nenhum item neste grupo.</p>
          ) : (
            <ul className="mt-3 divide-y divide-line">
              {componentes.map((item) => {
                const product = products.find((entry) => entry.id === item.productId);
                return (
                  <li key={item.productId} className="flex items-center justify-between gap-3 py-2 text-sm">
                    <span className="min-w-0">{product?.descricao ?? "Item removido"}</span>
                    <input
                      className={inputClass + " w-24"}
                      type="number"
                      min={0}
                      step="1"
                      aria-label={`Quantidade de ${product?.descricao ?? "item"}`}
                      value={item.qtd}
                      onChange={(event) =>
                        set({
                          ...row,
                          componentes: componentes.map((entry) =>
                            entry.productId === item.productId ? { ...entry, qtd: Number(event.target.value) } : entry,
                          ),
                        })
                      }
                    />
                    <button
                      type="button"
                      className="h-10 shrink-0 px-2 text-danger"
                      onClick={() =>
                        set({ ...row, componentes: componentes.filter((entry) => entry.productId !== item.productId) })
                      }
                    >
                      Tirar
                    </button>
                  </li>
                );
              })}
            </ul>
          )}
          <p className="tabular mt-3 text-sm font-medium">Custo do grupo: {brl(custoDeGrupo(row, products))}</p>
        </div>
      ) : (
        <Field label="Custo base (R$)">
          <input
            className={inputClass}
            type="number"
            min={0}
            step="0.01"
            value={row.custo}
            onChange={(e) => set({ ...row, custo: Number(e.target.value) })}
          />
        </Field>
      )}
    </div>
  );
}

function compressImage(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("leitura"));
    reader.onload = () => {
      const image = new Image();
      image.onerror = () => reject(new Error("imagem"));
      image.onload = () => {
        const max = 480;
        const scale = Math.min(1, max / Math.max(image.width, image.height));
        const canvas = document.createElement("canvas");
        canvas.width = Math.max(1, Math.round(image.width * scale));
        canvas.height = Math.max(1, Math.round(image.height * scale));
        const context = canvas.getContext("2d");
        if (!context) {
          reject(new Error("canvas"));
          return;
        }
        context.drawImage(image, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL("image/jpeg", 0.68));
      };
      image.src = String(reader.result);
    };
    reader.readAsDataURL(file);
  });
}

function Servicos() {
  const rows = useCrm((s) => s.services);
  const upsert = useCrm((s) => s.upsertService);
  const remove = useCrm((s) => s.removeService);
  const blank = (): ServiceRec => ({
    id: uid(),
    codigo: "",
    descricao: "",
    unidade: "SV",
    categoria: "Serviços",
    hhBase: 0,
    nivel: 1,
    custo: 0,
  });
  return (
    <EditorList
      title="Serviços"
      text="O nível de 1 a 4 multiplica o HH base. Na proposta, o HH final sobe para a hora inteira e já inclui a sobra técnica de 10%."
      rows={rows}
      blank={blank}
      onSave={(row) => upsert({ ...row, nivel: normalizeNivel(row.nivel) })}
      onRemove={remove}
      searchOf={(r) => `${r.codigo} ${r.descricao}`}
      columns={[
        { key: "codigo", label: "Código" },
        { key: "descricao", label: "Descrição" },
        { key: "hhBase", label: "HH base" },
        { key: "nivel", label: "Nível", render: (r) => String(normalizeNivel(r.nivel)) },
        { key: "fator", label: "Fator", render: (r) => fatorLabel(r.nivel) },
        { key: "hh", label: "HH (1 un)", render: (r) => String(hhFinal(r.hhBase, 1, r.nivel)) },
        { key: "custo", label: "Custo", render: (r) => brl(r.custo) },
      ]}
      form={(row, set) => (
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Código">
            <input className={inputClass} value={row.codigo} onChange={(e) => set({ ...row, codigo: e.target.value })} />
          </Field>
          <Field label="Unidade">
            <select className={inputClass} value={row.unidade} onChange={(e) => set({ ...row, unidade: e.target.value })}>
              {UNIDADES.map((u) => (
                <option key={u}>{u}</option>
              ))}
            </select>
          </Field>
          <div className="sm:col-span-2">
            <Field label="Descrição">
              <input className={inputClass} value={row.descricao} onChange={(e) => set({ ...row, descricao: e.target.value })} />
            </Field>
          </div>
          <Field label="HH base">
            <input
              className={inputClass}
              type="number"
              min={0}
              step="0.1"
              value={row.hhBase}
              onChange={(e) => set({ ...row, hhBase: Number(e.target.value) })}
            />
          </Field>
          <Field label="Nível de criticidade">
            <select
              className={inputClass}
              value={normalizeNivel(row.nivel)}
              onChange={(e) => set({ ...row, nivel: Number(e.target.value) as NivelCriticidade })}
            >
              {NIVEIS.map((item) => (
                <option key={item.nivel} value={item.nivel}>
                  {item.nivel} · fator {fatorLabel(item.nivel)}
                </option>
              ))}
            </select>
          </Field>
          <p className="text-sm text-muted sm:col-span-2">
            {NIVEIS.find((item) => item.nivel === normalizeNivel(row.nivel))?.descricao}. HH de 1 unidade:{" "}
            <span className="tabular font-medium text-ink">{hhFinal(row.hhBase, 1, row.nivel)} h</span>
            {" "}(base {row.hhBase || 0} × {fatorLabel(row.nivel)} × 1,10, para cima).
          </p>
          <Field label="Custo (R$)">
            <input
              className={inputClass}
              type="number"
              min={0}
              step="0.01"
              value={row.custo}
              onChange={(e) => set({ ...row, custo: Number(e.target.value) })}
            />
          </Field>
        </div>
      )}
      valid={(row) => (row.descricao.trim() ? null : "Informe a descrição.")}
      steps={(row, set) => [
        {
          title: "O que é o serviço",
          valid: () => (row.descricao.trim() ? null : "Informe a descrição."),
          body: (
            <div className="grid gap-3">
              <Field label="Código">
                <input className={inputClass} value={row.codigo} onChange={(e) => set({ ...row, codigo: e.target.value })} />
              </Field>
              <Field label="Descrição">
                <input className={inputClass} value={row.descricao} onChange={(e) => set({ ...row, descricao: e.target.value })} />
              </Field>
              <Field label="Unidade">
                <select className={inputClass} value={row.unidade} onChange={(e) => set({ ...row, unidade: e.target.value })}>
                  {UNIDADES.map((u) => (
                    <option key={u}>{u}</option>
                  ))}
                </select>
              </Field>
            </div>
          ),
        },
        {
          title: "HH e custo",
          body: (
            <div className="grid gap-3">
              <Field label="HH base">
                <input className={inputClass} type="number" min={0} step="0.1" value={row.hhBase} onChange={(e) => set({ ...row, hhBase: Number(e.target.value) })} />
              </Field>
              <Field label="Nível de criticidade">
                <select className={inputClass} value={normalizeNivel(row.nivel)} onChange={(e) => set({ ...row, nivel: Number(e.target.value) as NivelCriticidade })}>
                  {NIVEIS.map((item) => (
                    <option key={item.nivel} value={item.nivel}>
                      {item.nivel} · fator {fatorLabel(item.nivel)}
                    </option>
                  ))}
                </select>
              </Field>
              <p className="text-sm text-muted">
                HH de 1 unidade: <span className="tabular font-medium text-ink">{hhFinal(row.hhBase, 1, row.nivel)} h</span>
              </p>
              <Field label="Custo (R$)">
                <input className={inputClass} type="number" min={0} step="0.01" value={row.custo} onChange={(e) => set({ ...row, custo: Number(e.target.value) })} />
              </Field>
            </div>
          ),
        },
      ]}
    />
  );
}

function Clientes() {
  const rows = useCrm((s) => s.clients);
  const upsert = useCrm((s) => s.upsertClient);
  const remove = useCrm((s) => s.removeClient);
  const blank = (): Client => ({ id: uid(), nome: "", contato: "", email: "", telefone: "", cidade: "", estado: "" });
  return (
    <EditorList
      title="Clientes"
      text="Empresa para a qual a proposta será emitida."
      rows={rows}
      blank={blank}
      onSave={upsert}
      onRemove={remove}
      searchOf={(r) => `${r.nome} ${r.cidade} ${r.contato}`}
      columns={[
        { key: "nome", label: "Nome" },
        { key: "cidade", label: "Cidade" },
        { key: "estado", label: "UF" },
      ]}
      form={(row, set) => (
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Nome">
            <input className={inputClass} value={row.nome} onChange={(e) => set({ ...row, nome: e.target.value })} />
          </Field>
          <Field label="Contato">
            <input className={inputClass} value={row.contato} onChange={(e) => set({ ...row, contato: e.target.value })} />
          </Field>
          <Field label="E-mail">
            <input className={inputClass} value={row.email} onChange={(e) => set({ ...row, email: e.target.value })} />
          </Field>
          <Field label="Telefone">
            <input className={inputClass} value={row.telefone} onChange={(e) => set({ ...row, telefone: e.target.value })} />
          </Field>
          <Field label="Cidade">
            <input className={inputClass} value={row.cidade} onChange={(e) => set({ ...row, cidade: e.target.value })} />
          </Field>
          <Field label="UF">
            <input
              className={inputClass}
              maxLength={2}
              value={row.estado}
              onChange={(e) => set({ ...row, estado: e.target.value.toUpperCase() })}
            />
          </Field>
        </div>
      )}
      valid={(row) => (row.nome.trim() ? null : "Informe o nome.")}
      steps={(row, set) => [
        {
          title: "A empresa",
          valid: () => (row.nome.trim() ? null : "Informe o nome."),
          body: (
            <div className="grid gap-3">
              <Field label="Nome">
                <input className={inputClass} value={row.nome} onChange={(e) => set({ ...row, nome: e.target.value })} />
              </Field>
              <Field label="Contato">
                <input className={inputClass} value={row.contato} onChange={(e) => set({ ...row, contato: e.target.value })} />
              </Field>
            </div>
          ),
        },
        {
          title: "Contato e local",
          body: (
            <div className="grid gap-3">
              <Field label="E-mail">
                <input className={inputClass} value={row.email} onChange={(e) => set({ ...row, email: e.target.value })} />
              </Field>
              <Field label="Telefone">
                <input className={inputClass} value={row.telefone} onChange={(e) => set({ ...row, telefone: e.target.value })} />
              </Field>
              <Field label="Cidade">
                <input className={inputClass} value={row.cidade} onChange={(e) => set({ ...row, cidade: e.target.value })} />
              </Field>
              <Field label="UF">
                <input className={inputClass} maxLength={2} value={row.estado} onChange={(e) => set({ ...row, estado: e.target.value.toUpperCase() })} />
              </Field>
            </div>
          ),
        },
      ]}
    />
  );
}

function Projetos() {
  const rows = useCrm((s) => s.projects);
  const clients = useCrm((s) => s.clients);
  const upsert = useCrm((s) => s.upsertProject);
  const remove = useCrm((s) => s.removeProject);
  const blank = (): Project => ({
    id: uid(),
    clienteId: clients[0]?.id ?? "",
    nome: "",
    descricao: "",
    status: "em_analise",
  });
  return (
    <EditorList
      title="Projetos"
      text="Agrupa propostas de um mesmo cliente. Opcional na composição."
      rows={rows}
      blank={blank}
      onSave={upsert}
      onRemove={remove}
      searchOf={(r) => `${r.nome} ${r.descricao}`}
      columns={[
        { key: "nome", label: "Projeto" },
        {
          key: "clienteId",
          label: "Cliente",
          render: (r) => clients.find((c) => c.id === r.clienteId)?.nome ?? "—",
        },
        { key: "status", label: "Status", render: (r) => labelStatusProjeto(r.status) },
      ]}
      form={(row, set) => (
        <div className="grid gap-3 sm:grid-cols-2">
          <div className="sm:col-span-2">
            <Field label="Nome">
              <input className={inputClass} value={row.nome} onChange={(e) => set({ ...row, nome: e.target.value })} />
            </Field>
          </div>
          <Field label="Cliente">
            <select className={inputClass} value={row.clienteId} onChange={(e) => set({ ...row, clienteId: e.target.value })}>
              <option value="">Sem cliente</option>
              {clients.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.nome}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Status">
            <select
              className={inputClass}
              value={row.status}
              onChange={(e) => set({ ...row, status: e.target.value as Project["status"] })}
            >
              {STATUS_PROJETO.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.label}
                </option>
              ))}
            </select>
          </Field>
          <div className="sm:col-span-2">
            <Field label="Descrição">
              <textarea className={areaClass} value={row.descricao} onChange={(e) => set({ ...row, descricao: e.target.value })} />
            </Field>
          </div>
        </div>
      )}
      valid={(row) => (row.nome.trim() ? null : "Informe o nome.")}
      steps={(row, set) => [
        {
          title: "Qual é o projeto",
          valid: () => (row.nome.trim() ? null : "Informe o nome."),
          body: (
            <div className="grid gap-3">
              <Field label="Nome">
                <input className={inputClass} value={row.nome} onChange={(e) => set({ ...row, nome: e.target.value })} />
              </Field>
              <Field label="Cliente">
                <select className={inputClass} value={row.clienteId} onChange={(e) => set({ ...row, clienteId: e.target.value })}>
                  <option value="">Sem cliente</option>
                  {clients.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.nome}
                    </option>
                  ))}
                </select>
              </Field>
            </div>
          ),
        },
        {
          title: "Situação",
          body: (
            <div className="grid gap-3">
              <Field label="Status">
                <select className={inputClass} value={row.status} onChange={(e) => set({ ...row, status: e.target.value as Project["status"] })}>
                  {STATUS_PROJETO.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.label}
                    </option>
                  ))}
                </select>
              </Field>
              <Field label="Descrição">
                <textarea className={areaClass} value={row.descricao} onChange={(e) => set({ ...row, descricao: e.target.value })} />
              </Field>
            </div>
          ),
        },
      ]}
    />
  );
}

function EditorList<T extends { id: string }>({
  title,
  text,
  rows,
  columns,
  blank,
  onSave,
  onRemove,
  searchOf,
  form,
  steps,
  valid,
}: {
  title: string;
  text: string;
  rows: T[];
  columns: { key: string; label: string; render?: (row: T) => ReactNode }[];
  blank: () => T;
  onSave: (row: T) => void;
  onRemove: (id: string) => void;
  searchOf: (row: T) => string;
  form: (row: T, set: (row: T) => void) => ReactNode;
  steps?: (row: T, set: (row: T) => void) => WizardStep[];
  valid: (row: T) => string | null;
}) {
  const [editing, setEditing] = useState<T | null>(null);
  const [confirmId, setConfirmId] = useState<string | null>(null);
  const globalQuery = useCrm((s) => s.query);
  const setGlobalQuery = useCrm((s) => s.setQuery);
  const query = globalQuery;
  const filtered = rows.filter((r) => searchOf(r).toLowerCase().includes(query.trim().toLowerCase()));
  const wizardSteps = editing
    ? steps
      ? steps(editing, setEditing)
      : [{ title: "Dados", body: form(editing, setEditing), valid: () => valid(editing) }]
    : [];

  return (
    <section>
      <PageHead
        title={title}
        text={text}
        action={
          <button
            type="button"
            onClick={() => setEditing(blank())}
            className="inline-flex h-11 items-center gap-2 rounded-md bg-primary px-4 text-sm font-semibold text-primary-fg"
          >
            <Plus className="size-4" aria-hidden="true" />
            Novo
          </button>
        }
      />
      <div className="relative mb-4">
        <Search className="pointer-events-none absolute top-3 left-3 size-4 text-muted" aria-hidden="true" />
        <input
          className={inputClass + " pl-9"}
          placeholder="Buscar"
          value={query}
          onChange={(e) => setGlobalQuery(e.target.value)}
          aria-label="Buscar"
        />
      </div>
      <Wizard
        open={editing != null}
        title={title}
        steps={wizardSteps}
        onClose={() => setEditing(null)}
        onSave={() => {
          if (!editing) return "Nada para salvar.";
          const message = valid(editing);
          if (message) return message;
          onSave(editing);
          setEditing(null);
          return null;
        }}
      />
      {filtered.length === 0 ? (
        <p className="rounded-lg border border-dashed border-line px-4 py-8 text-center text-sm text-muted">Nenhum registro.</p>
      ) : (
        <>
          <ul className="space-y-3 md:hidden">
            {filtered.map((row) => (
              <li key={row.id} className="rounded-lg border border-line bg-surface p-4">
                {columns.map((col) => (
                  <div key={col.key} className="text-sm">
                    <span className="text-muted">{col.label}: </span>
                    {col.render ? col.render(row) : String((row as Record<string, unknown>)[col.key] ?? "")}
                  </div>
                ))}
                <RowActions
                  rowId={row.id}
                  confirmId={confirmId}
                  setConfirmId={setConfirmId}
                  onEdit={() => setEditing(row)}
                  onRemove={onRemove}
                />
              </li>
            ))}
          </ul>
          <div className="hidden overflow-x-auto rounded-lg border border-line bg-surface md:block">
            <table className="w-full text-left text-sm">
              <thead className="bg-bg text-xs tracking-wide text-muted uppercase">
                <tr>
                  {columns.map((col) => (
                    <th key={col.key} className="px-3 py-3 font-medium">
                      {col.label}
                    </th>
                  ))}
                  <th className="px-3 py-3 font-medium">Ações</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((row) => (
                  <tr key={row.id} className="border-t border-line">
                    {columns.map((col) => (
                      <td key={col.key} className="max-w-xs truncate px-3 py-3">
                        {col.render ? col.render(row) : String((row as Record<string, unknown>)[col.key] ?? "")}
                      </td>
                    ))}
                    <td className="px-3 py-2">
                      <RowActions
                        rowId={row.id}
                        confirmId={confirmId}
                        setConfirmId={setConfirmId}
                        onEdit={() => setEditing(row)}
                        onRemove={onRemove}
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
    </section>
  );
}

function RowActions({
  rowId,
  confirmId,
  setConfirmId,
  onEdit,
  onRemove,
}: {
  rowId: string;
  confirmId: string | null;
  setConfirmId: (id: string | null) => void;
  onEdit: () => void;
  onRemove: (id: string) => void;
}) {
  return (
    <div className="mt-3 flex flex-wrap gap-2 md:mt-0">
      <button type="button" onClick={onEdit} className="h-10 rounded-md border border-line px-3 text-sm">
        Editar
      </button>
      {confirmId === rowId ? (
        <button
          type="button"
          onClick={() => {
            onRemove(rowId);
            setConfirmId(null);
          }}
          className="h-10 rounded-md bg-danger px-3 text-sm font-medium text-primary-fg"
        >
          Confirmar
        </button>
      ) : (
        <button
          type="button"
          onClick={() => setConfirmId(rowId)}
          className="inline-flex h-10 items-center gap-1 rounded-md px-3 text-sm text-danger"
        >
          <Trash2 className="size-4" aria-hidden="true" />
          Excluir
        </button>
      )}
    </div>
  );
}

function Proposta() {
  const draft = useCrm((s) => s.draft);
  const clients = useCrm((s) => s.clients);
  const projects = useCrm((s) => s.projects);
  const products = useCrm((s) => s.products);
  const services = useCrm((s) => s.services);
  const patchDraft = useCrm((s) => s.patchDraft);
  const addProductLine = useCrm((s) => s.addProductLine);
  const addToGroup = useCrm((s) => s.addToGroup);
  const setGroupQty = useCrm((s) => s.setGroupQty);
  const removeGroup = useCrm((s) => s.removeGroup);
  const addServiceLine = useCrm((s) => s.addServiceLine);
  const patchLine = useCrm((s) => s.patchLine);
  const removeLine = useCrm((s) => s.removeLine);
  const applyMarginAll = useCrm((s) => s.applyMarginAll);
  const saveProposal = useCrm((s) => s.saveProposal);
  const newDraft = useCrm((s) => s.newDraft);
  const [kind, setKind] = useState<"item" | "grupo" | "servico">("item");
  const [pick, setPick] = useState("");
  const [qtd, setQtd] = useState(1);
  const [just, setJust] = useState("");
  const [nivel, setNivel] = useState<NivelCriticidade>(1);
  const [error, setError] = useState("");
  const [includeOpen, setIncludeOpen] = useState(false);
  const [gruposAbertos, setGruposAbertos] = useState<Record<string, boolean>>({});
  const totals = proposalTotals(draft.itens);
  const filteredProjects = projects.filter((p) => !draft.clienteId || p.clienteId === draft.clienteId);
  const blocos = useMemo(() => montarBlocos(draft.itens), [draft.itens]);
  const produtoEscolhido = kind === "servico" ? undefined : products.find((item) => item.id === pick);

  return (
    <section>
      <PageHead
        title={draft.id ? "Editar proposta" : "Montar proposta"}
        text="Item entra sozinho. Grupo abre a composição pronta, e cada linha continua editável."
        action={
          <button type="button" onClick={newDraft} className="h-11 rounded-md border border-line bg-surface px-4 text-sm">
            Limpar
          </button>
        }
      />
      <div className="grid gap-3 rounded-lg border border-line bg-surface p-4 sm:grid-cols-2">
        <div className="sm:col-span-2">
          <Field label="Título">
            <input className={inputClass} value={draft.titulo} onChange={(e) => patchDraft({ titulo: e.target.value })} />
          </Field>
        </div>
        <Field label="Cliente">
          <select
            className={inputClass}
            value={draft.clienteId}
            onChange={(e) => patchDraft({ clienteId: e.target.value, projetoId: "" })}
          >
            <option value="">Sem cliente</option>
            {clients.map((c) => (
              <option key={c.id} value={c.id}>
                {c.nome}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Projeto">
          <select className={inputClass} value={draft.projetoId} onChange={(e) => patchDraft({ projetoId: e.target.value })}>
            <option value="">Sem projeto</option>
            {filteredProjects.map((p) => (
              <option key={p.id} value={p.id}>
                {p.nome}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Status">
          <select
            className={inputClass}
            value={draft.status}
            onChange={(e) => patchDraft({ status: e.target.value as ProposalStatus })}
          >
            {STATUS_PROPOSTA.map((s) => (
              <option key={s.id} value={s.id}>
                {s.label}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Margem padrão (%)">
          <input
            className={inputClass}
            type="number"
            step="1"
            value={draft.margem}
            onChange={(e) => patchDraft({ margem: Number(e.target.value) })}
          />
        </Field>
      </div>

      <button
        type="button"
        onClick={() => setIncludeOpen(true)}
        className="mt-4 inline-flex h-11 items-center gap-2 rounded-md bg-primary px-4 text-sm font-semibold text-primary-fg"
      >
        <Plus className="size-4" aria-hidden="true" />
        Incluir na listagem
      </button>
      <Wizard
        open={includeOpen}
        title="Incluir na proposta"
        onClose={() => setIncludeOpen(false)}
        onSave={() => {
          if (!pick) return "Selecione um item.";
          if (kind !== "servico" && produtoEscolhido?.tipo === "grupo" && (produtoEscolhido.componentes ?? []).length === 0) {
            return "Este grupo não tem itens.";
          }
          if (kind === "servico") addServiceLine(pick, qtd, just.trim(), nivel);
          else addProductLine(pick, qtd, just.trim());
          setJust("");
          setIncludeOpen(false);
          return null;
        }}
        steps={[
          {
            title: "O que entra",
            body: (
              <div className="grid gap-3">
                <div className="flex gap-2">
                  {(["item", "grupo", "servico"] as const).map((k) => (
                    <button
                      key={k}
                      type="button"
                      onClick={() => {
                        setKind(k);
                        setPick("");
                      }}
                      className={"h-10 rounded-md px-3 text-sm font-medium " + (kind === k ? "bg-primary text-primary-fg" : "border border-line")}
                    >
                      {k === "item" ? "Item" : k === "grupo" ? "Grupo" : "Serviço"}
                    </button>
                  ))}
                </div>
                <Field label={kind === "servico" ? "Serviço da base" : kind === "grupo" ? "Grupo da base" : "Item da base"}>
                  <select
                    className={inputClass}
                    value={pick}
                    onChange={(e) => {
                      const id = e.target.value;
                      setPick(id);
                      if (kind === "servico") {
                        const service = services.find((item) => item.id === id);
                        if (service) setNivel(normalizeNivel(service.nivel));
                      }
                    }}
                  >
                    <option value="">Selecionar</option>
                    {kind === "servico"
                      ? services.map((item) => (
                          <option key={item.id} value={item.id}>
                            {item.codigo ? `${item.codigo} · ` : ""}
                            {item.descricao}
                          </option>
                        ))
                      : products
                          .filter((item) => (kind === "grupo" ? item.tipo === "grupo" : item.tipo !== "grupo"))
                          .map((item) => (
                            <option key={item.id} value={item.id}>
                              {item.codigo ? `${item.codigo} · ` : ""}
                              {item.descricao}
                            </option>
                          ))}
                  </select>
                </Field>
              </div>
            ),
          },
          {
            title: "Quantidade e justificativa",
            valid: () => (pick ? null : "Selecione um item."),
            body: (
              <div className="grid gap-3">
                <Field label={kind === "grupo" ? "Qtd do grupo" : "Qtd"}>
                  <input className={inputClass} type="number" min={0} step="1" value={qtd} onChange={(e) => setQtd(Number(e.target.value))} />
                </Field>
                {kind === "servico" ? (
                  <Field label="Nível de criticidade">
                    <select className={inputClass} value={nivel} onChange={(e) => setNivel(Number(e.target.value) as NivelCriticidade)}>
                      {NIVEIS.map((item) => (
                        <option key={item.nivel} value={item.nivel}>
                          {item.nivel} · fator {fatorLabel(item.nivel)}
                        </option>
                      ))}
                    </select>
                  </Field>
                ) : null}
                <Field label="Justificativa">
                  <input className={inputClass} value={just} onChange={(e) => setJust(e.target.value)} placeholder="Trecho do escopo ou memória de cálculo" />
                </Field>
              </div>
            ),
          },
        ]}
      />

      {draft.itens.length === 0 ? (
        <p className="mt-4 rounded-lg border border-dashed border-line px-4 py-8 text-center text-sm text-muted">
          A listagem ainda está vazia.
        </p>
      ) : (
        <div className="mt-4 space-y-4">
          <div className="flex justify-end">
            <button type="button" onClick={applyMarginAll} className="h-10 rounded-md border border-line bg-surface px-3 text-sm">
              Aplicar margem padrão em todos
            </button>
          </div>
          {blocos.map((bloco) =>
            bloco.tipo === "secao" ? (
              <section key={bloco.secao} className="overflow-hidden rounded-lg border border-line bg-surface">
                <h2 className="border-b border-line bg-bg px-4 py-3 text-sm font-semibold">{bloco.secao}</h2>
                <ul>
                  {bloco.linhas.map((item) => (
                    <LineEditor
                      key={item.id}
                      item={item}
                      foto={products.find((product) => product.id === item.origemId)?.foto ?? ""}
                      onPatch={(patch) => patchLine(item.id, patch)}
                      onRemove={() => removeLine(item.id)}
                    />
                  ))}
                </ul>
              </section>
            ) : (
              <GrupoNaProposta
                key={bloco.id}
                header={bloco.header}
                linhas={bloco.linhas}
                aberto={gruposAbertos[bloco.id] !== false}
                foto={products.find((product) => product.id === bloco.header.origemId)?.foto ?? ""}
                fotos={products}
                onToggle={() => setGruposAbertos((atual) => ({ ...atual, [bloco.id]: atual[bloco.id] === false }))}
                onQty={(qtdGrupo) => setGroupQty(bloco.id, qtdGrupo)}
                onAdd={(productId, qtdItem) => addToGroup(bloco.id, productId, qtdItem)}
                onRemoveGroup={() => removeGroup(bloco.id)}
                onPatch={(id, patch) => patchLine(id, patch)}
                onRemoveLine={removeLine}
              />
            ),
          )}
        </div>
      )}

      <div className="mt-4 grid gap-3 rounded-2xl bg-primary px-5 py-5 text-primary-fg sm:grid-cols-4">
        <Sum label="Custo" value={brl(totals.custo)} />
        <Sum label="Venda" value={brl(totals.venda)} />
        <Sum label="Margem" value={brl(totals.margemValor)} />
        <Sum label="HH" value={String(totals.hh)} />
      </div>
      <div className="mt-3">
        <Field label="Observações">
          <textarea className={areaClass} value={draft.observacoes} onChange={(e) => patchDraft({ observacoes: e.target.value })} />
        </Field>
      </div>
      {error ? <p className="mt-3 text-sm text-danger">{error}</p> : null}
      <button
        type="button"
        className="mt-4 h-11 rounded-md bg-accent px-5 text-sm font-semibold text-accent-fg"
        onClick={() => {
          const message = saveProposal();
          setError(message ?? "");
        }}
      >
        Salvar proposta
      </button>
    </section>
  );
}

function Sum({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="text-xs tracking-wide text-primary-fg/70 uppercase">{label}</p>
      <p className="tabular mt-1 text-lg font-semibold">{value}</p>
    </div>
  );
}

function montarBlocos(itens: Line[]) {
  const vistos = new Set<string>();
  const saida: Array<
    | { tipo: "secao"; secao: string; linhas: Line[] }
    | { tipo: "grupo"; id: string; header: Line; linhas: Line[] }
  > = [];
  for (const item of itens) {
    if (item.grupoId) {
      if (vistos.has(item.grupoId)) continue;
      vistos.add(item.grupoId);
      const membros = itens.filter((linha) => linha.grupoId === item.grupoId);
      const header = membros.find((linha) => linha.cabecalho) ?? membros[0];
      if (!header) continue;
      saida.push({
        tipo: "grupo",
        id: item.grupoId,
        header,
        linhas: membros.filter((linha) => linha.id !== header.id),
      });
      continue;
    }
    const ultimo = saida[saida.length - 1];
    if (ultimo && ultimo.tipo === "secao" && ultimo.secao === item.secao) ultimo.linhas.push(item);
    else saida.push({ tipo: "secao", secao: item.secao, linhas: [item] });
  }
  return saida;
}

function GrupoNaProposta({
  header,
  linhas,
  aberto,
  foto,
  fotos,
  onToggle,
  onQty,
  onAdd,
  onRemoveGroup,
  onPatch,
  onRemoveLine,
}: {
  header: Line;
  linhas: Line[];
  aberto: boolean;
  foto: string;
  fotos: Product[];
  onToggle: () => void;
  onQty: (qtd: number) => void;
  onAdd: (productId: string, qtd: number) => void;
  onRemoveGroup: () => void;
  onPatch: (id: string, patch: Partial<Pick<Line, "qtd" | "margem" | "justificativa" | "custo" | "nivel">>) => void;
  onRemoveLine: (id: string) => void;
}) {
  const venda = linhas.reduce((acc, linha) => acc + lineTotal(linha), 0);
  const [extraId, setExtraId] = useState("");
  const [extraQtd, setExtraQtd] = useState(1);
  const avulsos = fotos.filter((product) => product.tipo !== "grupo");
  return (
    <section className="overflow-hidden rounded-lg border border-line bg-surface">
      <button
        type="button"
        onClick={onToggle}
        aria-expanded={aberto}
        className="flex w-full items-center gap-3 px-4 py-3 text-left"
      >
        <ChevronDown className={"size-4 shrink-0 transition-transform " + (aberto ? "" : "-rotate-90")} aria-hidden="true" />
        {foto ? <img src={foto} alt="" className="h-11 w-11 rounded-md object-cover" /> : null}
        <span className="min-w-0 flex-1">
          <span className="block font-semibold">{header.descricao}</span>
          <span className="text-sm text-muted">{linhas.length} itens · grupo</span>
        </span>
        <span className="tabular text-sm font-medium">{brl(venda)}</span>
      </button>
      {aberto ? (
        <div className="border-t border-line">
          <div className="flex flex-wrap items-end justify-between gap-3 px-4 py-3">
            <label className="text-xs text-muted">
              Qtd do grupo
              <span className="mt-1 block font-normal">Recalcula os itens pela composição.</span>
              <input
                className={inputClass + " mt-1 w-28"}
                type="number"
                min={0}
                step="1"
                value={header.qtd}
                onChange={(event) => onQty(Number(event.target.value))}
              />
            </label>
            <button type="button" onClick={onRemoveGroup} className="h-11 text-sm text-danger">
              Remover grupo
            </button>
          </div>
          <div className="grid gap-3 border-t border-line px-4 py-3 sm:grid-cols-[1fr_120px_auto]">
            <select className={inputClass} value={extraId} onChange={(event) => setExtraId(event.target.value)} aria-label="Item para o grupo">
              <option value="">Incluir outro item da base</option>
              {avulsos.map((product) => (
                <option key={product.id} value={product.id}>
                  {product.codigo ? `${product.codigo} · ` : ""}
                  {product.descricao}
                </option>
              ))}
            </select>
            <input
              className={inputClass}
              type="number"
              min={0}
              step="1"
              value={extraQtd}
              aria-label="Quantidade extra"
              onChange={(event) => setExtraQtd(Number(event.target.value))}
            />
            <button
              type="button"
              className="h-11 rounded-md border border-line px-3 text-sm"
              onClick={() => {
                if (!extraId || extraQtd <= 0) return;
                onAdd(extraId, extraQtd);
                setExtraId("");
                setExtraQtd(1);
              }}
            >
              Incluir no grupo
            </button>
          </div>
          <ul>
            {linhas.map((item) => (
              <LineEditor
                key={item.id}
                item={item}
                foto={fotos.find((product) => product.id === item.origemId)?.foto ?? ""}
                onPatch={(patch) => onPatch(item.id, patch)}
                onRemove={() => onRemoveLine(item.id)}
              />
            ))}
          </ul>
        </div>
      ) : null}
    </section>
  );
}

function LineEditor({
  item,
  foto = "",
  onPatch,
  onRemove,
}: {
  item: Line;
  foto?: string;
  onPatch: (patch: Partial<Pick<Line, "qtd" | "margem" | "justificativa" | "custo" | "nivel">>) => void;
  onRemove: () => void;
}) {
  return (
    <li className="grid gap-3 border-t border-line px-4 py-4 lg:grid-cols-[1.4fr_repeat(4,minmax(0,0.7fr))_auto]">
      <div className="min-w-0">
        <div className="flex items-start gap-3">
          {foto ? <img src={foto} alt="" className="h-12 w-12 shrink-0 rounded-md object-cover" /> : null}
          <div className="min-w-0">
            <p className="font-medium">{item.descricao}</p>
            <p className="text-sm text-muted">
              {item.codigo || "sem código"}
              {item.fabricante ? ` · ${item.fabricante}` : ""} · {item.unidade}
              {item.tipo === "servico"
                ? ` · nível ${normalizeNivel(item.nivel)} (fator ${fatorLabel(item.nivel)}) · ${item.hh} HH`
                : ""}
            </p>
          </div>
        </div>
        <input
          className={inputClass + " mt-2"}
          value={item.justificativa}
          placeholder="Justificativa"
          onChange={(e) => onPatch({ justificativa: e.target.value })}
          aria-label="Justificativa"
        />
        {item.tipo === "servico" ? (
          <label className="mt-2 block text-xs text-muted">
            Nível de criticidade
            <select
              className={inputClass + " mt-1"}
              value={normalizeNivel(item.nivel)}
              onChange={(e) => onPatch({ nivel: Number(e.target.value) })}
            >
              {NIVEIS.map((nivel) => (
                <option key={nivel.nivel} value={nivel.nivel}>
                  {nivel.nivel} · fator {fatorLabel(nivel.nivel)}
                </option>
              ))}
            </select>
          </label>
        ) : null}
      </div>
      <Num label="Qtd" value={item.qtd} onChange={(qtd) => onPatch({ qtd })} />
      <Num label="Custo" value={item.custo} onChange={(custo) => onPatch({ custo })} />
      <Num label="Margem %" value={item.margem} onChange={(margem) => onPatch({ margem })} />
      <div>
        <p className="text-xs text-muted">Total</p>
        <p className="tabular mt-2 text-sm font-semibold">{brl(lineTotal(item))}</p>
        <p className="tabular text-xs text-muted">{brl(precoUnit(item.custo, item.margem))} / un</p>
      </div>
      <button type="button" onClick={onRemove} className="h-11 self-end text-sm text-danger lg:self-center">
        Remover
      </button>
    </li>
  );
}

function Num({ label, value, onChange }: { label: string; value: number; onChange: (n: number) => void }) {
  return (
    <label className="text-xs text-muted">
      {label}
      <input
        className={inputClass + " mt-1"}
        type="number"
        step="0.01"
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
      />
    </label>
  );
}

function Historico() {
  const proposals = useCrm((s) => s.proposals);
  const clients = useCrm((s) => s.clients);
  const projects = useCrm((s) => s.projects);
  const loadProposal = useCrm((s) => s.loadProposal);
  const removeProposal = useCrm((s) => s.removeProposal);
  const duplicateProposal = useCrm((s) => s.duplicateProposal);
  const [open, setOpen] = useState<string | null>(proposals[0]?.id ?? null);
  const [confirmId, setConfirmId] = useState<string | null>(null);
  const selected = proposals.find((p) => p.id === open) ?? null;

  return (
    <section>
      <PageHead title="Histórico" text="Propostas gravadas neste navegador. O arquivo abre no Excel." />
      {proposals.length === 0 ? (
        <p className="rounded-lg border border-dashed border-line px-4 py-8 text-center text-sm text-muted">Nenhuma proposta salva.</p>
      ) : (
        <div className="grid gap-4 lg:grid-cols-[280px_1fr]">
          <ul className="space-y-2">
            {proposals.map((p) => (
              <li key={p.id}>
                <button
                  type="button"
                  onClick={() => setOpen(p.id)}
                  className={
                    "w-full rounded-md border px-3 py-3 text-left " +
                    (open === p.id ? "border-primary bg-surface" : "border-line bg-surface")
                  }
                >
                  <p className="font-medium">{p.titulo}</p>
                  <p className="mt-1 text-sm text-muted">
                    {labelStatusProposta(p.status)} · {brl(proposalTotals(p.itens).venda)}
                  </p>
                </button>
              </li>
            ))}
          </ul>
          {selected ? (
            <ProposalDetail
              proposal={selected}
              client={clients.find((c) => c.id === selected.clienteId)}
              project={projects.find((p) => p.id === selected.projetoId)}
              confirm={confirmId === selected.id}
              onEdit={() => loadProposal(selected.id)}
              onCopy={() => duplicateProposal(selected.id)}
              onAskRemove={() => setConfirmId(selected.id)}
              onRemove={() => {
                removeProposal(selected.id);
                setConfirmId(null);
                setOpen(null);
              }}
            />
          ) : null}
        </div>
      )}
    </section>
  );
}

function ProposalDetail({
  proposal,
  client,
  project,
  confirm,
  onEdit,
  onCopy,
  onAskRemove,
  onRemove,
}: {
  proposal: Proposal;
  client?: Client;
  project?: Project;
  confirm: boolean;
  onEdit: () => void;
  onCopy: () => void;
  onAskRemove: () => void;
  onRemove: () => void;
}) {
  const totals = proposalTotals(proposal.itens);
  const openWarehouse = useCrm((s) => s.openWarehouse);
  return (
    <article className="min-w-0 rounded-lg border border-line bg-surface p-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <h2 className="text-xl font-semibold">{proposal.titulo}</h2>
          <p className="mt-1 text-sm text-muted">
            {client?.nome ?? "Sem cliente"}
            {project ? ` · ${project.nome}` : ""} · {labelStatusProposta(proposal.status)}
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            className="inline-flex h-11 items-center gap-2 rounded-md bg-primary px-3 text-sm font-semibold text-primary-fg"
            onClick={() => {
              const safe = proposal.titulo.replaceAll(/[^\w\-]+/g, "_").slice(0, 40);
              downloadText(`Proposta_${safe}.csv`, proposalCsv(proposal, client, project), "text/csv;charset=utf-8");
            }}
          >
            <Download className="size-4" aria-hidden="true" />
            Exportar Excel
          </button>
          <button
            type="button"
            onClick={() => openWarehouse(proposal.id)}
            className="inline-flex h-11 items-center gap-2 rounded-md border border-line px-3 text-sm"
          >
            <Warehouse className="size-4" aria-hidden="true" />
            Almoxarifado
          </button>
          <button type="button" onClick={onEdit} className="h-11 rounded-md border border-line px-3 text-sm">
            Editar
          </button>
          <button type="button" onClick={onCopy} className="h-11 rounded-md border border-line px-3 text-sm">
            Duplicar
          </button>
          {confirm ? (
            <button type="button" onClick={onRemove} className="h-11 rounded-md bg-danger px-3 text-sm text-primary-fg">
              Confirmar exclusão
            </button>
          ) : (
            <button type="button" onClick={onAskRemove} className="h-11 px-3 text-sm text-danger">
              Excluir
            </button>
          )}
        </div>
      </div>
      <div className="mt-4 overflow-x-auto">
        <table className="w-full min-w-[720px] text-left text-sm">
          <thead className="text-xs tracking-wide text-muted uppercase">
            <tr>
              {["Item", "Descrição", "Qtd", "Und", "Nível", "HH", "Custo", "Margem", "Total"].map((h) => (
                <th key={h} className="px-2 py-2 font-medium">
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {proposal.itens
              .filter((item) => !item.cabecalho)
              .map((item) => (
              <tr key={item.id} className="border-t border-line">
                <td className="px-2 py-2 font-mono text-xs">{item.codigo}</td>
                <td className="px-2 py-2">{item.grupoNome ? `${item.grupoNome} · ${item.descricao}` : item.descricao}</td>
                <td className="tabular px-2 py-2">{item.qtd}</td>
                <td className="px-2 py-2">{item.unidade}</td>
                <td className="px-2 py-2">{item.tipo === "servico" ? normalizeNivel(item.nivel) : "—"}</td>
                <td className="tabular px-2 py-2">{item.tipo === "servico" ? item.hh : "—"}</td>
                <td className="tabular px-2 py-2">{brl(item.custo)}</td>
                <td className="tabular px-2 py-2">{item.margem}%</td>
                <td className="tabular px-2 py-2 font-medium">{brl(lineTotal(item))}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="tabular mt-4 text-sm">
        Custo {brl(totals.custo)} · Venda {brl(totals.venda)} · Margem {brl(totals.margemValor)} · HH {totals.hh}
      </p>
      {proposal.observacoes ? <p className="mt-2 text-sm text-muted">{proposal.observacoes}</p> : null}
    </article>
  );
}
