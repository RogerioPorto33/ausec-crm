import { useState, type ReactNode } from "react";
import { Plus, Trash2 } from "lucide-react";
import { uid, type Pessoa, type Vinculo } from "@/lib/crm/model";
import { useCrm } from "@/lib/crm/store";
import { Wizard } from "@/components/crm/Wizard";

const inputClass =
  "h-11 w-full rounded-md border border-line bg-surface px-3 text-sm text-ink outline-none focus:border-primary";

export function Pessoal() {
  const pessoas = useCrm((s) => s.pessoas);
  const vinculos = useCrm((s) => s.vinculos);
  const query = useCrm((s) => s.query).trim().toLowerCase();
  const lista = pessoas.filter((p) => !query || `${p.nome} ${p.funcao}`.toLowerCase().includes(query));
  const ativos = pessoas.filter((p) => p.ativo);

  return (
    <section>
      <div className="mb-6">
        <h1 className="text-2xl font-semibold tracking-tight">Pessoal</h1>
        <p className="mt-1 max-w-2xl text-sm text-pretty text-muted">
          Cadastro da equipe. Função na obra fica na Adm de obra, ao montar a alocação.
        </p>
      </div>
      <div className="mb-4 grid gap-3 sm:grid-cols-2">
        <article className="card px-5 py-4">
          <p className="text-xs font-medium text-muted">Ativos</p>
          <p className="tabular mt-2 text-2xl font-semibold">{ativos.length}</p>
          <p className="mt-1 text-sm text-muted">{pessoas.length} cadastrados</p>
        </article>
        <article className="card px-5 py-4">
          <p className="text-xs font-medium text-muted">Vínculos</p>
          <p className="tabular mt-2 text-2xl font-semibold">{vinculos.length}</p>
          <p className="mt-1 text-sm text-muted">CLT, PJ, estágio e outros</p>
        </article>
      </div>
      <Equipe pessoas={lista} vinculos={vinculos} />
    </section>
  );
}

function Equipe({ pessoas, vinculos }: { pessoas: Pessoa[]; vinculos: Vinculo[] }) {
  const upsert = useCrm((s) => s.upsertPessoa);
  const remove = useCrm((s) => s.removePessoa);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<Pessoa>(() => emptyPessoa(vinculos[0]?.id ?? ""));

  return (
    <div className="space-y-4">
      <button
        type="button"
        onClick={() => {
          setForm(emptyPessoa(vinculos[0]?.id ?? ""));
          setOpen(true);
        }}
        className="inline-flex h-11 items-center gap-2 rounded-md bg-accent px-4 text-sm font-semibold text-accent-fg"
      >
        <Plus className="size-4" aria-hidden="true" />
        Incluir na equipe
      </button>
      <Wizard
        open={open}
        title="Nova pessoa"
        onClose={() => setOpen(false)}
        onSave={() => {
          if (!form.nome.trim()) return "Informe o nome.";
          upsert({ ...form, nome: form.nome.trim(), funcao: form.funcao.trim() });
          setOpen(false);
          return null;
        }}
        steps={[
          {
            title: "Quem é",
            valid: () => (form.nome.trim() ? null : "Informe o nome."),
            body: (
              <div className="grid gap-3">
                <Field label="Nome">
                  <input className={inputClass} value={form.nome} onChange={(e) => setForm({ ...form, nome: e.target.value })} />
                </Field>
                <Field label="Função padrão">
                  <input className={inputClass} value={form.funcao} onChange={(e) => setForm({ ...form, funcao: e.target.value })} placeholder="Técnico, engenheiro, auxiliar" />
                </Field>
              </div>
            ),
          },
          {
            title: "Vínculo",
            body: (
              <Field label="Vínculo">
                <select className={inputClass} value={form.vinculoId} onChange={(e) => setForm({ ...form, vinculoId: e.target.value })}>
                  <option value="">Sem vínculo</option>
                  {vinculos.map((v) => (
                    <option key={v.id} value={v.id}>
                      {v.nome}
                    </option>
                  ))}
                </select>
              </Field>
            ),
          },
        ]}
      />

      {pessoas.length === 0 ? (
        <p className="text-sm text-muted">Nenhuma pessoa cadastrada.</p>
      ) : (
        <div className="overflow-x-auto rounded-lg border border-line bg-surface">
          <table className="w-full min-w-[640px] text-left text-sm">
            <thead className="text-xs tracking-wide text-muted uppercase">
              <tr>
                {["Pessoa", "Função", "Vínculo", ""].map((h) => (
                  <th key={h || "acao"} className="px-3 py-2 font-medium">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {pessoas.map((p) => (
                <tr key={p.id} className="border-t border-line">
                  <td className="px-3 py-3">
                    <p className="font-medium">{p.nome}</p>
                    {!p.ativo ? <p className="text-xs text-muted">inativo</p> : null}
                  </td>
                  <td className="px-3 py-3">{p.funcao || "—"}</td>
                  <td className="px-3 py-3">
                    <select className="h-9 rounded-md border border-line px-2 text-sm" value={p.vinculoId} onChange={(e) => upsert({ ...p, vinculoId: e.target.value })}>
                      <option value="">—</option>
                      {vinculos.map((v) => (
                        <option key={v.id} value={v.id}>
                          {v.nome}
                        </option>
                      ))}
                    </select>
                  </td>
                  <td className="px-3 py-3">
                    <button type="button" onClick={() => upsert({ ...p, ativo: !p.ativo })} className="mr-3 text-sm text-primary">
                      {p.ativo ? "Inativar" : "Ativar"}
                    </button>
                    <button type="button" onClick={() => remove(p.id)} className="text-danger" aria-label="Excluir pessoa">
                      <Trash2 className="inline size-4" aria-hidden="true" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="block text-sm">
      <span className="mb-1 block font-medium">{label}</span>
      {children}
    </label>
  );
}

function emptyPessoa(vinculoId: string): Pessoa {
  return { id: uid(), nome: "", funcao: "", vinculoId, ativo: true };
}
