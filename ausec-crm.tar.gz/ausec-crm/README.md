# AUSEC CRM

CRM interno da AUSEC: bases, propostas, cronograma, almoxarifado, pessoal, mensagens e adm de obra.

Login demo: `admin@ausec.local` / `ausec`

```bash
npm install
npm run dev
```

Abre em http://127.0.0.1:8080
